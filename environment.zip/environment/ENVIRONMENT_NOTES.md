# Environment notes

The reported analyses were not all executed in a single frozen software environment. Two machine-generated manifests record the following environments.

## Main neural model

- Python 3.12.3
- PyTorch 2.8.0+cu128
- CUDA 12.8
- NumPy 2.3.2
- pandas 2.3.3
- scikit-learn 1.9.1
- device: CUDA
- recorded GPU: NVIDIA RTX PRO 6000 Blackwell Server Edition

Use `requirements_main.txt` as a reconstruction aid. The copied `provenance/main_model_run_manifest.json` is the authoritative execution record.

## Strong baselines

- Python 3.11.15
- NumPy 1.26.4
- pandas 2.2.2
- scikit-learn 1.9.0
- XGBoost 3.2.0
- LightGBM 4.7.0
- CatBoost 1.2.10
- TabM 0.0.3
- pytabkit 1.7.3

Use `requirements_baselines.txt` as a reconstruction aid. The copied `provenance/baseline_run_manifest.json` is the authoritative execution record.

## Why there are two requirement files

The manifests document materially different Python and NumPy stacks. Combining them into a single purportedly exact lock file would misrepresent the historical execution environment and may create dependency conflicts. Reviewers can inspect the full workflow without installation; exact re-execution should use separate environments.

## Unrecorded versions

SciPy and openpyxl are required by parts of the workflow, but their exact historical versions were not captured in the selected run manifests. They are therefore deliberately unpinned. Before a permanent public release, the authors should recreate each environment, execute an end-to-end verification, and export a tested lock file (`conda-lock`, `pip-tools`, or equivalent) rather than retroactively guessing versions.

## Suggested installation

Create two clean environments and install the corresponding requirement file. GPU users must select a PyTorch/CUDA build compatible with their driver. Hardware differences can produce small floating-point differences even when seeds and software versions are fixed.

