"""ESD-MTMS-Net 统一训练入口。

默认命令为 ``check``，只检查数据、折划分和配置，不训练。正式训练必须同时
使用 ``train`` 和 ``--confirm-training TRAIN``。所有由数据学习的变换均在相应
训练高校内拟合；外层测试高校不得参与预处理、早停、寻优或方法选择。
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import platform
import random
import sys
import time
from datetime import datetime, timezone
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd
import sklearn
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from torch import Tensor, nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset

from model import AblationFlags, ModelConfig, build_model


HERE = Path(__file__).resolve().parent
RESEARCH_ROOT = HERE.parent
DATA_SCRIPT = RESEARCH_ROOT / "01_data_preprocessing" / "data_preprocessing.py"
DATA_FILE = RESEARCH_ROOT / "01_data_preprocessing" / "output" / "model_input_data.csv"
FOLD_FILE = RESEARCH_ROOT / "01_data_preprocessing" / "output" / "university_five_fold_assignment.csv"
OUTPUT_DIR = HERE / "output"
TASK_WEIGHTS = (0.70, 0.15, 0.15)
SELECTION_FRACTION = 0.15
CONFIRMATION_TEXT = "TRAIN"


def _load_data_module() -> Any:
    """按文件加载数据阶段定义，避免复制字段契约和折内处理代码。"""

    if not DATA_SCRIPT.is_file():
        raise FileNotFoundError(f"缺少数据处理代码：{DATA_SCRIPT}")
    module_name = "esd_data_preprocessing"
    spec = importlib.util.spec_from_file_location(module_name, DATA_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载：{DATA_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


DATA = _load_data_module()


@dataclass(frozen=True)
class TrainConfig:
    batch_size: int = 256
    max_epochs: int = 300
    patience: int = 45
    learning_rate: float = 5.0e-4
    weight_decay: float = 1.0e-4
    gradient_clip: float = 1.0
    warmup_epochs: int = 10
    min_delta: float = 1.0e-4
    use_amp: bool = True


@dataclass(frozen=True)
class LossConfig:
    protocol: str = "M0"
    huber_delta: float = 0.70
    rank_weight: float = 0.20
    rank_temperature: float = 0.25
    risk_weight: float = 2.0
    task_weights: tuple[float, float, float] = TASK_WEIGHTS


@dataclass
class PreparedSplit:
    train_continuous: np.ndarray
    train_categorical: np.ndarray
    train_target: np.ndarray
    train_risk: np.ndarray
    other_continuous: np.ndarray
    other_categorical: np.ndarray
    other_target: np.ndarray
    other_target_raw: np.ndarray
    other_risk: np.ndarray
    continuous_names: list[str]
    categorical_names: list[str]
    cardinalities: list[int]
    feature_processor: Any
    representation_processor: Any
    target_processor: Any


class PiecewiseLinearEncoder:
    """训练折拟合的分位数分段线性编码（PLE）。

    每个非二元连续特征最多使用16个区间。第 j 个基函数表示样本在第 j 个区间
    已完成的比例：较早区间为1、当前区间为0--1、较晚区间为0。缺失指示变量
    保持单列，不进行分段扩展。
    """

    def __init__(self, max_bins: int = 16) -> None:
        if max_bins < 2:
            raise ValueError("PLE 至少需要2个候选区间")
        self.max_bins = int(max_bins)

    def fit(self, values: np.ndarray, names: Sequence[str]) -> "PiecewiseLinearEncoder":
        if values.ndim != 2 or values.shape[1] != len(names):
            raise ValueError("PLE 输入矩阵与名称数量不一致")
        self.edges_: list[np.ndarray | None] = []
        self.output_names_: list[str] = []
        quantiles = np.linspace(0.0, 1.0, self.max_bins + 1)
        for column, name in zip(values.T, names):
            if name.endswith("__missing") or np.unique(column).size <= 2:
                self.edges_.append(None)
                self.output_names_.append(name)
                continue
            edges = np.unique(np.quantile(column, quantiles))
            if len(edges) < 2:
                self.edges_.append(None)
                self.output_names_.append(name)
                continue
            self.edges_.append(edges.astype(np.float64))
            self.output_names_.extend(
                [f"{name}__PLE_{index + 1:02d}" for index in range(len(edges) - 1)]
            )
        return self

    def transform(self, values: np.ndarray) -> np.ndarray:
        if not hasattr(self, "edges_") or values.shape[1] != len(self.edges_):
            raise RuntimeError("PLE 未拟合或输入维度不一致")
        output: list[np.ndarray] = []
        for column, edges in zip(values.T, self.edges_):
            if edges is None:
                output.append(column[:, None])
                continue
            width = np.diff(edges)
            encoded = (column[:, None] - edges[:-1][None, :]) / width[None, :]
            output.append(np.clip(encoded, 0.0, 1.0))
        return np.concatenate(output, axis=1).astype(np.float32, copy=False)


def apply_representation(
    train_values: np.ndarray,
    other_values: np.ndarray,
    names: Sequence[str],
    representation: str,
) -> tuple[np.ndarray, np.ndarray, list[str], PiecewiseLinearEncoder | None]:
    if representation == "raw":
        return train_values, other_values, list(names), None
    if representation != "ple16":
        raise ValueError(f"未知连续编码：{representation}")
    encoder = PiecewiseLinearEncoder(max_bins=16).fit(train_values, names)
    return (
        encoder.transform(train_values),
        encoder.transform(other_values),
        encoder.output_names_,
        encoder,
    )


def prepare_split(
    train_frame: pd.DataFrame,
    other_frame: pd.DataFrame,
    representation: str,
) -> PreparedSplit:
    """仅在 train_frame 拟合特征、目标与 PLE 处理器。"""

    feature_processor = DATA.FoldFeaturePreprocessor().fit(train_frame)
    train_x = feature_processor.transform(train_frame)
    other_x = feature_processor.transform(other_frame)
    train_cont, other_cont, continuous_names, representation_processor = apply_representation(
        train_x.continuous, other_x.continuous, train_x.continuous_names, representation
    )
    target_processor = DATA.FoldTargetPreprocessor().fit(train_frame)
    train_y, _, train_risk = target_processor.transform(train_frame)
    other_y, other_raw, other_risk = target_processor.transform(other_frame)
    arrays = [train_cont, other_cont, train_y, other_y, other_raw]
    if not all(np.isfinite(array).all() for array in arrays):
        raise ValueError("折内处理后存在非有限值")
    return PreparedSplit(
        train_continuous=train_cont,
        train_categorical=train_x.categorical,
        train_target=train_y,
        train_risk=train_risk,
        other_continuous=other_cont,
        other_categorical=other_x.categorical,
        other_target=other_y,
        other_target_raw=other_raw,
        other_risk=other_risk,
        continuous_names=continuous_names,
        categorical_names=train_x.categorical_names,
        cardinalities=train_x.categorical_cardinalities,
        feature_processor=feature_processor,
        representation_processor=representation_processor,
        target_processor=target_processor,
    )


def build_theory_groups(continuous_names: Sequence[str], categorical_names: Sequence[str]) -> dict[str, list[int]]:
    """依据字段语义创建理论组；PLE基函数继承原连续字段所属组。"""

    ability = set(DATA.INITIAL_ABILITY)
    school = set(DATA.ENVIRONMENT)
    household = set(DATA.HOUSEHOLD)
    assets = set(DATA.ASSETS)
    groups = {
        "入学能力": [],
        "数字可及性": [],
        "学校与专业环境": [],
        "家庭社会经济背景": [],
        "家庭物质资本": [],
    }
    all_names = [*continuous_names, *categorical_names]
    for index, name in enumerate(all_names):
        base = name.split("__", 1)[0]
        if base in ability:
            groups["入学能力"].append(index)
        elif base == "DAI":
            groups["数字可及性"].append(index)
        elif base in school:
            groups["学校与专业环境"].append(index)
        elif base in household:
            groups["家庭社会经济背景"].append(index)
        elif base in assets:
            groups["家庭物质资本"].append(index)
        else:
            raise ValueError(f"特征尚未分配理论组：{name}")
    if any(not indices for indices in groups.values()):
        raise ValueError(f"存在空理论组：{groups}")
    return groups


def _array_list(value: Any) -> list[Any]:
    """将NumPy/张量状态转换为可安全写入检查点的普通列表。"""

    if isinstance(value, Tensor):
        value = value.detach().cpu().numpy()
    return np.asarray(value).tolist()


def export_preprocessing_state(split: PreparedSplit, representation: str) -> dict[str, Any]:
    """导出外层训练折拟合状态，保证模型权重可复核和解释。"""

    feature = split.feature_processor
    target = split.target_processor
    indicator_features = getattr(feature.numeric_imputer.indicator_, "features_", [])
    ple_edges = None
    if split.representation_processor is not None:
        ple_edges = [
            None if edges is None else _array_list(edges)
            for edges in split.representation_processor.edges_
        ]
    return {
        "状态版本": 1,
        "连续编码": representation,
        "原始连续字段": list(DATA.CONTINUOUS_INPUTS),
        "原始类别字段": list(DATA.CATEGORICAL_INPUTS),
        "模型连续字段": list(split.continuous_names),
        "模型类别字段": list(split.categorical_names),
        "连续插补中位数": _array_list(feature.numeric_imputer.statistics_),
        "连续缺失指示字段索引": _array_list(indicator_features),
        "连续标准化均值": _array_list(feature.numeric_scaler.mean_),
        "连续标准化尺度": _array_list(feature.numeric_scaler.scale_),
        "类别词表": [_array_list(values) for values in feature.category_encoder.categories_],
        "类别基数": list(split.cardinalities),
        "PLE节点": ple_edges,
        "非英语PC1输入标准化均值": _array_list(target.pc_scaler.mean_),
        "非英语PC1输入标准化尺度": _array_list(target.pc_scaler.scale_),
        "非英语PC1载荷": _array_list(target.pca.components_),
        "非英语PC1解释方差比例": _array_list(target.pca.explained_variance_ratio_),
        "非英语PC1方向": float(target.pc_sign),
        "三任务标准化均值": _array_list(target.target_scaler.mean_),
        "三任务标准化尺度": _array_list(target.target_scaler.scale_),
        "英语低表现阈值": float(target.risk_threshold),
    }


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class StudentDataset(Dataset):
    def __init__(
        self,
        continuous: np.ndarray,
        categorical: np.ndarray,
        targets: np.ndarray,
        risks: np.ndarray,
    ) -> None:
        lengths = {len(continuous), len(categorical), len(targets), len(risks)}
        if len(lengths) != 1:
            raise ValueError("数据集各数组行数不一致")
        self.continuous = torch.as_tensor(continuous, dtype=torch.float32)
        self.categorical = torch.as_tensor(categorical, dtype=torch.long)
        self.targets = torch.as_tensor(targets, dtype=torch.float32)
        self.risks = torch.as_tensor(risks, dtype=torch.bool)

    def __len__(self) -> int:
        return len(self.targets)

    def __getitem__(self, index: int) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        return (
            self.continuous[index], self.categorical[index],
            self.targets[index], self.risks[index],
        )


class ProtocolLoss(nn.Module):
    """M0--M3预注册训练目标；选择指标始终独立计算。"""

    def __init__(self, config: LossConfig) -> None:
        super().__init__()
        if config.protocol not in {"M0", "M1", "M2", "M3"}:
            raise ValueError("训练目标只能是 M0、M1、M2 或 M3")
        self.config = config
        weights = torch.tensor(config.task_weights, dtype=torch.float32)
        if weights.shape != (3,) or bool((weights < 0).any()) or float(weights.sum()) <= 0.0:
            raise ValueError("三个任务权重必须非负且总和为正")
        self.register_buffer("task_weights", weights / weights.sum())

    def _pairwise_rank(self, prediction: Tensor, target: Tensor) -> Tensor:
        count = len(target)
        if count < 2:
            return prediction.new_zeros(())
        row, column = torch.triu_indices(count, count, offset=1, device=target.device)
        target_difference = target[row] - target[column]
        usable = target_difference.abs() > 0.05
        direction = target_difference.sign()
        predicted_difference = prediction[row] - prediction[column]
        pair_loss = F.softplus(
            -direction * predicted_difference / self.config.rank_temperature
        ) * usable.to(prediction.dtype)
        return pair_loss.sum() / usable.sum().clamp_min(1).to(prediction.dtype)

    def forward(self, prediction: Tensor, target: Tensor, risk: Tensor) -> Tensor:
        if prediction.shape != target.shape or prediction.shape[1] != 3:
            raise ValueError("预测和目标必须为 [batch, 3]")
        if self.config.protocol in {"M0", "M2"}:
            per_sample = (prediction - target).square()
        else:
            per_sample = F.huber_loss(
                prediction, target, delta=self.config.huber_delta, reduction="none"
            )
        if self.config.protocol == "M3":
            english_weight = torch.where(
                risk, prediction.new_tensor(self.config.risk_weight), prediction.new_tensor(1.0)
            )
            english = (per_sample[:, 0] * english_weight).sum() / english_weight.sum()
            task_losses = torch.stack([english, per_sample[:, 1].mean(), per_sample[:, 2].mean()])
        else:
            task_losses = per_sample.mean(dim=0)
        total = torch.sum(self.task_weights.to(prediction) * task_losses)
        if self.config.protocol in {"M2", "M3"}:
            total = total + self.config.rank_weight * self._pairwise_rank(
                prediction[:, 0], target[:, 0]
            )
        return total


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_loader(dataset: Dataset, config: TrainConfig, shuffle: bool, seed: int) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=shuffle,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
        generator=generator,
    )


@dataclass
class FitResult:
    best_epoch: int
    best_score: float
    history: list[dict[str, float]]
    elapsed_seconds: float
    peak_gpu_memory_mb: float


@torch.inference_mode()
def validation_score(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    task_weights: Sequence[float] = TASK_WEIGHTS,
) -> float:
    model.eval()
    squared_error: Tensor | None = None
    seen = 0
    for continuous, categorical, target, _ in loader:
        target = target.to(device, non_blocking=True)
        prediction = model(
            continuous.to(device, non_blocking=True),
            categorical.to(device, non_blocking=True),
        )
        batch_error = (prediction - target).to(torch.float64).square().sum(dim=0)
        squared_error = batch_error if squared_error is None else squared_error + batch_error
        seen += len(target)
    if squared_error is None or seen == 0:
        raise RuntimeError("验证集为空")
    weights = squared_error.new_tensor(task_weights)
    weights = weights / weights.sum().clamp_min(1.0e-12)
    return float(torch.sum(weights * torch.sqrt(squared_error / seen)).cpu())


def fit_model(
    model: nn.Module,
    train_data: StudentDataset,
    validation_data: StudentDataset | None,
    train_config: TrainConfig,
    loss_config: LossConfig,
    seed: int,
    device: torch.device,
) -> FitResult:
    set_seed(seed)
    model.to(device)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
        torch.cuda.synchronize(device)
    fit_started = time.perf_counter()
    criterion = ProtocolLoss(loss_config).to(device)
    train_loader = make_loader(train_data, train_config, True, seed)
    validation_loader = (
        make_loader(validation_data, train_config, False, seed + 1)
        if validation_data is not None else None
    )
    optimizer_kwargs: dict[str, Any] = {
        "lr": train_config.learning_rate,
        "weight_decay": train_config.weight_decay,
    }
    if device.type == "cuda":
        optimizer_kwargs["fused"] = True
    try:
        optimizer = torch.optim.AdamW(model.parameters(), **optimizer_kwargs)
    except (RuntimeError, TypeError):
        optimizer_kwargs.pop("fused", None)
        optimizer = torch.optim.AdamW(model.parameters(), **optimizer_kwargs)

    warmup = min(train_config.warmup_epochs, max(0, train_config.max_epochs - 1))
    if warmup:
        scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[
                torch.optim.lr_scheduler.LinearLR(
                    optimizer, start_factor=1.0 / max(2, warmup), total_iters=warmup
                ),
                torch.optim.lr_scheduler.CosineAnnealingLR(
                    optimizer,
                    T_max=max(1, train_config.max_epochs - warmup),
                    eta_min=train_config.learning_rate * 0.01,
                ),
            ],
            milestones=[warmup],
        )
    else:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(1, train_config.max_epochs),
            eta_min=train_config.learning_rate * 0.01,
        )
    amp_enabled = train_config.use_amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    best_score, best_epoch, stale = math.inf, 0, 0
    best_state: dict[str, Tensor] | None = None
    history: list[dict[str, float]] = []

    for epoch in range(1, train_config.max_epochs + 1):
        model.train()
        running = torch.zeros((), dtype=torch.float64, device=device)
        seen = 0
        for continuous, categorical, target, risk in train_loader:
            continuous = continuous.to(device, non_blocking=True)
            categorical = categorical.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            risk = risk.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=amp_enabled):
                prediction = model(continuous, categorical)
                loss = criterion(prediction, target, risk)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), train_config.gradient_clip)
            scaler.step(optimizer)
            scaler.update()
            running.add_(loss.detach().to(torch.float64) * len(target))
            seen += len(target)
        score = (
            validation_score(model, validation_loader, device, loss_config.task_weights)
            if validation_loader is not None else math.nan
        )
        history.append(
            {
                "epoch": float(epoch),
                "train_loss": float((running / max(1, seen)).cpu()),
                "validation_weighted_rmse_std": score,
                "learning_rate": float(optimizer.param_groups[0]["lr"]),
            }
        )
        scheduler.step()
        if validation_loader is None:
            best_epoch = epoch
            continue
        if score < best_score - train_config.min_delta:
            best_score, best_epoch, stale = score, epoch, 0
            best_state = {
                name: value.detach().cpu().clone() for name, value in model.state_dict().items()
            }
        else:
            stale += 1
        if stale >= train_config.patience:
            break

    if validation_loader is not None:
        if best_state is None:
            raise RuntimeError("训练没有产生有效检查点")
        model.load_state_dict(best_state)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
        peak_memory = torch.cuda.max_memory_allocated(device) / (1024.0 ** 2)
    else:
        peak_memory = 0.0
    return FitResult(
        best_epoch=best_epoch,
        best_score=best_score,
        history=history,
        elapsed_seconds=time.perf_counter() - fit_started,
        peak_gpu_memory_mb=float(peak_memory),
    )


@torch.inference_mode()
def predict(model: nn.Module, dataset: StudentDataset, config: TrainConfig, device: torch.device) -> np.ndarray:
    model.eval()
    output = []
    for continuous, categorical, _, _ in make_loader(dataset, config, False, seed=0):
        output.append(model(continuous.to(device), categorical.to(device)).cpu().numpy())
    return np.concatenate(output, axis=0)


def make_dataset(
    continuous: np.ndarray, categorical: np.ndarray, target: np.ndarray, risk: np.ndarray
) -> StudentDataset:
    return StudentDataset(continuous, categorical, target, risk)


def make_model(
    split: PreparedSplit,
    config: ModelConfig,
    flags: AblationFlags | None = None,
) -> nn.Module:
    groups = build_theory_groups(split.continuous_names, split.categorical_names)
    return build_model(
        len(split.continuous_names), split.cardinalities, groups,
        config=config, flags=flags,
    )


def university_validation_split(frame: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    splitter = GroupShuffleSplit(
        n_splits=1, test_size=SELECTION_FRACTION, random_state=seed
    )
    train_index, validation_index = next(
        splitter.split(frame, groups=frame[DATA.GROUP_COLUMN].astype(str))
    )
    train = frame.iloc[train_index].copy()
    validation = frame.iloc[validation_index].copy()
    if set(train[DATA.GROUP_COLUMN]).intersection(validation[DATA.GROUP_COLUMN]):
        raise RuntimeError("内部早停划分发生高校泄漏")
    return train, validation


def suggested_configs(trial: Any, base_model: ModelConfig, base_train: TrainConfig) -> tuple[ModelConfig, TrainConfig]:
    d_model = trial.suggest_categorical("d_model", [64, 96, 128, 160, 192])
    heads = trial.suggest_categorical("num_heads", [4, 8])
    if d_model % heads:
        raise RuntimeError("搜索空间产生不可整除的 d_model/num_heads")
    return (
        replace(
            base_model,
            d_model=d_model,
            num_heads=heads,
            num_layers=trial.suggest_int("num_layers", 2, 5),
            ff_ratio=trial.suggest_int("ff_ratio", 2, 6),
            dropout=trial.suggest_float("dropout", 0.02, 0.35),
            topk_ratio=trial.suggest_float("topk_ratio", 0.25, 0.80),
            topk_temperature=trial.suggest_float("topk_temperature", 0.35, 1.50, log=True),
            head_hidden=trial.suggest_categorical("head_hidden", [64, 96, 128, 192, 256]),
        ),
        replace(
            base_train,
            batch_size=trial.suggest_categorical("batch_size", [128, 256, 512]),
            learning_rate=trial.suggest_float("learning_rate", 1.0e-5, 2.0e-3, log=True),
            weight_decay=trial.suggest_float("weight_decay", 1.0e-7, 1.0e-2, log=True),
            gradient_clip=trial.suggest_float("gradient_clip", 0.5, 5.0, log=True),
        ),
    )


def tune_outer_fold(
    outer_train: pd.DataFrame,
    outer_fold: int,
    representation: str,
    loss_config: LossConfig,
    base_model: ModelConfig,
    base_train: TrainConfig,
    trials: int,
    device: torch.device,
) -> tuple[ModelConfig, TrainConfig, dict[str, Any]]:
    """只在外层训练高校内部执行3折TPE寻优。"""

    if trials <= 0:
        return base_model, base_train, {"enabled": False}
    try:
        import optuna
    except ImportError as exc:
        raise RuntimeError("启用寻优需要安装 optuna") from exc
    groups = outer_train[DATA.GROUP_COLUMN].astype(str).to_numpy()
    inner_splits = list(GroupKFold(n_splits=3).split(outer_train, groups=groups))
    cached_inner: list[tuple[PreparedSplit, StudentDataset, StudentDataset]] = []
    for train_index, validation_index in inner_splits:
        split = prepare_split(
            outer_train.iloc[train_index], outer_train.iloc[validation_index], representation
        )
        cached_inner.append(
            (
                split,
                make_dataset(
                    split.train_continuous, split.train_categorical,
                    split.train_target, split.train_risk,
                ),
                make_dataset(
                    split.other_continuous, split.other_categorical,
                    split.other_target, split.other_risk,
                ),
            )
        )

    def objective(trial: Any) -> float:
        model_config, train_config = suggested_configs(trial, base_model, base_train)
        trial_train = replace(
            train_config,
            max_epochs=min(120, train_config.max_epochs),
            patience=min(18, train_config.patience),
            warmup_epochs=min(5, train_config.warmup_epochs),
        )
        scores = []
        for inner_fold, (split, train_dataset, validation_dataset) in enumerate(
            cached_inner, start=1
        ):
            trial_seed = 2027 + trial.number * 100 + inner_fold
            set_seed(trial_seed)
            model = make_model(split, model_config)
            result = fit_model(
                model,
                train_dataset,
                validation_dataset,
                trial_train,
                loss_config,
                seed=trial_seed,
                device=device,
            )
            scores.append(result.best_score)
            trial.report(float(np.mean(scores)), inner_fold)
            if trial.should_prune():
                raise optuna.TrialPruned()
        return float(np.mean(scores))

    study = optuna.create_study(
        direction="minimize",
        sampler=optuna.samplers.TPESampler(
            seed=2027 + outer_fold, n_startup_trials=min(8, trials), multivariate=True
        ),
        pruner=optuna.pruners.MedianPruner(n_startup_trials=min(8, trials), n_warmup_steps=1),
    )
    study.optimize(objective, n_trials=trials, show_progress_bar=False, gc_after_trial=True)
    best_model, best_train = suggested_configs(study.best_trial, base_model, base_train)
    summary = {
        "enabled": True,
        "outer_fold": outer_fold,
        "best_trial": int(study.best_trial.number),
        "best_value": float(study.best_value),
        "best_params": study.best_params,
        "n_trials": len(study.trials),
        "trials": [
            {
                "number": int(item.number),
                "state": item.state.name,
                "value": None if item.value is None else float(item.value),
                "params": dict(item.params),
            }
            for item in study.trials
        ],
    }
    return best_model, best_train, summary


def load_protocol_data() -> pd.DataFrame:
    if not DATA_FILE.is_file() or not FOLD_FILE.is_file():
        raise FileNotFoundError("缺少01阶段输出；请先完成数据与预处理")
    frame = pd.read_csv(DATA_FILE, encoding="utf-8-sig")
    folds = pd.read_csv(FOLD_FILE, encoding="utf-8-sig")
    required = {DATA.SAMPLE_ID, DATA.GROUP_COLUMN, *DATA.MODEL_INPUTS, *DATA.MODEL_TARGET_COLUMNS}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"模型输入基础数据缺少字段：{missing}")
    if folds[DATA.SAMPLE_ID].duplicated().any() or frame[DATA.SAMPLE_ID].duplicated().any():
        raise ValueError("样本编号不唯一")
    merged = frame.merge(
        folds[[DATA.SAMPLE_ID, DATA.GROUP_COLUMN, "外层测试折"]],
        on=[DATA.SAMPLE_ID, DATA.GROUP_COLUMN], how="left", validate="one_to_one",
    )
    if merged["外层测试折"].isna().any() or set(merged["外层测试折"]) != {1, 2, 3, 4, 5}:
        raise ValueError("五折高校划分不完整")
    counts = merged.groupby(DATA.GROUP_COLUMN, observed=True)["外层测试折"].nunique()
    if not counts.eq(1).all():
        raise ValueError("同一高校出现在多个外层测试折")
    return merged


def inverse_targets(processor: Any, standardized: np.ndarray) -> np.ndarray:
    return processor.target_scaler.inverse_transform(standardized).astype(np.float32)


def calculate_metrics(raw_true: np.ndarray, raw_prediction: np.ndarray) -> list[dict[str, float | str]]:
    rows: list[dict[str, float | str]] = []
    for index, task in enumerate(DATA.FoldTargetPreprocessor.task_names):
        truth, prediction = raw_true[:, index], raw_prediction[:, index]
        rows.append(
            {
                "任务": task,
                "RMSE": float(mean_squared_error(truth, prediction) ** 0.5),
                "MAE": float(mean_absolute_error(truth, prediction)),
                "R2": float(r2_score(truth, prediction)),
            }
        )
    return rows


def fit_risk_calibrator(risk_score: np.ndarray, risk_label: np.ndarray) -> dict[str, float | str]:
    """仅用内部验证高校拟合英语低表现概率校准器。"""

    labels = np.asarray(risk_label, dtype=int)
    scores = np.asarray(risk_score, dtype=float).reshape(-1, 1)
    if np.unique(labels).size < 2:
        return {"method": "constant", "probability": float(labels.mean())}
    calibrator = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
    calibrator.fit(scores, labels)
    return {
        "method": "logistic_internal_validation",
        "coefficient": float(calibrator.coef_[0, 0]),
        "intercept": float(calibrator.intercept_[0]),
    }


def apply_risk_calibrator(state: dict[str, float | str], risk_score: np.ndarray) -> np.ndarray:
    if state["method"] == "constant":
        return np.full(len(risk_score), float(state["probability"]), dtype=np.float64)
    linear = float(state["coefficient"]) * np.asarray(risk_score) + float(state["intercept"])
    positive = linear >= 0
    probability = np.empty_like(linear, dtype=np.float64)
    probability[positive] = 1.0 / (1.0 + np.exp(-linear[positive]))
    negative_exp = np.exp(linear[~positive])
    probability[~positive] = negative_exp / (1.0 + negative_exp)
    return probability


def run_training(args: argparse.Namespace) -> None:
    if args.confirm_training != CONFIRMATION_TEXT:
        raise RuntimeError(
            f"训练被安全锁阻止；确需运行时添加 --confirm-training {CONFIRMATION_TEXT}"
        )
    frame = load_protocol_data()
    seeds = tuple(int(value) for value in args.seeds.split(",") if value.strip())
    if not seeds:
        raise ValueError("至少指定一个随机种子")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.set_float32_matmul_precision("high")
    model_config = ModelConfig(variant=args.architecture)
    train_config = TrainConfig(max_epochs=args.max_epochs, patience=args.patience)
    loss_config = LossConfig(protocol=args.objective)
    representation_label = {"raw": "raw_continuous_encoding", "ple16": "ple16_encoding"}[args.representation]
    architecture_label = {"v1": "", "v2": "v2_soft_threshold_gating_"}[args.architecture]
    prefix = f"{architecture_label}{args.objective}_{representation_label}"
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    started_at = datetime.now(timezone.utc).astimezone()
    start_time = time.time()
    prediction_rows: list[pd.DataFrame] = []
    metric_rows: list[dict[str, Any]] = []
    tuning_rows: list[dict[str, Any]] = []
    history_rows: list[dict[str, Any]] = []
    efficiency_rows: list[dict[str, Any]] = []

    for outer_fold in range(1, 6):
        outer_test = frame.loc[frame["外层测试折"] == outer_fold].copy()
        outer_train = frame.loc[frame["外层测试折"] != outer_fold].copy()
        selected_model, selected_train, tuning = tune_outer_fold(
            outer_train, outer_fold, args.representation, loss_config,
            model_config, train_config, args.tune_trials, device,
        )
        tuning_rows.append(tuning)
        # 外层完整训练/测试处理与随机种子无关，只拟合一次并供所有种子复用。
        full = prepare_split(outer_train, outer_test, args.representation)
        full_train_dataset = make_dataset(
            full.train_continuous, full.train_categorical,
            full.train_target, full.train_risk,
        )
        full_test_dataset = make_dataset(
            full.other_continuous, full.other_categorical,
            full.other_target, full.other_risk,
        )
        for seed in seeds:
            selection_train, selection_validation = university_validation_split(outer_train, seed)
            selection = prepare_split(selection_train, selection_validation, args.representation)
            set_seed(seed)
            selection_model = make_model(selection, selected_model)
            selected = fit_model(
                selection_model,
                make_dataset(selection.train_continuous, selection.train_categorical, selection.train_target, selection.train_risk),
                make_dataset(selection.other_continuous, selection.other_categorical, selection.other_target, selection.other_risk),
                selected_train,
                loss_config,
                seed,
                device,
            )

            selection_validation_data = make_dataset(
                selection.other_continuous,
                selection.other_categorical,
                selection.other_target,
                selection.other_risk,
            )
            selection_prediction_std = predict(
                selection_model, selection_validation_data, selected_train, device
            )
            selection_prediction_raw = inverse_targets(
                selection.target_processor, selection_prediction_std
            )
            calibration_labels = (
                selection_validation["大学英语成绩"].to_numpy(dtype=float)
                <= full.target_processor.risk_threshold
            ).astype(np.int8)
            risk_calibrator = fit_risk_calibrator(
                -selection_prediction_raw[:, 0], calibration_labels
            )
            refit_config = replace(
                selected_train,
                max_epochs=max(1, selected.best_epoch),
                patience=max(1, selected.best_epoch + 1),
                warmup_epochs=min(selected_train.warmup_epochs, max(0, selected.best_epoch - 1)),
            )
            set_seed(seed)
            final_model = make_model(full, selected_model)
            refitted = fit_model(
                final_model,
                full_train_dataset,
                None,
                refit_config,
                loss_config,
                seed,
                device,
            )
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            inference_started = time.perf_counter()
            standardized_prediction = predict(
                final_model,
                full_test_dataset,
                refit_config,
                device,
            )
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            inference_seconds = time.perf_counter() - inference_started
            raw_prediction = inverse_targets(full.target_processor, standardized_prediction)
            risk_score = -raw_prediction[:, 0]
            risk_probability = apply_risk_calibrator(risk_calibrator, risk_score)
            checkpoint = OUTPUT_DIR / f"{prefix}_fold_{outer_fold}_seed_{seed}_model.pt"
            torch.save(
                {
                    "checkpoint_format_version": 1,
                    "model_state": {k: v.detach().cpu() for k, v in final_model.state_dict().items()},
                    "model_config": asdict(selected_model),
                    "train_config": asdict(refit_config),
                    "loss_config": asdict(loss_config),
                    "preprocessing_state": export_preprocessing_state(full, args.representation),
                    "theory_groups": build_theory_groups(full.continuous_names, full.categorical_names),
                    "risk_calibrator": risk_calibrator,
                    "outer_fold": outer_fold,
                    "seed": seed,
                    "best_epoch_from_inner_validation": selected.best_epoch,
                },
                checkpoint,
            )
            fold_prediction = outer_test[
                [DATA.SAMPLE_ID, DATA.GROUP_COLUMN, *DATA.AUDIT_COLUMNS]
            ].copy()
            fold_prediction["外层测试折"] = outer_fold
            fold_prediction["随机种子"] = seed
            for task_index, task_name in enumerate(DATA.FoldTargetPreprocessor.task_names):
                fold_prediction[f"{task_name}_真实值"] = full.other_target_raw[:, task_index]
                fold_prediction[f"{task_name}_预测值"] = raw_prediction[:, task_index]
                fold_prediction[f"{task_name}_标准化真实值"] = full.other_target[:, task_index]
                fold_prediction[f"{task_name}_标准化预测值"] = standardized_prediction[:, task_index]
            fold_prediction["低表现真实标签"] = full.other_risk
            fold_prediction["低表现风险分数"] = risk_score
            fold_prediction["低表现校准概率"] = risk_probability
            fold_prediction["训练折英语风险阈值"] = full.target_processor.risk_threshold
            prediction_rows.append(fold_prediction)
            for row in calculate_metrics(full.other_target_raw, raw_prediction):
                metric_rows.append(
                    {"外层测试折": outer_fold, "随机种子": seed, **row,
                     "最佳早停轮次": selected.best_epoch}
                )
            for phase, result in (("内部早停", selected), ("完整外层训练折重拟合", refitted)):
                for history_row in result.history:
                    history_rows.append(
                        {
                            "外层测试折": outer_fold,
                            "随机种子": seed,
                            "阶段": phase,
                            **history_row,
                        }
                    )
            parameter_count = sum(parameter.numel() for parameter in final_model.parameters())
            trainable_count = sum(
                parameter.numel() for parameter in final_model.parameters() if parameter.requires_grad
            )
            efficiency_rows.append(
                {
                    "外层测试折": outer_fold,
                    "随机种子": seed,
                    "模型参数量": parameter_count,
                    "可训练参数量": trainable_count,
                    "最佳早停轮次": selected.best_epoch,
                    "内部早停耗时秒": selected.elapsed_seconds,
                    "完整训练折重拟合耗时秒": refitted.elapsed_seconds,
                    "峰值GPU显存MB": max(
                        selected.peak_gpu_memory_mb, refitted.peak_gpu_memory_mb
                    ),
                    "测试样本数": len(outer_test),
                    "测试集推理耗时秒": inference_seconds,
                    "单样本推理毫秒": inference_seconds * 1000.0 / len(outer_test),
                }
            )

    elapsed = time.time() - start_time
    predictions = pd.concat(prediction_rows, ignore_index=True)
    predictions.to_csv(
        OUTPUT_DIR / f"{prefix}_oof_predictions.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(metric_rows).to_csv(
        OUTPUT_DIR / f"{prefix}_fold_metrics.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(history_rows).to_csv(
        OUTPUT_DIR / f"{prefix}_training_history.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(efficiency_rows).to_csv(
        OUTPUT_DIR / f"{prefix}_training_inference_efficiency.csv", index=False, encoding="utf-8-sig"
    )

    prediction_columns = [
        column for column in predictions.columns
        if column.endswith("_预测值") or column.endswith("_标准化预测值")
    ] + ["低表现风险分数", "低表现校准概率"]
    group_keys = [DATA.SAMPLE_ID, "外层测试折"]
    grouped = predictions.groupby(group_keys, observed=True, sort=False)
    ensemble_mean = grouped[prediction_columns].mean().add_suffix("_集成均值")
    ensemble_std = grouped[prediction_columns].std(ddof=0).add_suffix("_种子标准差")
    metadata_columns = [
        DATA.GROUP_COLUMN, *DATA.AUDIT_COLUMNS,
        *[column for column in predictions.columns if column.endswith("_真实值")],
        "低表现真实标签", "训练折英语风险阈值",
    ]
    ensemble = grouped[metadata_columns].first().join(ensemble_mean).join(ensemble_std).reset_index()
    ensemble.to_csv(
        OUTPUT_DIR / f"{prefix}_three_seed_ensemble_oof_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    trial_rows: list[dict[str, Any]] = []
    for tuning in tuning_rows:
        for trial in tuning.get("trials", []):
            trial_rows.append(
                {
                    "外层测试折": tuning.get("outer_fold"),
                    "试验编号": trial["number"],
                    "状态": trial["state"],
                    "目标值": trial["value"],
                    **{f"参数_{key}": value for key, value in trial["params"].items()},
                }
            )
    if trial_rows:
        pd.DataFrame(trial_rows).to_csv(
            OUTPUT_DIR / f"{prefix}_optuna_optimization_trace.csv", index=False, encoding="utf-8-sig"
        )

    finished_at = datetime.now(timezone.utc).astimezone()
    gpu_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    manifest = {
        "清单版本": 1,
        "研究协议": prefix,
        "开始时间": started_at.isoformat(),
        "结束时间": finished_at.isoformat(),
        "随机种子": list(seeds),
        "外层验证": "固定5折高校隔离",
        "内部验证": "高校分组15%早停",
        "寻优试验数_每个外层折": args.tune_trials,
        "设备": str(device),
        "GPU": gpu_name,
        "总耗时秒": elapsed,
        "软件环境": {
            "Python": platform.python_version(),
            "PyTorch": torch.__version__,
            "CUDA": torch.version.cuda,
            "NumPy": np.__version__,
            "pandas": pd.__version__,
            "scikit-learn": sklearn.__version__,
        },
        "输入文件SHA256": {
            DATA_FILE.name: file_sha256(DATA_FILE),
            FOLD_FILE.name: file_sha256(FOLD_FILE),
            "model.py": file_sha256(HERE / "model.py"),
            "train_main.py": file_sha256(HERE / "train_main.py"),
        },
        "基础模型配置": asdict(model_config),
        "基础训练配置": asdict(train_config),
        "损失配置": asdict(loss_config),
        "寻优摘要": tuning_rows,
    }
    (OUTPUT_DIR / f"{prefix}_run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def check_protocol(args: argparse.Namespace) -> None:
    frame = load_protocol_data()
    fold_sizes = frame.groupby("外层测试折", observed=True).size().to_dict()
    university_counts = frame.groupby("外层测试折", observed=True)[DATA.GROUP_COLUMN].nunique().to_dict()
    print("主模型训练协议检查通过（未训练）")
    print(f"样本数={len(frame)}, 高校数={frame[DATA.GROUP_COLUMN].nunique()}")
    print(f"各折样本数={fold_sizes}")
    print(f"各折高校数={university_counts}")
    print(
        f"模型版本={args.architecture}, 连续编码={args.representation}, "
        f"训练目标={args.objective}"
    )
    print("训练安全锁=开启；只有 train + --confirm-training TRAIN 才会启动训练")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=["check", "train"], default="check")
    parser.add_argument("--representation", choices=["raw", "ple16"], default="raw")
    parser.add_argument("--architecture", choices=["v1", "v2"], default="v1")
    parser.add_argument("--objective", choices=["M0", "M1", "M2", "M3"], default="M0")
    parser.add_argument("--seeds", default="42,3407,2027")
    parser.add_argument("--max-epochs", type=int, default=300)
    parser.add_argument("--patience", type=int, default=45)
    parser.add_argument("--tune-trials", type=int, default=0)
    parser.add_argument("--confirm-training", default="")
    args = parser.parse_args()
    if args.max_epochs <= 0 or args.patience <= 0 or args.tune_trials < 0:
        parser.error("轮数和耐心必须为正，寻优次数不能为负")
    return args


def main() -> None:
    args = parse_args()
    if args.command == "check":
        check_protocol(args)
    else:
        run_training(args)


if __name__ == "__main__":
    main()
