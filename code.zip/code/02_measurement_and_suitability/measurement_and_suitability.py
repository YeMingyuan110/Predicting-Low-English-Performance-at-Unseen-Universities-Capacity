"""建模前统计、教育测量与数据适用性检验。

本文件不训练论文模型，也不改变模型输入。它读取第01阶段已经确定性清洗的
基础数据和固定高校折，在一个Excel工作簿中输出论文所需的统计表。所有PC1
和训练/测试比较均按照外层训练高校重新拟合，避免全样本信息泄漏。
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from scipy.stats import chi2, kurtosis, skew, spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT.parent / "01_data_preprocessing" / "output"
DEFAULT_DATA = DATA_ROOT / "model_input_data.csv"
DEFAULT_FOLDS = DATA_ROOT / "university_five_fold_assignment.csv"
OUTPUT_DIR = ROOT / "output"
OUTPUT_FILE = "01_pre_modeling_statistics_and_tests.xlsx"

SAMPLE_ID = "样本编号"
GROUP_COLUMN = "高校名称"
FOLD_COLUMN = "外层测试折"
MISSING_TOKEN = "__MISSING__"

INITIAL_ABILITY = [
    "高中数学成绩", "高中批判性阅读成绩", "高中公民素养成绩", "高中生物成绩", "高中英语成绩"
]
CONTINUOUS_INPUTS = [*INITIAL_ABILITY, "DAI"]
ENVIRONMENT = ["高中学校性质", "高中学校类型", "工程专业"]
HOUSEHOLD = [
    "父亲受教育程度", "母亲受教育程度", "父亲职业", "母亲职业", "家庭社会经济阶层",
    "SISBEN社会福利等级", "家庭收入", "家庭人口数", "学生就业情况",
]
ASSETS = ["电视", "洗衣机", "微波炉", "汽车", "DVD设备", "冰箱", "固定电话"]
CATEGORICAL_INPUTS = [*ENVIRONMENT, *HOUSEHOLD, *ASSETS]
MODEL_INPUTS = [*CONTINUOUS_INPUTS, *CATEGORICAL_INPUTS]
NON_ENGLISH_TARGETS = ["大学定量推理成绩", "大学批判性阅读成绩", "大学公民素养成绩"]
TARGETS = [*NON_ENGLISH_TARGETS, "大学英语成绩", "工程项目规划成绩"]
AUDIT_COLUMNS = ["性别", "学生社会经济水平", "高校社会经济水平"]


def load_inputs(data_path: Path, fold_path: Path) -> pd.DataFrame:
    data = pd.read_csv(data_path, encoding="utf-8-sig")
    folds = pd.read_csv(fold_path, encoding="utf-8-sig")
    required = {SAMPLE_ID, GROUP_COLUMN, *MODEL_INPUTS, *TARGETS, *AUDIT_COLUMNS}
    missing = sorted(required.difference(data.columns))
    if missing:
        raise ValueError(f"模型输入基础数据缺少字段: {missing}")
    if folds[SAMPLE_ID].duplicated().any() or data[SAMPLE_ID].duplicated().any():
        raise ValueError("样本编号必须唯一")
    fold_map = folds[[SAMPLE_ID, FOLD_COLUMN]].copy()
    frame = data.merge(fold_map, on=SAMPLE_ID, how="left", validate="one_to_one")
    if frame[FOLD_COLUMN].isna().any():
        raise ValueError("存在未分配外层折的样本")
    frame[FOLD_COLUMN] = frame[FOLD_COLUMN].astype(int)
    if len(MODEL_INPUTS) != 25 or set(TARGETS).intersection(MODEL_INPUTS):
        raise RuntimeError("固定25变量协议或结果隔离检查失败")
    return frame


def result_distribution(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, float | int | str]] = []
    for column in TARGETS:
        values = pd.to_numeric(frame[column], errors="raise").to_numpy(float)
        minimum, maximum = float(values.min()), float(values.max())
        row: dict[str, float | int | str] = {
            "结果变量": column,
            "样本量": len(values),
            "均值": float(values.mean()),
            "标准差": float(values.std(ddof=1)),
            "最小值": minimum,
            "P01": float(np.quantile(values, 0.01)),
            "P05": float(np.quantile(values, 0.05)),
            "P10": float(np.quantile(values, 0.10)),
            "P25": float(np.quantile(values, 0.25)),
            "中位数": float(np.quantile(values, 0.50)),
            "P75": float(np.quantile(values, 0.75)),
            "P90": float(np.quantile(values, 0.90)),
            "P95": float(np.quantile(values, 0.95)),
            "P99": float(np.quantile(values, 0.99)),
            "最大值": maximum,
            "偏度": float(skew(values, bias=False)),
            "超额峰度": float(kurtosis(values, fisher=True, bias=False)),
            "地板比例": float(np.mean(values == minimum)),
            "天花板比例": float(np.mean(values == maximum)),
        }
        rows.append(row)
    return pd.DataFrame(rows)


def icc_one_way(values: Iterable[float], groups: Iterable[object]) -> dict[str, float | int]:
    work = pd.DataFrame({"值": values, "组": groups}).dropna()
    grouped = work.groupby("组", observed=True)["值"]
    counts = grouped.size().to_numpy(float)
    means = grouped.mean().to_numpy(float)
    grand = float(work["值"].mean())
    cluster_count, sample_count = len(counts), len(work)
    if cluster_count < 2 or sample_count <= cluster_count:
        raise ValueError("ICC至少需要两个非空高校")
    ss_between = float(np.sum(counts * (means - grand) ** 2))
    ss_within = float(grouped.apply(lambda part: ((part - part.mean()) ** 2).sum()).sum())
    ms_between = ss_between / (cluster_count - 1)
    ms_within = ss_within / (sample_count - cluster_count)
    n0 = (sample_count - np.sum(counts**2) / sample_count) / (cluster_count - 1)
    denominator = ms_between + (n0 - 1.0) * ms_within
    icc = (ms_between - ms_within) / denominator if denominator else np.nan
    mean_cluster_size = float(counts.mean())
    return {
        "样本量": sample_count,
        "高校数": cluster_count,
        "平均高校样本量": mean_cluster_size,
        "高校间均方": ms_between,
        "高校内均方": ms_within,
        "ICC1": float(icc),
        "设计效应": float(1.0 + (mean_cluster_size - 1.0) * max(float(icc), 0.0)),
    }


def university_heterogeneity(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    summary_rows = []
    for target in TARGETS:
        row = {"结果变量": target, **icc_one_way(frame[target], frame[GROUP_COLUMN])}
        summary_rows.append(row)

    english_q25 = float(frame["大学英语成绩"].quantile(0.25))
    detail = (
        frame.assign(描述性英语低表现=frame["大学英语成绩"].le(english_q25))
        .groupby(GROUP_COLUMN, observed=True)
        .agg(
            样本量=(SAMPLE_ID, "size"),
            英语均值=("大学英语成绩", "mean"),
            英语标准差=("大学英语成绩", "std"),
            英语最小值=("大学英语成绩", "min"),
            英语最大值=("大学英语成绩", "max"),
            描述性低表现率=("描述性英语低表现", "mean"),
        )
        .reset_index()
    )
    detail["描述性全样本P25阈值"] = english_q25
    detail["外层测试折"] = detail[GROUP_COLUMN].map(
        frame.groupby(GROUP_COLUMN, observed=True)[FOLD_COLUMN].first()
    )
    return pd.DataFrame(summary_rows), detail


def oriented_pc1(values: np.ndarray) -> tuple[np.ndarray, float, np.ndarray, np.ndarray]:
    scaler = StandardScaler().fit(values)
    scaled = scaler.transform(values)
    pca = PCA(n_components=1, random_state=42).fit(scaled)
    score = pca.transform(scaled)[:, 0]
    anchor = scaled.mean(axis=1)
    correlation = np.corrcoef(score, anchor)[0, 1]
    sign = -1.0 if np.isfinite(correlation) and correlation < 0 else 1.0
    loadings = pca.components_[0] * sign
    eigenvalues = np.linalg.eigvalsh(np.corrcoef(scaled, rowvar=False))[::-1]
    return score * sign, float(pca.explained_variance_ratio_[0]), loadings, eigenvalues


def kmo_and_bartlett(values: np.ndarray) -> tuple[float, float, int, float]:
    corr = np.corrcoef(values, rowvar=False)
    inv_corr = np.linalg.pinv(corr)
    scale = np.sqrt(np.outer(np.diag(inv_corr), np.diag(inv_corr)))
    partial = -inv_corr / scale
    np.fill_diagonal(partial, 0.0)
    corr_no_diag = corr.copy()
    np.fill_diagonal(corr_no_diag, 0.0)
    r2 = float(np.sum(corr_no_diag**2) / 2.0)
    p2 = float(np.sum(partial**2) / 2.0)
    kmo = r2 / (r2 + p2) if (r2 + p2) else np.nan
    n, p = values.shape
    determinant = max(float(np.linalg.det(corr)), np.finfo(float).tiny)
    statistic = -(n - 1.0 - (2.0 * p + 5.0) / 6.0) * np.log(determinant)
    degrees = p * (p - 1) // 2
    return float(kmo), float(statistic), int(degrees), float(chi2.sf(statistic, degrees))


def parallel_analysis(values: np.ndarray, repeats: int, rng: np.random.Generator) -> tuple[np.ndarray, int]:
    scaled = StandardScaler().fit_transform(values)
    observed = np.linalg.eigvalsh(np.corrcoef(scaled, rowvar=False))[::-1]
    null_eigenvalues = np.empty((repeats, scaled.shape[1]), dtype=float)
    for repeat in range(repeats):
        permuted = np.column_stack([rng.permutation(scaled[:, index]) for index in range(scaled.shape[1])])
        null_eigenvalues[repeat] = np.linalg.eigvalsh(np.corrcoef(permuted, rowvar=False))[::-1]
    null_p95 = np.quantile(null_eigenvalues, 0.95, axis=0)
    retained = int(np.sum(observed > null_p95))
    return null_p95, retained


def pc1_stability(
    frame: pd.DataFrame,
    bootstrap_repeats: int,
    parallel_repeats: int,
    seed: int,
) -> pd.DataFrame:
    all_values = frame[NON_ENGLISH_TARGETS].to_numpy(float)
    _, _, reference_loadings, _ = oriented_pc1(all_values)
    rows: list[dict[str, float | int]] = []

    for fold in sorted(frame[FOLD_COLUMN].unique()):
        train = frame.loc[frame[FOLD_COLUMN].ne(fold)].copy()
        values = train[NON_ENGLISH_TARGETS].to_numpy(float)
        _, explained, loadings, eigenvalues = oriented_pc1(values)
        kmo, bartlett, bartlett_df, bartlett_p = kmo_and_bartlett(values)
        fold_rng = np.random.default_rng(seed + int(fold))
        null_p95, retained = parallel_analysis(values, parallel_repeats, fold_rng)

        groups = train[GROUP_COLUMN].astype(str).to_numpy()
        unique_groups = np.unique(groups)
        group_indices = {group: np.flatnonzero(groups == group) for group in unique_groups}
        boot_loadings = np.empty((bootstrap_repeats, len(NON_ENGLISH_TARGETS)), dtype=float)
        for repeat in range(bootstrap_repeats):
            sampled_groups = fold_rng.choice(unique_groups, size=len(unique_groups), replace=True)
            indices = np.concatenate([group_indices[group] for group in sampled_groups])
            _, _, candidate_loadings, _ = oriented_pc1(values[indices])
            boot_loadings[repeat] = candidate_loadings

        congruence = float(np.dot(loadings, reference_loadings) / (
            np.linalg.norm(loadings) * np.linalg.norm(reference_loadings)
        ))
        row: dict[str, float | int] = {
            "外层测试折": int(fold),
            "训练样本量": len(train),
            "训练高校数": train[GROUP_COLUMN].nunique(),
            "PC1解释率": explained,
            "与全样本描述性载荷一致系数": congruence,
            "KMO": kmo,
            "Bartlett卡方": bartlett,
            "Bartlett自由度": bartlett_df,
            "Bartlett_P值": bartlett_p,
            "并行分析保留成分数": retained,
        }
        for index, column in enumerate(NON_ENGLISH_TARGETS):
            row[f"{column}_载荷"] = float(loadings[index])
            row[f"{column}_载荷CI下限"] = float(np.quantile(boot_loadings[:, index], 0.025))
            row[f"{column}_载荷CI上限"] = float(np.quantile(boot_loadings[:, index], 0.975))
            row[f"成分{index + 1}_观测特征值"] = float(eigenvalues[index])
            row[f"成分{index + 1}_随机P95特征值"] = float(null_p95[index])
        rows.append(row)
    return pd.DataFrame(rows)


def missing_mask(series: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(series):
        return series.isna()
    return series.isna() | series.astype("string").eq(MISSING_TOKEN) | series.astype("string").str.strip().eq("")


def missingness_tables(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    masks = pd.DataFrame({column: missing_mask(frame[column]) for column in MODEL_INPUTS})
    english = frame["大学英语成绩"].astype(float)
    summary_rows = []
    for column in MODEL_INPUTS:
        mask = masks[column]
        observed = english.loc[~mask]
        missing = english.loc[mask]
        pooled_sd = float(english.std(ddof=1))
        summary_rows.append({
            "变量": column,
            "缺失数": int(mask.sum()),
            "缺失率": float(mask.mean()),
            "缺失组英语均值": float(missing.mean()) if len(missing) else np.nan,
            "非缺失组英语均值": float(observed.mean()) if len(observed) else np.nan,
            "英语均值差_缺失减非缺失": float(missing.mean() - observed.mean()) if len(missing) else np.nan,
            "标准化均值差": float((missing.mean() - observed.mean()) / pooled_sd) if len(missing) and pooled_sd else np.nan,
        })

    row_missing_count = masks.sum(axis=1)
    count_distribution = (
        row_missing_count.value_counts().sort_index().rename_axis("每名学生缺失变量数")
        .reset_index(name="学生数")
    )
    count_distribution["比例"] = count_distribution["学生数"] / len(frame)

    any_missing = masks.any(axis=1)
    group_rows = []
    for group_column in [GROUP_COLUMN, *AUDIT_COLUMNS]:
        work = pd.DataFrame({"分组值": frame[group_column].astype("string"), "存在任一缺失": any_missing})
        grouped = work.groupby("分组值", observed=True)["存在任一缺失"].agg(["size", "mean"]).reset_index()
        grouped.insert(0, "分组变量", group_column)
        grouped = grouped.rename(columns={"size": "样本量", "mean": "任一缺失率"})
        group_rows.append(grouped)
    return pd.DataFrame(summary_rows), count_distribution, pd.concat(group_rows, ignore_index=True)


def corrected_cramers_v(left: pd.Series, right: pd.Series) -> float:
    table = pd.crosstab(left.astype("string"), right.astype("string"))
    observed = table.to_numpy(float)
    n = observed.sum()
    if n <= 1 or min(observed.shape) <= 1:
        return np.nan
    expected = np.outer(observed.sum(axis=1), observed.sum(axis=0)) / n
    chi_square = float(np.sum(np.divide((observed - expected) ** 2, expected, out=np.zeros_like(expected), where=expected > 0)))
    phi2 = chi_square / n
    rows, columns = observed.shape
    corrected_phi2 = max(0.0, phi2 - ((columns - 1) * (rows - 1)) / (n - 1))
    corrected_rows = rows - ((rows - 1) ** 2) / (n - 1)
    corrected_columns = columns - ((columns - 1) ** 2) / (n - 1)
    denominator = min(corrected_columns - 1, corrected_rows - 1)
    return float(np.sqrt(corrected_phi2 / denominator)) if denominator > 0 else np.nan


def eta_squared(categories: pd.Series, values: pd.Series) -> float:
    work = pd.DataFrame({"类别": categories.astype("string"), "值": values.astype(float)}).dropna()
    grand = float(work["值"].mean())
    total = float(np.sum((work["值"] - grand) ** 2))
    between = float(sum(len(part) * (part["值"].mean() - grand) ** 2 for _, part in work.groupby("类别")))
    return between / total if total else np.nan


def association_tables(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    continuous_rows = []
    for first_index, first in enumerate(CONTINUOUS_INPUTS):
        for second in CONTINUOUS_INPUTS[first_index + 1:]:
            coefficient, p_value = spearmanr(frame[first], frame[second], nan_policy="omit")
            continuous_rows.append({
                "变量1": first, "变量2": second, "Spearman相关": coefficient, "P值_描述性": p_value,
                "高度冗余标记": bool(abs(coefficient) >= 0.80),
            })

    categorical_rows = []
    for first_index, first in enumerate(CATEGORICAL_INPUTS):
        for second in CATEGORICAL_INPUTS[first_index + 1:]:
            value = corrected_cramers_v(frame[first], frame[second])
            categorical_rows.append({
                "变量1": first, "变量2": second, "校正CramersV": value,
                "高度冗余标记": bool(np.isfinite(value) and value >= 0.80),
            })

    english_rows = []
    for column in CONTINUOUS_INPUTS:
        coefficient, p_value = spearmanr(frame[column], frame["大学英语成绩"], nan_policy="omit")
        english_rows.append({
            "变量": column, "变量类型": "连续/有序", "与英语关联指标": "Spearman",
            "关联值": coefficient, "P值_描述性": p_value, "类别数": np.nan,
        })
    for column in CATEGORICAL_INPUTS:
        english_rows.append({
            "变量": column, "变量类型": "类别", "与英语关联指标": "Eta平方",
            "关联值": eta_squared(frame[column], frame["大学英语成绩"]),
            "P值_描述性": np.nan, "类别数": frame[column].nunique(dropna=False),
        })
    return pd.DataFrame(continuous_rows), pd.DataFrame(categorical_rows), pd.DataFrame(english_rows)


def standardized_mean_difference(train: pd.Series, test: pd.Series) -> float:
    train_values = pd.to_numeric(train, errors="coerce").dropna().to_numpy(float)
    test_values = pd.to_numeric(test, errors="coerce").dropna().to_numpy(float)
    pooled = np.sqrt((np.var(train_values, ddof=1) + np.var(test_values, ddof=1)) / 2.0)
    return float((test_values.mean() - train_values.mean()) / pooled) if pooled else 0.0


def population_stability_index(train: pd.Series, test: pd.Series, bins: int = 10) -> float:
    train_values = pd.to_numeric(train, errors="coerce").dropna().to_numpy(float)
    test_values = pd.to_numeric(test, errors="coerce").dropna().to_numpy(float)
    edges = np.unique(np.quantile(train_values, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    train_count, _ = np.histogram(train_values, bins=edges)
    test_count, _ = np.histogram(test_values, bins=edges)
    epsilon = 1e-6
    train_rate = np.clip(train_count / train_count.sum(), epsilon, None)
    test_rate = np.clip(test_count / test_count.sum(), epsilon, None)
    return float(np.sum((test_rate - train_rate) * np.log(test_rate / train_rate)))


def categorical_shift(train: pd.Series, test: pd.Series) -> tuple[float, float]:
    train_values = train.astype("string").fillna(MISSING_TOKEN)
    test_values = test.astype("string").fillna(MISSING_TOKEN)
    categories = sorted(set(train_values.unique()).union(test_values.unique()))
    train_rate = train_values.value_counts(normalize=True).reindex(categories, fill_value=0.0).to_numpy(float)
    test_rate = test_values.value_counts(normalize=True).reindex(categories, fill_value=0.0).to_numpy(float)
    js_distance = float(jensenshannon(train_rate, test_rate, base=2.0))
    unknown_rate = float((~test_values.isin(set(train_values.unique()))).mean())
    return js_distance, unknown_rate


def domain_classifier_auc(train: pd.DataFrame, test: pd.DataFrame, seed: int) -> float:
    combined = pd.concat([train[MODEL_INPUTS], test[MODEL_INPUTS]], ignore_index=True)
    labels = np.concatenate([np.zeros(len(train), dtype=int), np.ones(len(test), dtype=int)])
    numeric_pipeline = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(handle_unknown="ignore", min_frequency=2)),
    ])
    transformer = ColumnTransformer([
        ("numeric", numeric_pipeline, CONTINUOUS_INPUTS),
        ("categorical", categorical_pipeline, CATEGORICAL_INPUTS),
    ])
    pipeline = Pipeline([
        ("transform", transformer),
        ("model", LogisticRegression(max_iter=1000, class_weight="balanced", solver="liblinear", random_state=seed)),
    ])
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    probability = cross_val_predict(pipeline, combined, labels, cv=cv, method="predict_proba", n_jobs=1)[:, 1]
    return float(roc_auc_score(labels, probability))


def fold_shift(frame: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    feature_rows = []
    fold_rows = []
    for fold in sorted(frame[FOLD_COLUMN].unique()):
        train = frame.loc[frame[FOLD_COLUMN].ne(fold)]
        test = frame.loc[frame[FOLD_COLUMN].eq(fold)]
        for column in CONTINUOUS_INPUTS:
            feature_rows.append({
                "外层测试折": int(fold), "变量": column, "变量类型": "连续/有序",
                "SMD_测试减训练": standardized_mean_difference(train[column], test[column]),
                "PSI": population_stability_index(train[column], test[column]),
                "JS距离": np.nan, "测试未见类别率": np.nan,
            })
        for column in CATEGORICAL_INPUTS:
            js_distance, unknown_rate = categorical_shift(train[column], test[column])
            feature_rows.append({
                "外层测试折": int(fold), "变量": column, "变量类型": "类别",
                "SMD_测试减训练": np.nan, "PSI": np.nan,
                "JS距离": js_distance, "测试未见类别率": unknown_rate,
            })

        threshold = float(train["大学英语成绩"].quantile(0.25))
        fold_rows.append({
            "外层测试折": int(fold),
            "训练样本量": len(train),
            "测试样本量": len(test),
            "训练高校数": train[GROUP_COLUMN].nunique(),
            "测试高校数": test[GROUP_COLUMN].nunique(),
            "训练折英语P25阈值": threshold,
            "训练风险率": float(train["大学英语成绩"].le(threshold).mean()),
            "测试风险率_沿用训练阈值": float(test["大学英语成绩"].le(threshold).mean()),
            "域分类器交叉验证AUC": domain_classifier_auc(train, test, seed + int(fold)),
        })
    return pd.DataFrame(feature_rows), pd.DataFrame(fold_rows)


def baseline_group_differences(frame: pd.DataFrame) -> pd.DataFrame:
    threshold = float(frame["大学英语成绩"].quantile(0.25))
    rows = []
    for group_column in AUDIT_COLUMNS:
        for group_value, part in frame.groupby(group_column, observed=True, dropna=False):
            values = part["大学英语成绩"].astype(float)
            rows.append({
                "分组变量": group_column,
                "分组值": str(group_value),
                "样本量": len(part),
                "高校数": part[GROUP_COLUMN].nunique(),
                "英语均值": float(values.mean()),
                "英语标准差": float(values.std(ddof=1)),
                "英语P25": float(values.quantile(0.25)),
                "英语中位数": float(values.median()),
                "描述性低表现率": float(values.le(threshold).mean()),
                "描述性全样本P25阈值": threshold,
            })
    return pd.DataFrame(rows)


def protocol_checks(frame: pd.DataFrame) -> pd.DataFrame:
    university_fold_count = frame.groupby(GROUP_COLUMN, observed=True)[FOLD_COLUMN].nunique()
    checks = [
        ("样本编号唯一", not frame[SAMPLE_ID].duplicated().any(), int(frame[SAMPLE_ID].nunique())),
        ("固定模型输入恰好25个", len(MODEL_INPUTS) == 25 and len(set(MODEL_INPUTS)) == 25, len(MODEL_INPUTS)),
        ("结果变量未进入模型输入", not bool(set(TARGETS).intersection(MODEL_INPUTS)), 0),
        ("五个外层测试折齐全", sorted(frame[FOLD_COLUMN].unique().tolist()) == [1, 2, 3, 4, 5], frame[FOLD_COLUMN].nunique()),
        ("每所高校仅属于一个测试折", bool(university_fold_count.eq(1).all()), int(university_fold_count.max())),
        ("主要结果不存在缺失", not frame[TARGETS].isna().any().any(), int(frame[TARGETS].isna().sum().sum())),
    ]
    return pd.DataFrame(checks, columns=["检查项目", "是否通过", "检查值"])


def write_workbook(
    frame: pd.DataFrame,
    output_path: Path,
    bootstrap_repeats: int,
    parallel_repeats: int,
    seed: int,
) -> None:
    distribution = result_distribution(frame)
    icc, university = university_heterogeneity(frame)
    pc1 = pc1_stability(frame, bootstrap_repeats, parallel_repeats, seed)
    missing_summary, missing_count, missing_group = missingness_tables(frame)
    continuous_assoc, categorical_assoc, english_assoc = association_tables(frame)
    shift_features, shift_folds = fold_shift(frame, seed)
    baseline_groups = baseline_group_differences(frame)
    checks = protocol_checks(frame)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        checks.to_excel(writer, sheet_name="协议检查", index=False)
        distribution.to_excel(writer, sheet_name="结果分布", index=False)
        icc.to_excel(writer, sheet_name="高校ICC与设计效应", index=False)
        university.to_excel(writer, sheet_name="高校英语明细", index=False)
        pc1.to_excel(writer, sheet_name="PC1折间稳定性", index=False)
        missing_summary.to_excel(writer, sheet_name="缺失变量汇总", index=False)
        missing_count.to_excel(writer, sheet_name="学生缺失数量", index=False)
        missing_group.to_excel(writer, sheet_name="缺失分组差异", index=False)
        continuous_assoc.to_excel(writer, sheet_name="连续变量相关", index=False)
        categorical_assoc.to_excel(writer, sheet_name="类别变量关联", index=False)
        english_assoc.to_excel(writer, sheet_name="预测变量与英语关联", index=False)
        shift_features.to_excel(writer, sheet_name="折间变量漂移", index=False)
        shift_folds.to_excel(writer, sheet_name="折间总体漂移", index=False)
        baseline_groups.to_excel(writer, sheet_name="分组基线差异", index=False)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--folds", type=Path, default=DEFAULT_FOLDS)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--bootstrap", type=int, default=200)
    parser.add_argument("--parallel", type=int, default=200)
    parser.add_argument("--seed", type=int, default=20260923)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.bootstrap < 100 or args.parallel < 100:
        raise ValueError("正式建模前检验要求bootstrap和并行分析重复次数均不少于100")
    frame = load_inputs(args.data, args.folds)
    output_path = args.output_dir / OUTPUT_FILE
    write_workbook(frame, output_path, args.bootstrap, args.parallel, args.seed)
    print(f"已保存：{output_path}")


if __name__ == "__main__":
    main()
