"""用折外风险预测评估有限英语辅导名额的识别效率。"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import ndcg_score

ROOT = Path(__file__).resolve().parent.parent
MODULE = Path(__file__).resolve().parent
MAIN = ROOT / "03_main_model/output/M2_raw_continuous_encoding_three_seed_ensemble_oof_predictions.csv"
BASELINES = ROOT / "04_baseline_comparison/output/strong_baseline_three_seed_ensemble_predictions.csv"
FUSION = ROOT / "05_ablation_and_task_interaction/output/collaborative_fusion_three_seed_ensemble_predictions.csv"
CAPACITIES = (0.05, 0.10, 0.20, 0.30)
IDENTITY = ["样本编号", "外层测试折", "高校名称"]
SCORE = "低表现校准概率_集成均值"
LABEL = "低表现真实标签"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def read_predictions() -> tuple[pd.DataFrame, dict[str, Path]]:
    paths = {"ESD-MTMS-Net": MAIN, "协同融合": FUSION}
    frames = [pd.read_csv(MAIN).assign(比较模型="ESD-MTMS-Net")]
    # 04 的正式文件现统一含 TabM，无需再拼接历史“TabM增补”文件。
    for path, label in ((FUSION, "协同融合"), (BASELINES, None)):
        if not path.is_file():
            continue
        frame = pd.read_csv(path)
        if label is not None:
            frame["比较模型"] = label
        else:
            frame = frame.rename(columns={"基线模型": "比较模型"})
        frames.append(frame)
        paths[path.name] = path
    result = pd.concat(frames, ignore_index=True)
    needed = [*IDENTITY, "比较模型", SCORE, LABEL]
    if result[needed].isna().any().any() or result.duplicated(["比较模型", "样本编号"]).any():
        raise ValueError("样本外预测存在缺失或模型内样本重复")
    reference = frames[0].set_index("样本编号")[["外层测试折", "高校名称", LABEL]]
    for name, model in result.groupby("比较模型"):
        joined = model.set_index("样本编号")[["外层测试折", "高校名称", LABEL]].reindex(reference.index)
        if len(model) != len(reference) or not joined.equals(reference):
            raise ValueError(f"{name} 的样本、外层折或真实标签与主模型不一致")
    # 常数预测没有个体排序；用样本编号打破平分会制造虚假的Precision@K。
    no_ranking = [name for name, model in result.groupby("比较模型")
                  if all(part[SCORE].nunique() == 1 for _, part in model.groupby("外层测试折"))]
    if no_ranking:
        result = result[~result["比较模型"].isin(no_ranking)].copy()
    return result, paths


def paired_bootstrap(predictions: pd.DataFrame, repeats: int = 2000, seed: int = 20260924) -> pd.DataFrame:
    """原始固定名额策略在高校整群抽样下，与CatBoost成对比较。"""
    if "CatBoost" not in set(predictions["比较模型"]):
        return pd.DataFrame()
    reference = predictions[predictions["比较模型"].eq("CatBoost")].set_index("样本编号")
    clusters = reference["高校名称"].astype(str).unique()
    cluster_index = reference["高校名称"].astype(str).map({name: i for i, name in enumerate(clusters)}).to_numpy()
    positives = np.bincount(cluster_index, weights=reference[LABEL], minlength=len(clusters))
    rng = np.random.default_rng(seed)
    selections = {}
    for name, model in predictions.groupby("比较模型"):
        ordered = model.set_index("样本编号").reindex(reference.index)
        for capacity in CAPACITIES:
            chosen = assign_capacity_for_bootstrap(ordered, capacity)
            selections[(name, capacity)] = (
                np.bincount(cluster_index, weights=chosen * reference[LABEL].to_numpy(), minlength=len(clusters)),
                np.bincount(cluster_index, weights=chosen, minlength=len(clusters)),
            )
    rows = []
    for capacity in CAPACITIES:
        base_found, base_selected = selections[("CatBoost", capacity)]
        for name in sorted(predictions["比较模型"].unique()):
            if name == "CatBoost":
                continue
            candidate_found, candidate_selected = selections[(name, capacity)]
            differences = {"Recall@K": [], "Precision@K": []}
            for _ in range(repeats):
                sample = rng.integers(0, len(clusters), len(clusters))
                total_positive = positives[sample].sum()
                if total_positive == 0:
                    continue
                differences["Recall@K"].append((candidate_found[sample].sum() - base_found[sample].sum()) / total_positive)
                differences["Precision@K"].append(
                    candidate_found[sample].sum() / candidate_selected[sample].sum()
                    - base_found[sample].sum() / base_selected[sample].sum()
                )
            for metric, draws in differences.items():
                point = (candidate_found.sum() - base_found.sum()) / positives.sum() if metric == "Recall@K" else (
                    candidate_found.sum() / candidate_selected.sum() - base_found.sum() / base_selected.sum()
                )
                rows.append({"比较模型": name, "参照模型": "CatBoost", "容量比例": capacity,
                             "差值指标": metric, "估计差值": point,
                             "95%区间下限": float(np.quantile(draws, 0.025)),
                             "95%区间上限": float(np.quantile(draws, 0.975)),
                             "高校聚类Bootstrap次数": repeats})
    return pd.DataFrame(rows)


def assign_capacity_for_bootstrap(model: pd.DataFrame, capacity: float) -> np.ndarray:
    selected = np.zeros(len(model), dtype=float)
    for _, part in model.groupby("外层测试折"):
        count = int(np.ceil(len(part) * capacity))
        ranked = part.assign(_sample_id=part.index).sort_values([SCORE, "_sample_id"], ascending=[False, True])
        selected[model.index.isin(ranked.head(count).index)] = 1.0
    return selected


def evaluate(frame: pd.DataFrame, capacity: float) -> tuple[dict, pd.DataFrame]:
    selected_parts = []
    for fold, part in frame.groupby("外层测试折", sort=True):
        count = int(np.ceil(len(part) * capacity))
        selected_parts.append(part.sort_values([SCORE, "样本编号"], ascending=[False, True]).head(count))
    selected = pd.concat(selected_parts, ignore_index=True)
    label = frame[LABEL].to_numpy(dtype=int)
    found = int(selected[LABEL].sum())
    positive = int(label.sum())
    count = len(selected)
    prevalence = float(label.mean())
    expected_random = sum(
        np.ceil(len(part) * capacity) * part[LABEL].mean()
        for _, part in frame.groupby("外层测试折")
    )
    oracle = sum(
        min(int(np.ceil(len(part) * capacity)), int(part[LABEL].sum()))
        for _, part in frame.groupby("外层测试折")
    )
    ndcg = float(np.mean([
        ndcg_score(
            part[LABEL].to_numpy(dtype=float).reshape(1, -1),
            part[SCORE].to_numpy(dtype=float).reshape(1, -1),
            k=int(np.ceil(len(part) * capacity)),
        )
        for _, part in frame.groupby("外层测试折")
    ]))
    metrics = {
        "比较模型": str(frame["比较模型"].iloc[0]), "容量比例": capacity,
        "辅导名额": count, "真正低表现总人数": positive, "识别人数": found,
        "Precision@K": found / count, "Recall@K": found / positive,
        "Lift@K": (found / count) / prevalence, "nDCG@K_折均": ndcg,
        "每识别1人所需联系人数": count / found if found else np.nan,
        "相对随机多识别人数_期望": found - expected_random,
        "距离折内理论上限人数": oracle - found,
        "相对随机减少无效联系人数_期望": found - expected_random,
    }
    selected = selected[[*IDENTITY, "比较模型", LABEL, SCORE]].copy()
    selected["容量比例"] = capacity
    selected["是否获得支持名额"] = True
    return metrics, selected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=MODULE / "output")
    args = parser.parse_args()
    predictions, paths = read_predictions()
    summary, allocations = [], []
    for _, model in predictions.groupby("比较模型", sort=True):
        for capacity in CAPACITIES:
            metrics, allocation = evaluate(model, capacity)
            summary.append(metrics)
            allocations.append(allocation)
    summary_frame = pd.DataFrame(summary)
    # 每个真正低表现学生获得有效支持的效益设为1；无效联系的成本为情景参数。
    scenarios = pd.concat([
        summary_frame.assign(
            无效联系成本相对效益=cost,
            每百名学生净收益=(
                summary_frame["识别人数"] - cost * (summary_frame["辅导名额"] - summary_frame["识别人数"])
            ) * 100 / len(predictions[predictions["比较模型"] == "ESD-MTMS-Net"]),
        )
        for cost in (0.0, 0.25, 0.5, 1.0)
    ], ignore_index=True)
    args.output.mkdir(parents=True, exist_ok=True)
    summary_frame.to_csv(args.output / "capacity_constrained_identification_efficiency.csv", index=False, encoding="utf-8-sig")
    scenarios[["比较模型", "容量比例", "无效联系成本相对效益", "每百名学生净收益"]].to_csv(
        args.output / "counseling_cost_scenario_net_benefit.csv", index=False, encoding="utf-8-sig"
    )
    pd.concat(allocations, ignore_index=True).to_csv(
        args.output / "within_fold_capacity_allocation_details.csv", index=False, encoding="utf-8-sig"
    )
    paired_bootstrap(predictions).to_csv(
        args.output / "university_cluster_intervals_vs_catboost.csv", index=False, encoding="utf-8-sig"
    )
    (args.output / "run_manifest.json").write_text(json.dumps({
        "协议": "五折样本外预测；各测试折独立分配固定比例容量；按校准风险降序",
        "容量比例": CAPACITIES, "比较模型": sorted(predictions["比较模型"].unique()),
        "净收益": "识别真阳性-成本比×无效联系；单位效益和成本仅为透明情景，不代表干预因果效益",
        "无排序能力基线": "每折风险分数常数者不进入容量排序比较，随机分配期望作为基准",
        "配对比较": "固定折内名额政策下，高校整群bootstrap 2000次，与CatBoost比较",
        "输入SHA256": {name: sha256(path) for name, path in paths.items()},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(summary_frame[summary_frame["比较模型"].eq("ESD-MTMS-Net")].to_string(index=False))


if __name__ == "__main__":
    main()
