"""基于既有样本外预测评估跨高校泛化、稳健性、校准与不确定性。

本脚本不重新训练模型，也不使用测试标签调参。所有主结果来自锁定的
五折高校隔离、三随机种子 ESD-MTMS-Net 样本外预测。
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from scipy.stats import spearmanr
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    log_loss,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)


MODULE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = MODULE_DIR.parent
DEFAULT_INPUT = PROJECT_DIR / "01_data_preprocessing" / "output" / "model_input_data.csv"
DEFAULT_ENSEMBLE = (
    PROJECT_DIR / "03_main_model" / "output" / "M2_raw_continuous_encoding_three_seed_ensemble_oof_predictions.csv"
)
DEFAULT_SEED_PREDICTIONS = (
    PROJECT_DIR / "03_main_model" / "output" / "M2_raw_continuous_encoding_oof_predictions.csv"
)
DEFAULT_OUTPUT = MODULE_DIR / "output"
DATA_SCRIPT = PROJECT_DIR / "01_data_preprocessing" / "data_preprocessing.py"


def load_model_input_columns() -> tuple[str, ...]:
    """从预处理阶段读取唯一的模型输入字段契约，避免审计字段混入漂移。"""
    spec = importlib.util.spec_from_file_location("esd_reliability_data_contract", DATA_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载数据字段契约：{DATA_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    columns = tuple(module.MODEL_INPUTS)
    if len(columns) != 25 or set(columns) & set(module.AUDIT_COLUMNS):
        raise RuntimeError("模型输入字段契约异常或包含公平审计字段")
    return columns


MODEL_INPUT_COLUMNS = load_model_input_columns()

ID = "样本编号"
UNIVERSITY = "高校名称"
FOLD = "外层测试折"
SEED = "随机种子"

TASKS = {
    "英语连续成绩": ("english_performance_真实值", "english_performance_预测值"),
    "非英语通用能力PC1": (
        "non_english_generic_pc1_真实值",
        "non_english_generic_pc1_预测值",
    ),
    "工程项目规划": (
        "engineering_project_formulation_真实值",
        "engineering_project_formulation_预测值",
    ),
}

ENSEMBLE_PREDICTION_COLUMNS = {
    name: (truth, f"{prediction}_集成均值")
    for name, (truth, prediction) in TASKS.items()
}

OUTCOME_COLUMNS = {
    "大学定量推理成绩",
    "大学批判性阅读成绩",
    "大学公民素养成绩",
    "大学英语成绩",
    "工程项目规划成绩",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--ensemble", type=Path, default=DEFAULT_ENSEMBLE)
    parser.add_argument("--seed-predictions", type=Path, default=DEFAULT_SEED_PREDICTIONS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--random-state", type=int, default=20260924)
    parser.add_argument("--min-university-size", type=int, default=30)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_columns(frame: pd.DataFrame, columns: Iterable[str], source: Path) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"{source.name} 缺少字段: {missing}")


def regression_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    truth = np.asarray(truth, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    result = {
        "RMSE": float(math.sqrt(mean_squared_error(truth, prediction))),
        "MAE": float(mean_absolute_error(truth, prediction)),
        "R2": np.nan,
    }
    if len(truth) >= 2 and np.var(truth) > 0:
        result["R2"] = float(r2_score(truth, prediction))
    return result


def probability_metrics(label: np.ndarray, probability: np.ndarray) -> dict[str, float]:
    label = np.asarray(label, dtype=int)
    probability = np.clip(np.asarray(probability, dtype=float), 1e-6, 1.0 - 1e-6)
    result = {
        "ROC_AUC": np.nan,
        "PR_AUC": np.nan,
        "Brier": float(brier_score_loss(label, probability)),
        "LogLoss": float(log_loss(label, probability, labels=[0, 1])),
    }
    if np.unique(label).size == 2:
        result["ROC_AUC"] = float(roc_auc_score(label, probability))
        result["PR_AUC"] = float(average_precision_score(label, probability))
    return result


def university_metrics(ensemble: pd.DataFrame, min_size: int) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for university, group in ensemble.groupby(UNIVERSITY, sort=True):
        base: dict[str, object] = {
            UNIVERSITY: university,
            FOLD: int(group[FOLD].iloc[0]),
            "样本量": len(group),
            "达到稳健汇总最小样本量": len(group) >= min_size,
        }
        for task, (truth_column, prediction_column) in ENSEMBLE_PREDICTION_COLUMNS.items():
            metrics = regression_metrics(group[truth_column], group[prediction_column])
            base.update({f"{task}_{metric}": value for metric, value in metrics.items()})
        labels = group["低表现真实标签"].to_numpy(dtype=int)
        probabilities = group["低表现校准概率_集成均值"].to_numpy(dtype=float)
        risk = probability_metrics(labels, probabilities)
        base.update({f"低表现_{metric}": value for metric, value in risk.items()})
        base["低表现率"] = float(labels.mean())
        base["英语预测种子标准差均值"] = float(
            group["english_performance_预测值_种子标准差"].mean()
        )
        base["英语绝对误差均值"] = float(
            np.abs(
                group["english_performance_真实值"]
                - group["english_performance_预测值_集成均值"]
            ).mean()
        )
        rows.append(base)
    return pd.DataFrame(rows)


def aggregate_regression(
    ensemble: pd.DataFrame,
    university: pd.DataFrame,
    min_size: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    reliable = university[university["样本量"] >= min_size]
    for task, (truth_column, prediction_column) in ENSEMBLE_PREDICTION_COLUMNS.items():
        pooled = regression_metrics(ensemble[truth_column], ensemble[prediction_column])
        rows.extend(
            {"任务": task, "汇总方式": "样本池化", "指标": metric, "估计值": value}
            for metric, value in pooled.items()
        )
        for label, source in (("高校宏平均_全部高校", university), (f"高校宏平均_样本量至少{min_size}", reliable)):
            for metric in ("RMSE", "MAE", "R2"):
                values = source[f"{task}_{metric}"].dropna()
                rows.append(
                    {
                        "任务": task,
                        "汇总方式": label,
                        "指标": metric,
                        "估计值": float(values.mean()),
                    }
                )
        for metric, quantile, label in (
            ("RMSE", 0.90, "高校最差十分位_P90"),
            ("MAE", 0.90, "高校最差十分位_P90"),
            ("R2", 0.10, "高校最差十分位_P10"),
        ):
            values = reliable[f"{task}_{metric}"].dropna()
            rows.append(
                {
                    "任务": task,
                    "汇总方式": label,
                    "指标": metric,
                    "估计值": float(values.quantile(quantile)),
                }
            )
    return pd.DataFrame(rows)


def cluster_bootstrap(
    ensemble: pd.DataFrame,
    repetitions: int,
    random_state: int,
) -> pd.DataFrame:
    """按高校整群重采样，给出池化和高校宏平均回归指标区间。"""
    rng = np.random.default_rng(random_state)
    rows: list[dict[str, object]] = []
    universities = sorted(ensemble[UNIVERSITY].unique())
    university_index = {name: index for index, name in enumerate(universities)}
    cluster_ids = ensemble[UNIVERSITY].map(university_index).to_numpy(dtype=int)
    number_of_clusters = len(universities)

    for task, (truth_column, prediction_column) in ENSEMBLE_PREDICTION_COLUMNS.items():
        truth = ensemble[truth_column].to_numpy(dtype=float)
        prediction = ensemble[prediction_column].to_numpy(dtype=float)
        error = prediction - truth
        count = np.bincount(cluster_ids, minlength=number_of_clusters).astype(float)
        squared_error = np.bincount(cluster_ids, weights=error**2, minlength=number_of_clusters)
        absolute_error = np.bincount(cluster_ids, weights=np.abs(error), minlength=number_of_clusters)
        sum_y = np.bincount(cluster_ids, weights=truth, minlength=number_of_clusters)
        sum_y2 = np.bincount(cluster_ids, weights=truth**2, minlength=number_of_clusters)
        cluster_rmse = np.sqrt(squared_error / count)
        cluster_mae = absolute_error / count
        cluster_sst = sum_y2 - (sum_y**2 / count)
        cluster_r2 = np.full(number_of_clusters, np.nan)
        valid_r2 = cluster_sst > 0
        cluster_r2[valid_r2] = 1.0 - squared_error[valid_r2] / cluster_sst[valid_r2]

        samples: dict[tuple[str, str], list[float]] = {
            ("样本池化", "RMSE"): [],
            ("样本池化", "MAE"): [],
            ("样本池化", "R2"): [],
            ("高校宏平均", "RMSE"): [],
            ("高校宏平均", "MAE"): [],
            ("高校宏平均", "R2"): [],
        }
        for _ in range(repetitions):
            selected = rng.integers(0, number_of_clusters, size=number_of_clusters)
            weights = np.bincount(selected, minlength=number_of_clusters).astype(float)
            total_n = float(weights @ count)
            total_sse = float(weights @ squared_error)
            total_sae = float(weights @ absolute_error)
            total_y = float(weights @ sum_y)
            total_y2 = float(weights @ sum_y2)
            total_sst = total_y2 - total_y**2 / total_n
            samples[("样本池化", "RMSE")].append(math.sqrt(total_sse / total_n))
            samples[("样本池化", "MAE")].append(total_sae / total_n)
            samples[("样本池化", "R2")].append(1.0 - total_sse / total_sst)
            samples[("高校宏平均", "RMSE")].append(float(cluster_rmse[selected].mean()))
            samples[("高校宏平均", "MAE")].append(float(cluster_mae[selected].mean()))
            samples[("高校宏平均", "R2")].append(float(np.nanmean(cluster_r2[selected])))

        point = regression_metrics(truth, prediction)
        macro_point = {
            "RMSE": float(cluster_rmse.mean()),
            "MAE": float(cluster_mae.mean()),
            "R2": float(np.nanmean(cluster_r2)),
        }
        for (aggregation, metric), values in samples.items():
            values_array = np.asarray(values, dtype=float)
            rows.append(
                {
                    "任务": task,
                    "汇总方式": aggregation,
                    "指标": metric,
                    "估计值": point[metric] if aggregation == "样本池化" else macro_point[metric],
                    "95%区间下限": float(np.nanquantile(values_array, 0.025)),
                    "95%区间上限": float(np.nanquantile(values_array, 0.975)),
                    "高校聚类Bootstrap次数": repetitions,
                }
            )
    return pd.DataFrame(rows)


def seed_stability(raw: pd.DataFrame, ensemble: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for seed, seed_frame in raw.groupby(SEED, sort=True):
        for fold_label, fold_frame in [("总体", seed_frame), *list(seed_frame.groupby(FOLD, sort=True))]:
            for task, (truth_column, prediction_column) in TASKS.items():
                metrics = regression_metrics(fold_frame[truth_column], fold_frame[prediction_column])
                rows.append(
                    {
                        "预测来源": f"种子{int(seed)}",
                        "外层测试折": fold_label,
                        "任务": task,
                        **metrics,
                    }
                )
    for fold_label, fold_frame in [("总体", ensemble), *list(ensemble.groupby(FOLD, sort=True))]:
        for task, (truth_column, prediction_column) in ENSEMBLE_PREDICTION_COLUMNS.items():
            metrics = regression_metrics(fold_frame[truth_column], fold_frame[prediction_column])
            rows.append(
                {
                    "预测来源": "三种子集成",
                    "外层测试折": fold_label,
                    "任务": task,
                    **metrics,
                }
            )
    return pd.DataFrame(rows)


def add_distribution_shift(
    base_data: pd.DataFrame,
    ensemble: pd.DataFrame,
    university: pd.DataFrame,
) -> pd.DataFrame:
    fold_map = ensemble[[ID, FOLD]].drop_duplicates()
    merged = base_data.merge(fold_map, on=ID, how="left", validate="one_to_one")
    if merged[FOLD].isna().any():
        raise ValueError("基础数据存在无法匹配外层折的样本")
    require_columns(base_data, MODEL_INPUT_COLUMNS, DEFAULT_INPUT)
    numeric = [column for column in MODEL_INPUT_COLUMNS if pd.api.types.is_numeric_dtype(base_data[column])]
    categorical = [column for column in MODEL_INPUT_COLUMNS if column not in numeric]
    rows: list[dict[str, object]] = []

    for name, group in merged.groupby(UNIVERSITY, sort=True):
        fold = int(group[FOLD].iloc[0])
        train = merged[merged[FOLD] != fold]
        train_mean = train[numeric].mean()
        train_sd = train[numeric].std(ddof=0).replace(0.0, np.nan)
        numeric_shift = ((group[numeric].mean() - train_mean).abs() / train_sd).mean(skipna=True)
        categorical_shifts: list[float] = []
        for column in categorical:
            levels = sorted(set(train[column].astype(str)) | set(group[column].astype(str)))
            train_distribution = train[column].astype(str).value_counts(normalize=True).reindex(levels, fill_value=0.0)
            group_distribution = group[column].astype(str).value_counts(normalize=True).reindex(levels, fill_value=0.0)
            categorical_shifts.append(float(0.5 * np.abs(train_distribution - group_distribution).sum()))
        categorical_shift = float(np.mean(categorical_shifts))
        rows.append(
            {
                UNIVERSITY: name,
                "数值特征平均绝对标准化均值差": float(numeric_shift),
                "类别特征平均总变差距离": categorical_shift,
                "综合分布漂移": float(np.mean([numeric_shift, categorical_shift])),
                "数值特征数": len(numeric),
                "类别特征数": len(categorical),
            }
        )
    return university.merge(pd.DataFrame(rows), on=UNIVERSITY, how="left", validate="one_to_one")


def bootstrap_spearman(
    x: np.ndarray,
    y: np.ndarray,
    repetitions: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = y[valid]
    values: list[float] = []
    for _ in range(repetitions):
        indices = rng.integers(0, len(x), size=len(x))
        statistic = spearmanr(x[indices], y[indices]).statistic
        if np.isfinite(statistic):
            values.append(float(statistic))
    return float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))


def shift_error_associations(
    university: pd.DataFrame,
    repetitions: int,
    random_state: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(random_state + 19)
    outcomes = [
        "英语连续成绩_RMSE",
        "英语连续成绩_MAE",
        "英语连续成绩_R2",
        "英语预测种子标准差均值",
    ]
    rows: list[dict[str, object]] = []
    for shift in (
        "数值特征平均绝对标准化均值差",
        "类别特征平均总变差距离",
        "综合分布漂移",
    ):
        for outcome in outcomes:
            subset = university[[shift, outcome]].dropna()
            result = spearmanr(subset[shift], subset[outcome])
            lower, upper = bootstrap_spearman(
                subset[shift].to_numpy(float),
                subset[outcome].to_numpy(float),
                repetitions,
                rng,
            )
            rows.append(
                {
                    "漂移指标": shift,
                    "结果指标": outcome,
                    "高校数": len(subset),
                    "Spearman相关": float(result.statistic),
                    "双侧P值": float(result.pvalue),
                    "95%区间下限": lower,
                    "95%区间上限": upper,
                }
            )
    result = pd.DataFrame(rows)
    # 十二项相关共享同一批高校，不能逐项把未校正P值当作确认性证据。
    order = np.argsort(result["双侧P值"].to_numpy(float))
    ordered_p = result["双侧P值"].to_numpy(float)[order]
    adjusted = np.maximum.accumulate(ordered_p * (len(ordered_p) - np.arange(len(ordered_p))))
    result["Holm校正P值"] = np.nan
    result.loc[order, "Holm校正P值"] = np.minimum(adjusted, 1.0)
    return result


def calibration_analysis(ensemble: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, object]] = []
    curves: list[pd.DataFrame] = []
    for fold_label, frame in [("总体", ensemble), *list(ensemble.groupby(FOLD, sort=True))]:
        label = frame["低表现真实标签"].to_numpy(dtype=int)
        probability = np.clip(
            frame["低表现校准概率_集成均值"].to_numpy(dtype=float),
            1e-6,
            1.0 - 1e-6,
        )
        metrics = probability_metrics(label, probability)
        bins = pd.qcut(probability, q=10, duplicates="drop")
        curve = (
            pd.DataFrame({"标签": label, "概率": probability, "分箱": bins})
            .groupby("分箱", observed=True)
            .agg(样本量=("标签", "size"), 平均预测概率=("概率", "mean"), 实际低表现率=("标签", "mean"))
            .reset_index(drop=True)
        )
        curve.insert(0, "分箱序号", np.arange(1, len(curve) + 1))
        curve.insert(0, "外层测试折", fold_label)
        curves.append(curve)
        ece = float(
            np.average(
                np.abs(curve["平均预测概率"] - curve["实际低表现率"]),
                weights=curve["样本量"],
            )
        )
        # C=inf is the current scikit-learn spelling for an unpenalized model.
        calibration_model = LogisticRegression(C=np.inf, solver="lbfgs", max_iter=1000)
        calibration_model.fit(logit(probability).reshape(-1, 1), label)
        summaries.append(
            {
                "外层测试折": fold_label,
                "样本量": len(frame),
                "低表现率": float(label.mean()),
                **metrics,
                "ECE_等频10箱": ece,
                "校准截距": float(calibration_model.intercept_[0]),
                "校准斜率": float(calibration_model.coef_[0, 0]),
            }
        )
    return pd.DataFrame(summaries), pd.concat(curves, ignore_index=True)


def selective_prediction(ensemble: pd.DataFrame) -> pd.DataFrame:
    """按三种子预测标准差从低到高保留样本；筛选过程不使用真实标签。"""
    uncertainty = ensemble["english_performance_预测值_种子标准差"].to_numpy(float)
    truth = ensemble["english_performance_真实值"].to_numpy(float)
    prediction = ensemble["english_performance_预测值_集成均值"].to_numpy(float)
    order = np.argsort(uncertainty, kind="stable")
    rows: list[dict[str, object]] = []
    for coverage in (0.50, 0.60, 0.70, 0.80, 0.90, 1.00):
        retained_n = max(1, int(math.ceil(len(order) * coverage)))
        retained = order[:retained_n]
        deferred = order[retained_n:]
        metrics = regression_metrics(truth[retained], prediction[retained])
        rows.append(
            {
                "保留比例": coverage,
                "保留样本量": retained_n,
                "延后样本量": len(deferred),
                "不确定性阈值": float(uncertainty[retained].max()),
                **metrics,
                "保留样本平均绝对误差": float(np.abs(truth[retained] - prediction[retained]).mean()),
                "延后样本平均绝对误差": (
                    float(np.abs(truth[deferred] - prediction[deferred]).mean())
                    if len(deferred)
                    else np.nan
                ),
            }
        )
    return pd.DataFrame(rows)


def write_outputs(args: argparse.Namespace) -> None:
    if args.bootstrap < 500:
        raise ValueError("正式高校聚类Bootstrap次数不得少于500")
    if args.min_university_size < 10:
        raise ValueError("高校稳健汇总最小样本量不得少于10")
    for path in (args.input, args.ensemble, args.seed_predictions):
        if not path.exists():
            raise FileNotFoundError(path)

    base_data = pd.read_csv(args.input)
    ensemble = pd.read_csv(args.ensemble)
    raw = pd.read_csv(args.seed_predictions)
    required_ensemble = {
        ID,
        UNIVERSITY,
        FOLD,
        "低表现真实标签",
        "低表现校准概率_集成均值",
        "english_performance_预测值_种子标准差",
        *[column for pair in ENSEMBLE_PREDICTION_COLUMNS.values() for column in pair],
    }
    required_raw = {ID, UNIVERSITY, FOLD, SEED, *[column for pair in TASKS.values() for column in pair]}
    require_columns(ensemble, required_ensemble, args.ensemble)
    require_columns(raw, required_raw, args.seed_predictions)
    require_columns(base_data, {ID, UNIVERSITY, *OUTCOME_COLUMNS}, args.input)
    if ensemble[ID].duplicated().any() or len(ensemble) != len(base_data):
        raise ValueError("三种子集成预测必须与基础数据一一对应")
    expected_raw_rows = len(ensemble) * raw[SEED].nunique()
    if len(raw) != expected_raw_rows or raw.duplicated([ID, SEED]).any():
        raise ValueError("逐种子样本外预测覆盖不完整或存在重复")

    args.output.mkdir(parents=True, exist_ok=True)
    university = university_metrics(ensemble, args.min_university_size)
    university = add_distribution_shift(base_data, ensemble, university)
    aggregate = aggregate_regression(ensemble, university, args.min_university_size)
    bootstrap = cluster_bootstrap(ensemble, args.bootstrap, args.random_state)
    stability = seed_stability(raw, ensemble)
    associations = shift_error_associations(university, args.bootstrap, args.random_state)
    calibration, calibration_curve = calibration_analysis(ensemble)
    selective = selective_prediction(ensemble)

    outputs = {
        "overall_and_university_macro_metrics.csv": aggregate,
        "university_generalization_and_drift_metrics.csv": university,
        "university_cluster_bootstrap_intervals.csv": bootstrap,
        "seed_and_fold_stability.csv": stability,
        "drift_error_associations.csv": associations,
        "low_performance_probability_calibration_metrics.csv": calibration,
        "low_performance_probability_calibration_curve.csv": calibration_curve,
        "seed_disagreement_selective_prediction.csv": selective,
    }
    for filename, frame in outputs.items():
        frame.to_csv(args.output / filename, index=False, encoding="utf-8-sig")

    manifest = {
        "分析协议": "五折未见高校、三随机种子样本外预测可靠性审计",
        "重新训练模型": False,
        "样本量": len(ensemble),
        "高校数": int(ensemble[UNIVERSITY].nunique()),
        "随机种子": sorted(int(value) for value in raw[SEED].unique()),
        "高校聚类Bootstrap次数": args.bootstrap,
        "高校稳健汇总最小样本量": args.min_university_size,
        "漂移变量口径": "仅包含01阶段定义的25个模型输入；排除性别、学生SES及高校SES审计字段",
        "漂移模型输入字段": list(MODEL_INPUT_COLUMNS),
        "漂移关联检验性质": "12项探索性相关；同时报告未校正双侧P值与12项Holm校正P值，不作因果推断",
        "不确定性定义": "同一样本三随机种子英语预测值的标准差",
        "保形区间状态": "未计算：既有输出未保存训练折内部校准残差，禁止使用测试标签事后校准",
        "输入SHA256": {
            args.input.name: sha256(args.input),
            args.ensemble.name: sha256(args.ensemble),
            args.seed_predictions.name: sha256(args.seed_predictions),
        },
        "输出文件": list(outputs),
    }
    (args.output / "reliability_analysis_run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"可靠性分析完成：{len(ensemble)}个样本，{ensemble[UNIVERSITY].nunique()}所高校")
    print(f"结果目录：{args.output}")


if __name__ == "__main__":
    write_outputs(parse_args())
