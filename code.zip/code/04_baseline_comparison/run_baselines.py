"""强基线统一训练入口。

所有方法复用 03 主模型的固定高校隔离五折、折内特征/目标处理、
低英语表现定义和内部高校校准协议。默认只检查；正式训练必须显式
传入 ``train --confirm-training TRAIN``。
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import importlib.metadata
import json
import os
import pickle
import platform
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import sklearn
import torch
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import MultiTaskElasticNet
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.multioutput import MultiOutputRegressor
from sklearn.neural_network import MLPRegressor


HERE = Path(__file__).resolve().parent
RESEARCH_ROOT = HERE.parent
MAIN_DIR = RESEARCH_ROOT / "03_main_model"
OUTPUT_DIR = HERE / "output"
SMOKE_OUTPUT_DIR = RESEARCH_ROOT / "90_开发过程" / "04_基线冒烟"
CONFIRMATION_TEXT = "TRAIN"

if str(MAIN_DIR) not in sys.path:
    sys.path.insert(0, str(MAIN_DIR))
import train_main as protocol  # noqa: E402


DATA = protocol.DATA
ALL_MODELS = (
    "dummy_mean", "elastic_net", "random_forest", "extra_trees", "hist_gbdt",
    "xgboost", "lightgbm", "catboost", "mlp", "tabm", "realmlp",
)
MODEL_LABELS = {
    "dummy_mean": "均值基准",
    "elastic_net": "ElasticNet",
    "random_forest": "RandomForest",
    "extra_trees": "ExtraTrees",
    "hist_gbdt": "HistGradientBoosting",
    "xgboost": "XGBoost",
    "lightgbm": "LightGBM",
    "catboost": "CatBoost",
    "mlp": "MLP",
    "tabm": "TabM",
    "realmlp": "RealMLP-TD",
}
OPTIONAL_PACKAGES = {
    "xgboost": "xgboost", "lightgbm": "lightgbm", "catboost": "catboost",
    "tabm": "tabm", "realmlp": "pytabkit",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_ints(text: str, *, allowed: set[int] | None = None) -> tuple[int, ...]:
    values = tuple(dict.fromkeys(int(item.strip()) for item in text.split(",") if item.strip()))
    if not values:
        raise ValueError("参数不能为空")
    if allowed is not None and not set(values).issubset(allowed):
        raise ValueError(f"参数必须位于 {sorted(allowed)}")
    return values


def parse_models(text: str) -> tuple[str, ...]:
    names = tuple(dict.fromkeys(item.strip() for item in text.split(",") if item.strip()))
    unknown = sorted(set(names).difference(ALL_MODELS))
    if not names or unknown:
        raise ValueError(f"未知基线 {unknown}；可选值={list(ALL_MODELS)}")
    return names


def missing_packages(models: Iterable[str]) -> list[str]:
    return [
        package for model, package in OPTIONAL_PACKAGES.items()
        if model in models and importlib.util.find_spec(package) is None
    ]


class TabMRegressor:
    """TabM 的最小多任务回归适配器，保留官方独立子模型损失。"""

    def __init__(
        self,
        seed: int,
        max_epochs: int = 300,
        patience: int = 30,
        batch_size: int = 256,
    ) -> None:
        self.seed = int(seed)
        self.max_epochs = int(max_epochs)
        self.patience = int(patience)
        self.batch_size = int(batch_size)
        self.best_epoch_: int | None = None
        self.model_: Any | None = None

    @staticmethod
    def _unpack(x: Any) -> tuple[np.ndarray, np.ndarray, list[int]]:
        if not isinstance(x, tuple) or len(x) != 3:
            raise TypeError("TabM 输入必须为（连续数组，类别数组，类别基数）")
        continuous, categorical, cardinalities = x
        return (
            np.asarray(continuous, dtype=np.float32),
            np.asarray(categorical, dtype=np.int64),
            [int(value) for value in cardinalities],
        )

    def _predict_tensor(
        self, continuous: torch.Tensor, categorical: torch.Tensor, device: torch.device
    ) -> torch.Tensor:
        if self.model_ is None:
            raise RuntimeError("TabM 尚未拟合")
        return self.model_(
            continuous.to(device, non_blocking=True),
            categorical.to(device, non_blocking=True),
        ).mean(dim=1)

    def fit(
        self,
        x: Any,
        y: np.ndarray,
        validation_x: Any | None = None,
        validation_y: np.ndarray | None = None,
    ) -> "TabMRegressor":
        from tabm import TabM

        continuous, categorical, cardinalities = self._unpack(x)
        target = np.asarray(y, dtype=np.float32)
        if target.ndim != 2 or target.shape[1] != 3:
            raise ValueError("TabM 目标必须是 [n,3]")
        protocol.set_seed(self.seed)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model_ = TabM.make(
            n_num_features=continuous.shape[1],
            cat_cardinalities=cardinalities or None,
            d_out=3,
            arch_type="tabm-mini",
            k=16,
            n_blocks=3,
            d_block=256,
            dropout=0.10,
        ).to(device)
        optimizer = torch.optim.AdamW(self.model_.parameters(), lr=2.0e-3, weight_decay=1.0e-4)
        x_num = torch.from_numpy(continuous)
        x_cat = torch.from_numpy(categorical)
        targets = torch.from_numpy(target)
        generator = torch.Generator().manual_seed(self.seed)
        loader = torch.utils.data.DataLoader(
            torch.utils.data.TensorDataset(x_num, x_cat, targets),
            batch_size=self.batch_size,
            shuffle=True,
            generator=generator,
            pin_memory=device.type == "cuda",
        )
        if validation_x is not None:
            val_num_np, val_cat_np, _ = self._unpack(validation_x)
            if validation_y is None:
                raise ValueError("提供验证特征时必须提供验证目标")
            val_num = torch.from_numpy(val_num_np)
            val_cat = torch.from_numpy(val_cat_np)
            val_target = torch.from_numpy(np.asarray(validation_y, dtype=np.float32))
        else:
            val_num = val_cat = val_target = None
        task_weights = torch.tensor(protocol.TASK_WEIGHTS, dtype=torch.float32, device=device)
        best_score = float("inf")
        best_state: dict[str, torch.Tensor] | None = None
        stale = 0
        amp_enabled = device.type == "cuda"
        scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
        for epoch in range(1, self.max_epochs + 1):
            self.model_.train()
            for batch_num, batch_cat, batch_target in loader:
                optimizer.zero_grad(set_to_none=True)
                batch_num = batch_num.to(device, non_blocking=True)
                batch_cat = batch_cat.to(device, non_blocking=True)
                batch_target = batch_target.to(device, non_blocking=True)
                with torch.autocast(device_type=device.type, enabled=amp_enabled):
                    all_predictions = self.model_(batch_num, batch_cat)
                    per_task = (all_predictions - batch_target[:, None, :]).square().mean(dim=(0, 1))
                    loss = torch.sum(task_weights * per_task)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            if val_num is None:
                self.best_epoch_ = epoch
                continue
            self.model_.eval()
            with torch.inference_mode():
                prediction = self._predict_tensor(val_num, val_cat, device).cpu()
            rmse = torch.sqrt((prediction - val_target).square().mean(dim=0))
            score = float(torch.sum(rmse * task_weights.cpu()))
            if score < best_score - 1.0e-4:
                best_score = score
                self.best_epoch_ = epoch
                best_state = {
                    name: value.detach().cpu().clone()
                    for name, value in self.model_.state_dict().items()
                }
                stale = 0
            else:
                stale += 1
            if stale >= self.patience:
                break
        if best_state is not None:
            self.model_.load_state_dict(best_state)
        if self.best_epoch_ is None:
            raise RuntimeError("TabM 未产生有效轮次")
        return self

    def predict(self, x: Any) -> np.ndarray:
        continuous, categorical, _ = self._unpack(x)
        if self.model_ is None:
            raise RuntimeError("TabM 尚未拟合")
        device = next(self.model_.parameters()).device
        dataset = torch.utils.data.TensorDataset(
            torch.from_numpy(continuous), torch.from_numpy(categorical)
        )
        loader = torch.utils.data.DataLoader(dataset, batch_size=1024, shuffle=False)
        output = []
        self.model_.eval()
        with torch.inference_mode():
            for batch_num, batch_cat in loader:
                output.append(self._predict_tensor(batch_num, batch_cat, device).cpu().numpy())
        return np.concatenate(output, axis=0)


def one_hot_matrix(continuous: np.ndarray, categorical: np.ndarray, cardinalities: list[int]) -> np.ndarray:
    blocks: list[np.ndarray] = [np.asarray(continuous, dtype=np.float32)]
    for index, cardinality in enumerate(cardinalities):
        codes = np.asarray(categorical[:, index], dtype=np.int64)
        if codes.min(initial=0) < 0 or codes.max(initial=0) >= cardinality:
            raise ValueError("类别编码超出训练折词表")
        blocks.append(np.eye(cardinality, dtype=np.float32)[codes])
    return np.concatenate(blocks, axis=1)


def catboost_frame(
    continuous: np.ndarray,
    categorical: np.ndarray,
    continuous_names: list[str],
    categorical_names: list[str],
) -> pd.DataFrame:
    frame = pd.DataFrame(continuous, columns=continuous_names)
    for index, name in enumerate(categorical_names):
        frame[name] = pd.Series(categorical[:, index], dtype="int64").astype(str)
    return frame


def design_matrices(split: Any, model_name: str) -> tuple[Any, Any, list[str] | None]:
    if model_name == "tabm":
        return (
            (split.train_continuous, split.train_categorical, split.cardinalities),
            (split.other_continuous, split.other_categorical, split.cardinalities),
            None,
        )
    if model_name == "catboost":
        return (
            catboost_frame(
                split.train_continuous, split.train_categorical,
                split.continuous_names, split.categorical_names,
            ),
            catboost_frame(
                split.other_continuous, split.other_categorical,
                split.continuous_names, split.categorical_names,
            ),
            list(split.categorical_names),
        )
    return (
        one_hot_matrix(split.train_continuous, split.train_categorical, split.cardinalities),
        one_hot_matrix(split.other_continuous, split.other_categorical, split.cardinalities),
        None,
    )


def make_estimator(model_name: str, seed: int, threads: int) -> Any:
    if model_name == "dummy_mean":
        return DummyRegressor(strategy="mean")
    if model_name == "elastic_net":
        return MultiTaskElasticNet(
            alpha=0.002, l1_ratio=0.10, max_iter=5000, tol=1.0e-4, selection="cyclic"
        )
    if model_name == "random_forest":
        return RandomForestRegressor(
            n_estimators=400, max_features=0.70, min_samples_leaf=2,
            n_jobs=threads, random_state=seed,
        )
    if model_name == "extra_trees":
        return ExtraTreesRegressor(
            n_estimators=400, max_features=0.85, min_samples_leaf=2,
            n_jobs=threads, random_state=seed,
        )
    if model_name == "hist_gbdt":
        base = HistGradientBoostingRegressor(
            learning_rate=0.05, max_iter=350, max_leaf_nodes=31,
            min_samples_leaf=20, l2_regularization=1.0, random_state=seed,
        )
        return MultiOutputRegressor(base, n_jobs=min(3, threads))
    if model_name == "xgboost":
        from xgboost import XGBRegressor

        base = XGBRegressor(
            n_estimators=700, learning_rate=0.035, max_depth=6, min_child_weight=3.0,
            subsample=0.85, colsample_bytree=0.85, reg_alpha=0.02, reg_lambda=1.0,
            objective="reg:squarederror", tree_method="hist",
            n_jobs=max(1, threads // 3), random_state=seed,
        )
        return MultiOutputRegressor(base, n_jobs=min(3, threads))
    if model_name == "lightgbm":
        from lightgbm import LGBMRegressor

        base = LGBMRegressor(
            n_estimators=700, learning_rate=0.035, num_leaves=31, min_child_samples=20,
            subsample=0.85, colsample_bytree=0.85, reg_alpha=0.02, reg_lambda=1.0,
            n_jobs=max(1, threads // 3), random_state=seed, verbosity=-1,
        )
        return MultiOutputRegressor(base, n_jobs=min(3, threads))
    if model_name == "catboost":
        from catboost import CatBoostRegressor

        return CatBoostRegressor(
            loss_function="MultiRMSE", iterations=700, learning_rate=0.035, depth=8,
            l2_leaf_reg=3.0, random_seed=seed, thread_count=threads,
            verbose=False, allow_writing_files=False,
        )
    if model_name == "mlp":
        return MLPRegressor(
            hidden_layer_sizes=(256, 128), activation="relu", solver="adam",
            alpha=1.0e-4, batch_size=256, learning_rate_init=5.0e-4,
            max_iter=300, early_stopping=False, tol=1.0e-4, random_state=seed,
        )
    if model_name == "tabm":
        return TabMRegressor(seed=seed)
    if model_name == "realmlp":
        from pytabkit import RealMLP_TD_Regressor

        return RealMLP_TD_Regressor(
            device="cuda" if torch.cuda.is_available() else "cpu",
            random_state=seed, n_cv=1, n_refit=0, n_epochs=300,
            n_threads=threads, verbosity=0,
        )
    raise ValueError(f"未实现基线：{model_name}")


def fit_estimator(estimator: Any, model_name: str, x: Any, y: np.ndarray, cat_names: list[str] | None) -> Any:
    if model_name == "catboost":
        estimator.fit(x, y, cat_features=cat_names)
    elif model_name == "mlp":
        # 轮数已由高校隔离内部验证选定；到达该预算不是收敛故障。
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            estimator.fit(x, y)
    elif model_name == "tabm":
        estimator.fit(x, y)
    else:
        estimator.fit(x, y)
    return estimator


def fit_selection_estimator(
    model_name: str,
    seed: int,
    threads: int,
    train_x: Any,
    train_y: np.ndarray,
    validation_x: Any,
    validation_y: np.ndarray,
    cat_names: list[str] | None,
) -> tuple[Any, int | None]:
    """在高校隔离的内部训练/验证集上拟合，神经网络据此确定重训轮次。"""

    estimator = make_estimator(model_name, seed, threads)
    if model_name == "tabm":
        estimator.fit(train_x, train_y, validation_x, validation_y)
        return estimator, estimator.best_epoch_
    if model_name == "realmlp":
        estimator.fit(train_x, train_y, validation_x, validation_y)
        stop_epochs = estimator.fit_params_["stop_epoch"]
        return estimator, int(next(iter(stop_epochs.values())))
    if model_name != "mlp":
        return fit_estimator(estimator, model_name, train_x, train_y, cat_names), None

    best_estimator: Any | None = None
    best_epoch = 0
    best_score = float("inf")
    stale = 0
    task_weights = np.asarray(protocol.TASK_WEIGHTS, dtype=float)
    for epoch in range(1, 301):
        estimator.partial_fit(train_x, train_y)
        prediction = np.asarray(estimator.predict(validation_x), dtype=float)
        task_rmse = np.sqrt(np.mean(np.square(prediction - validation_y), axis=0))
        score = float(task_rmse @ task_weights)
        if score < best_score - 1.0e-4:
            best_score = score
            best_epoch = epoch
            best_estimator = copy.deepcopy(estimator)
            stale = 0
        else:
            stale += 1
        if stale >= 30:
            break
    if best_estimator is None or best_epoch <= 0:
        raise RuntimeError("MLP内部高校早停未产生有效模型")
    return best_estimator, best_epoch


def safe_risk_metrics(labels: np.ndarray, scores: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    labels = np.asarray(labels, dtype=int)
    scores = np.asarray(scores, dtype=float)
    probabilities = np.clip(np.asarray(probabilities, dtype=float), 1.0e-7, 1.0 - 1.0e-7)
    auc = average_precision = float("nan")
    if np.unique(labels).size >= 2:
        auc = float(roc_auc_score(labels, scores))
        average_precision = float(average_precision_score(labels, scores))
    return {
        "ROC_AUC": auc,
        "PR_AUC": average_precision,
        "Brier": float(brier_score_loss(labels, probabilities)),
        "LogLoss": float(log_loss(labels, probabilities, labels=[0, 1])),
    }


def serialized_bytes(estimator: Any) -> int:
    try:
        return len(pickle.dumps(estimator, protocol=pickle.HIGHEST_PROTOCOL))
    except Exception:
        return -1


def write_outputs(
    output_dir: Path,
    predictions: pd.DataFrame,
    metric_rows: list[dict[str, Any]],
    risk_rows: list[dict[str, Any]],
    efficiency_rows: list[dict[str, Any]],
    manifest: dict[str, Any],
    prefix: str = "",
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(output_dir / f"{prefix}strong_baseline_oof_predictions.csv", index=False, encoding="utf-8-sig")

    prediction_columns = [
        column for column in predictions.columns
        if column.endswith("_预测值") or column.endswith("_标准化预测值")
    ] + ["低表现风险分数", "低表现校准概率"]
    keys = ["基线模型", DATA.SAMPLE_ID, "外层测试折"]
    grouped = predictions.groupby(keys, observed=True, sort=False)
    means = grouped[prediction_columns].mean().add_suffix("_集成均值")
    deviations = grouped[prediction_columns].std(ddof=0).add_suffix("_种子标准差")
    metadata = [
        DATA.GROUP_COLUMN, *DATA.AUDIT_COLUMNS,
        *[column for column in predictions.columns if column.endswith("_真实值")],
        "低表现真实标签", "训练折英语风险阈值",
    ]
    ensemble = grouped[metadata].first().join(means).join(deviations).reset_index()
    ensemble.to_csv(output_dir / f"{prefix}strong_baseline_three_seed_ensemble_predictions.csv", index=False, encoding="utf-8-sig")

    for label, group in ensemble.groupby("基线模型", observed=True, sort=False):
        raw_true = np.column_stack([
            group[f"{task}_真实值"].to_numpy(dtype=float)
            for task in DATA.FoldTargetPreprocessor.task_names
        ])
        raw_prediction = np.column_stack([
            group[f"{task}_预测值_集成均值"].to_numpy(dtype=float)
            for task in DATA.FoldTargetPreprocessor.task_names
        ])
        for row in protocol.calculate_metrics(raw_true, raw_prediction):
            metric_rows.append(
                {"基线模型": label, "外层测试折": "三种子集成", "随机种子": "集成", **row}
            )
        risk_rows.append(
            {
                "基线模型": label,
                "外层测试折": "三种子集成",
                "随机种子": "集成",
                **safe_risk_metrics(
                    group["低表现真实标签"].to_numpy(),
                    group["低表现风险分数_集成均值"].to_numpy(),
                    group["低表现校准概率_集成均值"].to_numpy(),
                ),
            }
        )

    pd.DataFrame(metric_rows).to_csv(output_dir / f"{prefix}strong_baseline_fold_metrics.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(risk_rows).to_csv(
        output_dir / f"{prefix}strong_baseline_risk_discrimination_and_calibration.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(efficiency_rows).to_csv(
        output_dir / f"{prefix}strong_baseline_training_inference_efficiency.csv", index=False, encoding="utf-8-sig"
    )
    (output_dir / f"{prefix}strong_baseline_run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def run_experiment(args: argparse.Namespace, *, smoke: bool) -> None:
    if not smoke and args.confirm_training != CONFIRMATION_TEXT:
        raise RuntimeError(f"训练被安全锁阻止；请添加 --confirm-training {CONFIRMATION_TEXT}")
    models = parse_models(args.models)
    missing = missing_packages(models)
    if missing:
        raise RuntimeError(f"所选基线缺少依赖：{missing}")
    seeds = parse_ints(args.seeds)
    folds = parse_ints(args.folds, allowed={1, 2, 3, 4, 5})
    frame = protocol.load_protocol_data()
    output_dir = SMOKE_OUTPUT_DIR if smoke else Path(args.output_dir)
    started_at = datetime.now(timezone.utc).astimezone()
    started = time.time()
    prediction_parts: list[pd.DataFrame] = []
    metric_rows: list[dict[str, Any]] = []
    risk_rows: list[dict[str, Any]] = []
    efficiency_rows: list[dict[str, Any]] = []

    for outer_fold in folds:
        outer_test = frame.loc[frame["外层测试折"] == outer_fold].copy()
        outer_train = frame.loc[frame["外层测试折"] != outer_fold].copy()
        full = protocol.prepare_split(outer_train, outer_test, "raw")
        for seed in seeds:
            selection_train, selection_validation = protocol.university_validation_split(outer_train, seed)
            selection = protocol.prepare_split(selection_train, selection_validation, "raw")
            for model_name in models:
                label = MODEL_LABELS[model_name]
                selection_x, validation_x, selection_categories = design_matrices(selection, model_name)
                selection_started = time.perf_counter()
                selection_estimator, selected_epoch = fit_selection_estimator(
                    model_name, seed, args.threads,
                    selection_x, selection.train_target,
                    validation_x, selection.other_target,
                    selection_categories,
                )
                selection_seconds = time.perf_counter() - selection_started
                validation_std = np.asarray(
                    selection_estimator.predict(validation_x), dtype=np.float32
                ).reshape(len(selection.other_target), -1)
                validation_raw = protocol.inverse_targets(selection.target_processor, validation_std)
                calibration_labels = (
                    selection_validation["大学英语成绩"].to_numpy(dtype=float)
                    <= full.target_processor.risk_threshold
                ).astype(np.int8)
                calibrator = protocol.fit_risk_calibrator(-validation_raw[:, 0], calibration_labels)

                train_x, test_x, categorical_names = design_matrices(full, model_name)
                estimator = make_estimator(model_name, seed, args.threads)
                if model_name == "mlp" and selected_epoch is not None:
                    estimator.set_params(max_iter=selected_epoch)
                if model_name == "tabm" and selected_epoch is not None:
                    estimator.max_epochs = selected_epoch
                if model_name == "realmlp" and selected_epoch is not None:
                    estimator.set_params(stop_epoch=selected_epoch, val_fraction=0.0)
                fit_started = time.perf_counter()
                fit_estimator(estimator, model_name, train_x, full.train_target, categorical_names)
                fit_seconds = time.perf_counter() - fit_started
                inference_started = time.perf_counter()
                prediction_std = np.asarray(estimator.predict(test_x), dtype=np.float32).reshape(
                    len(full.other_target), -1
                )
                inference_seconds = time.perf_counter() - inference_started
                if prediction_std.shape[1] != 3 or not np.isfinite(prediction_std).all():
                    raise RuntimeError(f"{label}的预测维度或数值非法")
                prediction_raw = protocol.inverse_targets(full.target_processor, prediction_std)
                risk_score = -prediction_raw[:, 0]
                probability = protocol.apply_risk_calibrator(calibrator, risk_score)

                part = outer_test[[DATA.SAMPLE_ID, DATA.GROUP_COLUMN, *DATA.AUDIT_COLUMNS]].copy()
                part.insert(0, "基线模型", label)
                part["外层测试折"] = outer_fold
                part["随机种子"] = seed
                for task_index, task in enumerate(DATA.FoldTargetPreprocessor.task_names):
                    part[f"{task}_真实值"] = full.other_target_raw[:, task_index]
                    part[f"{task}_预测值"] = prediction_raw[:, task_index]
                    part[f"{task}_标准化真实值"] = full.other_target[:, task_index]
                    part[f"{task}_标准化预测值"] = prediction_std[:, task_index]
                part["低表现真实标签"] = full.other_risk
                part["低表现风险分数"] = risk_score
                part["低表现校准概率"] = probability
                part["训练折英语风险阈值"] = full.target_processor.risk_threshold
                prediction_parts.append(part)

                for row in protocol.calculate_metrics(full.other_target_raw, prediction_raw):
                    metric_rows.append(
                        {"基线模型": label, "外层测试折": outer_fold, "随机种子": seed, **row}
                    )
                risk_rows.append(
                    {"基线模型": label, "外层测试折": outer_fold, "随机种子": seed,
                     **safe_risk_metrics(full.other_risk, risk_score, probability)}
                )
                efficiency_rows.append(
                    {
                        "基线模型": label, "外层测试折": outer_fold, "随机种子": seed,
                        "训练耗时秒": fit_seconds,
                        "内部选择耗时秒": selection_seconds,
                        "总拟合耗时秒": selection_seconds + fit_seconds,
                        "测试集推理耗时秒": inference_seconds,
                        "单样本推理毫秒": inference_seconds * 1000.0 / len(outer_test),
                        "模型序列化大小字节": serialized_bytes(estimator),
                        "测试样本数": len(outer_test),
                        "内部高校早停轮次": selected_epoch,
                    }
                )
                print(
                    f"完成 折={outer_fold} 种子={seed} 模型={label} 训练={fit_seconds:.2f}s",
                    flush=True,
                )

    predictions = pd.concat(prediction_parts, ignore_index=True)
    for (label, seed), group in predictions.groupby(
        ["基线模型", "随机种子"], observed=True, sort=False
    ):
        raw_true = np.column_stack([
            group[f"{task}_真实值"].to_numpy(dtype=float)
            for task in DATA.FoldTargetPreprocessor.task_names
        ])
        raw_prediction = np.column_stack([
            group[f"{task}_预测值"].to_numpy(dtype=float)
            for task in DATA.FoldTargetPreprocessor.task_names
        ])
        for row in protocol.calculate_metrics(raw_true, raw_prediction):
            metric_rows.append(
                {"基线模型": label, "外层测试折": "OOF总体", "随机种子": seed, **row}
            )
        risk_rows.append(
            {
                "基线模型": label,
                "外层测试折": "OOF总体",
                "随机种子": seed,
                **safe_risk_metrics(
                    group["低表现真实标签"].to_numpy(),
                    group["低表现风险分数"].to_numpy(),
                    group["低表现校准概率"].to_numpy(),
                ),
            }
        )
    finished_at = datetime.now(timezone.utc).astimezone()
    manifest = {
        "清单版本": 1,
        "研究阶段": "04_强基线对比",
        "运行类型": "冒烟测试" if smoke else "正式训练",
        "开始时间": started_at.isoformat(),
        "结束时间": finished_at.isoformat(),
        "总耗时秒": time.time() - started,
        "外层验证": "固定5折高校隔离",
        "折": list(folds),
        "随机种子": list(seeds),
        "基线": [MODEL_LABELS[name] for name in models],
        "内部高校验证用途": "MLP、TabM、RealMLP早停与全部模型的风险概率校准，不访问外层测试折",
        "超参策略": "预先固定，不使用外层测试折调参",
        "线程数": args.threads,
        "软件环境": {
            "Python": platform.python_version(), "NumPy": np.__version__,
            "pandas": pd.__version__, "scikit-learn": sklearn.__version__,
            **{
                package: importlib.metadata.version(package)
                for package in OPTIONAL_PACKAGES.values()
                if importlib.util.find_spec(package) is not None
            },
        },
        "输入文件SHA256": {
            protocol.DATA_FILE.name: sha256(protocol.DATA_FILE),
            protocol.FOLD_FILE.name: sha256(protocol.FOLD_FILE),
            "run_baselines.py": sha256(Path(__file__)),
        },
    }
    write_outputs(
        output_dir, predictions, metric_rows, risk_rows, efficiency_rows, manifest,
        prefix=args.output_prefix,
    )
    print(f"结果已保存：{output_dir}", flush=True)


def check_protocol(args: argparse.Namespace) -> None:
    frame = protocol.load_protocol_data()
    models = parse_models(args.models)
    missing = missing_packages(models)
    print("强基线协议检查通过（未训练）")
    print(f"样本数={len(frame)}, 高校数={frame[DATA.GROUP_COLUMN].nunique()}")
    print(f"基线={[MODEL_LABELS[name] for name in models]}")
    print(f"缺失可选依赖={missing if missing else '无'}")
    print("正式训练安全锁=开启")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", nargs="?", choices=["check", "smoke", "smoke-all", "train"], default="check"
    )
    parser.add_argument("--models", default=",".join(ALL_MODELS))
    parser.add_argument("--seeds", default="42,3407,2027")
    parser.add_argument("--folds", default="1,2,3,4,5")
    parser.add_argument("--threads", type=int, default=min(16, os.cpu_count() or 1))
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--output-prefix", default="")
    parser.add_argument("--confirm-training", default="")
    args = parser.parse_args()
    if args.threads <= 0:
        parser.error("线程数必须为正")
    if args.command == "smoke":
        args.models = "dummy_mean,elastic_net"
        args.seeds = "42"
        args.folds = "1"
    elif args.command == "smoke-all":
        args.models = ",".join(ALL_MODELS)
        args.seeds = "42"
        args.folds = "1"
    return args


def main() -> None:
    args = parse_args()
    if args.command == "check":
        check_protocol(args)
    else:
        run_experiment(args, smoke=args.command in {"smoke", "smoke-all"})


if __name__ == "__main__":
    main()
