"""核验五折三种子基线输出，并生成与主模型配对的论文指标表。

只读取已经完成的折外预测；不训练、不选择模型、不访问训练折数据。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUTPUT = HERE / "output"
MAIN = ROOT / "03_main_model/output/M2_raw_continuous_encoding_three_seed_ensemble_oof_predictions.csv"
TASKS = (
    "english_performance",
    "non_english_generic_pc1",
    "engineering_project_formulation",
)
SEEDS = {42, 3407, 2027}
FOLDS = {1, 2, 3, 4, 5}


def metric_rows(frame: pd.DataFrame, model: str) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for task in TASKS:
        true = frame[f"{task}_真实值"].to_numpy(dtype=float)
        predicted = frame[f"{task}_预测值_集成均值"].to_numpy(dtype=float)
        error = true - predicted
        rows.append({
            "模型": model,
            "任务": task,
            "样本数": len(frame),
            "RMSE": float(np.sqrt(np.mean(error ** 2))),
            "MAE": float(np.mean(np.abs(error))),
            "R2": float(1 - np.sum(error ** 2) / np.sum((true - true.mean()) ** 2)),
        })
    labels = frame["低表现真实标签"].to_numpy(dtype=int)
    # 不同外层折的原始英语分数刻度虽相同，风险阈值和校准器却按折拟合；
    # 论文既有总体判别指标使用可跨折合并的校准概率，保持相同口径。
    probability = frame["低表现校准概率_集成均值"].to_numpy(dtype=float)
    rows[0]["ROC_AUC"] = float(roc_auc_score(labels, probability))
    rows[0]["PR_AUC"] = float(average_precision_score(labels, probability))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", default="")
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261011)
    args = parser.parse_args()
    if args.bootstrap < 500:
        raise ValueError("高校整群 bootstrap 至少重复 500 次")

    raw_path = OUTPUT / f"{args.prefix}strong_baseline_oof_predictions.csv"
    ensemble_path = OUTPUT / f"{args.prefix}strong_baseline_three_seed_ensemble_predictions.csv"
    manifest_path = OUTPUT / f"{args.prefix}strong_baseline_run_manifest.json"
    raw = pd.read_csv(raw_path)
    ensemble = pd.read_csv(ensemble_path)
    main_frame = pd.read_csv(MAIN).sort_values("样本编号").reset_index(drop=True)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    model_names = list(manifest["基线"])
    if set(manifest["折"]) != FOLDS or set(manifest["随机种子"]) != SEEDS:
        raise ValueError("运行清单不是完整五折三种子协议")
    if len(raw) != len(main_frame) * len(model_names) * len(SEEDS):
        raise ValueError("折外原始预测行数不等于样本数×模型数×种子数")
    if len(ensemble) != len(main_frame) * len(model_names):
        raise ValueError("三种子集成预测行数不等于样本数×模型数")
    if set(raw["基线模型"]) != set(model_names) or set(ensemble["基线模型"]) != set(model_names):
        raise ValueError("模型清单与预测文件不一致")
    if set(raw["随机种子"]) != SEEDS or set(raw["外层测试折"]) != FOLDS:
        raise ValueError("原始预测的折或种子不完整")
    if raw.duplicated(["基线模型", "随机种子", "样本编号"]).any():
        raise ValueError("同一模型、种子、学生出现重复折外预测")
    if ensemble.duplicated(["基线模型", "样本编号"]).any():
        raise ValueError("同一模型、学生出现重复集成预测")

    truth_columns = ["样本编号", "外层测试折", "高校名称", "低表现真实标签"]
    truth_columns += [f"{task}_真实值" for task in TASKS]
    reference = main_frame[truth_columns]
    numeric_truth = ["低表现真实标签", *[f"{task}_真实值" for task in TASKS]]
    predictions = ["低表现风险分数_集成均值", "低表现校准概率_集成均值"]
    predictions += [f"{task}_预测值_集成均值" for task in TASKS]
    metrics: list[dict[str, object]] = metric_rows(main_frame, "ESD-MTMS-Net")
    groups = main_frame["高校名称"].astype(str).to_numpy()
    schools, school_id = np.unique(groups, return_inverse=True)
    school_count = np.bincount(school_id, minlength=len(schools))
    rng = np.random.default_rng(args.seed)
    sampled = rng.integers(0, len(schools), (args.bootstrap, len(schools)))
    weights = np.zeros((args.bootstrap, len(schools)), dtype=np.float64)
    for row, indices in enumerate(sampled):
        weights[row] = np.bincount(indices, minlength=len(schools))
    total_n = weights @ school_count
    y = main_frame["english_performance_真实值"].to_numpy(dtype=float)
    main_error = y - main_frame["english_performance_预测值_集成均值"].to_numpy(dtype=float)
    main_school_sse = np.bincount(school_id, weights=main_error ** 2, minlength=len(schools))
    main_draw_rmse = np.sqrt((weights @ main_school_sse) / total_n)
    main_rmse = float(np.sqrt(np.mean(main_error ** 2)))
    differences: list[dict[str, object]] = []

    for model in model_names:
        frame = ensemble.loc[ensemble["基线模型"].eq(model)].sort_values("样本编号").reset_index(drop=True)
        one = raw.loc[raw["基线模型"].eq(model)]
        if len(one) != len(main_frame) * len(SEEDS) or len(frame) != len(main_frame):
            raise ValueError(f"{model} 的折外预测不完整")
        if not np.array_equal(frame["样本编号"].to_numpy(), reference["样本编号"].to_numpy()):
            raise ValueError(f"{model} 的学生集合与主模型不一致")
        if not frame["外层测试折"].equals(reference["外层测试折"]):
            raise ValueError(f"{model} 的外层高校折与主模型不一致")
        if not frame["高校名称"].astype(str).equals(reference["高校名称"].astype(str)):
            raise ValueError(f"{model} 的高校名称与主模型不一致")
        if not np.allclose(frame[numeric_truth].to_numpy(dtype=float), reference[numeric_truth].to_numpy(dtype=float), rtol=0, atol=1e-5):
            raise ValueError(f"{model} 的真实标签与主模型不一致")
        if not np.isfinite(frame[predictions].to_numpy(dtype=float)).all():
            raise ValueError(f"{model} 的预测存在非有限值")
        metrics.extend(metric_rows(frame, model))
        error = y - frame["english_performance_预测值_集成均值"].to_numpy(dtype=float)
        school_sse = np.bincount(school_id, weights=error ** 2, minlength=len(schools))
        draw_rmse = np.sqrt((weights @ school_sse) / total_n)
        delta = main_draw_rmse - draw_rmse
        differences.append({
            "基线模型": model,
            "比较方向": "ESD-MTMS-Net RMSE减基线RMSE；正值表示基线误差更低",
            "主模型RMSE": main_rmse,
            "基线RMSE": float(np.sqrt(np.mean(error ** 2))),
            "配对差值": main_rmse - float(np.sqrt(np.mean(error ** 2))),
            "95%区间下限": float(np.quantile(delta, 0.025)),
            "95%区间上限": float(np.quantile(delta, 0.975)),
            "高校整群Bootstrap次数": args.bootstrap,
        })

    pd.DataFrame(metrics).to_csv(OUTPUT / "same_protocol_baseline_manuscript_metrics.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(differences).to_csv(OUTPUT / "same_protocol_baseline_paired_difference_from_main_model.csv", index=False, encoding="utf-8-sig")
    (OUTPUT / "same_protocol_baseline_verification_manifest.json").write_text(json.dumps({
        "状态": "通过", "模型数": len(model_names), "模型": model_names,
        "学生数": len(main_frame), "高校数": len(schools), "折数": len(FOLDS),
        "种子数": len(SEEDS), "原始预测行数": len(raw), "集成预测行数": len(ensemble),
        "比较说明": "同一学生、同一高校折、同一真实标签的配对比较；非等预算超参搜索",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"核验通过：{len(model_names)} 模型，{len(main_frame)} 学生，{len(schools)} 高校")


if __name__ == "__main__":
    main()
