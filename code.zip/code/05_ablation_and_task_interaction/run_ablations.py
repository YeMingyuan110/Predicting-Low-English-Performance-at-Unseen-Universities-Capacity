"""消融、任务交互与协同敏感性统一入口。

默认只执行协议检查。正式嵌套融合必须显式使用
``fusion --confirm-training TRAIN``。外层测试折不参与权重选择。
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MAIN_DIR = ROOT / "03_main_model"
BASELINE_DIR = ROOT / "04_baseline_comparison"
OUTPUT_DIR = HERE / "output"
CONFIRMATION_TEXT = "TRAIN"

for directory in (MAIN_DIR, BASELINE_DIR):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))

import train_main as main_protocol  # noqa: E402
from model import AblationFlags, ModelConfig  # noqa: E402


def load_baseline_module() -> Any:
    path = BASELINE_DIR / "run_baselines.py"
    spec = importlib.util.spec_from_file_location("baseline_protocol_for_fusion", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载基线代码：{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


BASELINES = load_baseline_module()
NEURAL_OOF = MAIN_DIR / "output" / "M2_raw_continuous_encoding_oof_predictions.csv"
CATBOOST_OOF = BASELINE_DIR / "output" / "strong_baseline_oof_predictions.csv"


@dataclass(frozen=True)
class AblationSpec:
    key: str
    label: str
    flags: AblationFlags
    task_weights: tuple[float, float, float]


ABLATION_SPECS = (
    AblationSpec("full_v1", "完整V1三任务", AblationFlags(), (0.70, 0.15, 0.15)),
    AblationSpec(
        "no_attention", "去除全局特征注意力",
        AblationFlags(attention=False), (0.70, 0.15, 0.15),
    ),
    AblationSpec(
        "no_multiscale", "去除理论分组多尺度",
        AblationFlags(multiscale=False), (0.70, 0.15, 0.15),
    ),
    AblationSpec(
        "dense_ffn", "Top-K替换为Dense-FFN",
        AblationFlags(topk=False, dense=True), (0.70, 0.15, 0.15),
    ),
    AblationSpec(
        "no_ffn", "去除FFN",
        AblationFlags(topk=False, dense=False), (0.70, 0.15, 0.15),
    ),
    AblationSpec(
        "english_only", "英语单任务",
        AblationFlags(), (1.0, 0.0, 0.0),
    ),
    AblationSpec(
        "english_nonenglish", "英语+非英语双任务",
        AblationFlags(), (0.8235294118, 0.1764705882, 0.0),
    ),
)


def parse_specs(text: str) -> tuple[AblationSpec, ...]:
    requested = tuple(dict.fromkeys(value.strip() for value in text.split(",") if value.strip()))
    by_key = {spec.key: spec for spec in ABLATION_SPECS}
    unknown = sorted(set(requested).difference(by_key))
    if not requested or unknown:
        raise ValueError(f"未知消融配置 {unknown}；可选={list(by_key)}")
    return tuple(by_key[key] for key in requested)


def parse_ints(text: str) -> tuple[int, ...]:
    values = tuple(dict.fromkeys(int(value.strip()) for value in text.split(",") if value.strip()))
    if not values:
        raise ValueError("至少需要一个整数")
    return values


def select_weight(
    target: np.ndarray, neural: np.ndarray, tree: np.ndarray
) -> tuple[float, pd.DataFrame]:
    """只以内部高校验证集的英语 RMSE 选神经网络权重。"""

    rows = []
    for alpha in np.linspace(0.0, 1.0, 101):
        prediction = alpha * neural[:, 0] + (1.0 - alpha) * tree[:, 0]
        rmse = float(np.sqrt(np.mean(np.square(prediction - target[:, 0]))))
        rows.append({"神经网络权重": float(alpha), "内部验证英语RMSE": rmse})
    table = pd.DataFrame(rows)
    best = table.sort_values(
        ["内部验证英语RMSE", "神经网络权重"], kind="stable"
    ).iloc[0]
    return float(best["神经网络权重"]), table


def load_outer_predictions(seed: int, fold: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    neural = pd.read_csv(NEURAL_OOF)
    neural = neural.loc[
        neural["随机种子"].eq(seed) & neural["外层测试折"].eq(fold)
    ].copy()
    tree = pd.read_csv(CATBOOST_OOF)
    tree = tree.loc[
        tree["基线模型"].eq("CatBoost")
        & tree["随机种子"].eq(seed)
        & tree["外层测试折"].eq(fold)
    ].copy()
    if len(neural) == 0 or len(neural) != len(tree):
        raise RuntimeError(f"折{fold}种子{seed}的两类外层预测不完整")
    return neural, tree


def safe_risk_metrics(labels: np.ndarray, scores: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    probabilities = np.clip(probabilities, 1.0e-7, 1.0 - 1.0e-7)
    return {
        "ROC_AUC": float(roc_auc_score(labels, scores)),
        "PR_AUC": float(average_precision_score(labels, scores)),
        "Brier": float(brier_score_loss(labels, probabilities)),
        "LogLoss": float(log_loss(labels, probabilities, labels=[0, 1])),
    }


def run_ablation_screen(args: argparse.Namespace) -> None:
    """在相同高校隔离协议下运行结构与任务组合消融。"""

    if args.confirm_training != CONFIRMATION_TEXT:
        raise RuntimeError(f"训练被安全锁阻止；请添加 --confirm-training {CONFIRMATION_TEXT}")
    specs = parse_specs(args.specs)
    seeds = parse_ints(args.seeds)
    folds = parse_ints(args.folds)
    if not set(folds).issubset({1, 2, 3, 4, 5}):
        raise ValueError("外层折只能为1--5")
    frame = main_protocol.load_protocol_data()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.set_float32_matmul_precision("high")
    model_config = ModelConfig(variant="v1")
    base_train = main_protocol.TrainConfig(
        max_epochs=args.max_epochs, patience=args.patience
    )
    started = time.time()
    prediction_parts: list[pd.DataFrame] = []
    metric_rows: list[dict[str, Any]] = []
    risk_rows: list[dict[str, Any]] = []
    efficiency_rows: list[dict[str, Any]] = []

    for fold in folds:
        outer_train = frame.loc[frame["外层测试折"].ne(fold)].copy()
        outer_test = frame.loc[frame["外层测试折"].eq(fold)].copy()
        full = main_protocol.prepare_split(outer_train, outer_test, "raw")
        full_train_data = main_protocol.make_dataset(
            full.train_continuous, full.train_categorical, full.train_target, full.train_risk
        )
        full_test_data = main_protocol.make_dataset(
            full.other_continuous, full.other_categorical, full.other_target, full.other_risk
        )
        for seed in seeds:
            selection_train, selection_validation = main_protocol.university_validation_split(
                outer_train, seed
            )
            selection = main_protocol.prepare_split(
                selection_train, selection_validation, "raw"
            )
            selection_train_data = main_protocol.make_dataset(
                selection.train_continuous, selection.train_categorical,
                selection.train_target, selection.train_risk,
            )
            selection_validation_data = main_protocol.make_dataset(
                selection.other_continuous, selection.other_categorical,
                selection.other_target, selection.other_risk,
            )
            for spec in specs:
                unit_started = time.perf_counter()
                loss_config = main_protocol.LossConfig(
                    protocol="M2", task_weights=spec.task_weights
                )
                main_protocol.set_seed(seed)
                selection_model = main_protocol.make_model(
                    selection, model_config, spec.flags
                )
                selected = main_protocol.fit_model(
                    selection_model, selection_train_data, selection_validation_data,
                    base_train, loss_config, seed, device,
                )
                selection_std = main_protocol.predict(
                    selection_model, selection_validation_data, base_train, device
                )
                selection_raw = main_protocol.inverse_targets(
                    selection.target_processor, selection_std
                )
                calibration_labels = (
                    selection_validation["大学英语成绩"].to_numpy(dtype=float)
                    <= full.target_processor.risk_threshold
                ).astype(np.int8)
                calibrator = main_protocol.fit_risk_calibrator(
                    -selection_raw[:, 0], calibration_labels
                )
                refit_config = replace(
                    base_train,
                    max_epochs=max(1, selected.best_epoch),
                    patience=max(1, selected.best_epoch + 1),
                    warmup_epochs=min(base_train.warmup_epochs, max(0, selected.best_epoch - 1)),
                )
                main_protocol.set_seed(seed)
                final_model = main_protocol.make_model(full, model_config, spec.flags)
                refitted = main_protocol.fit_model(
                    final_model, full_train_data, None, refit_config,
                    loss_config, seed, device,
                )
                inference_started = time.perf_counter()
                prediction_std = main_protocol.predict(
                    final_model, full_test_data, refit_config, device
                )
                inference_seconds = time.perf_counter() - inference_started
                prediction_raw = main_protocol.inverse_targets(
                    full.target_processor, prediction_std
                )
                risk_score = -prediction_raw[:, 0]
                probability = main_protocol.apply_risk_calibrator(calibrator, risk_score)
                part = outer_test[
                    [main_protocol.DATA.SAMPLE_ID, main_protocol.DATA.GROUP_COLUMN,
                     *main_protocol.DATA.AUDIT_COLUMNS]
                ].copy()
                part.insert(0, "消融配置", spec.label)
                part["配置键"] = spec.key
                part["外层测试折"] = fold
                part["随机种子"] = seed
                for task_index, task in enumerate(main_protocol.DATA.FoldTargetPreprocessor.task_names):
                    part[f"{task}_真实值"] = full.other_target_raw[:, task_index]
                    part[f"{task}_预测值"] = prediction_raw[:, task_index]
                    part[f"{task}_标准化真实值"] = full.other_target[:, task_index]
                    part[f"{task}_标准化预测值"] = prediction_std[:, task_index]
                part["低表现真实标签"] = full.other_risk
                part["低表现风险分数"] = risk_score
                part["低表现校准概率"] = probability
                part["训练折英语风险阈值"] = full.target_processor.risk_threshold
                prediction_parts.append(part)
                active = np.asarray(spec.task_weights) > 0.0
                for task_index, row in enumerate(
                    main_protocol.calculate_metrics(full.other_target_raw, prediction_raw)
                ):
                    metric_rows.append(
                        {"消融配置": spec.label, "配置键": spec.key,
                         "外层测试折": fold, "随机种子": seed,
                         "是否活动任务": bool(active[task_index]), **row}
                    )
                risk_rows.append(
                    {"消融配置": spec.label, "配置键": spec.key,
                     "外层测试折": fold, "随机种子": seed,
                     **safe_risk_metrics(full.other_risk, risk_score, probability)}
                )
                efficiency_rows.append(
                    {"消融配置": spec.label, "配置键": spec.key,
                     "外层测试折": fold, "随机种子": seed,
                     "内部最佳轮次": selected.best_epoch,
                     "内部早停耗时秒": selected.elapsed_seconds,
                     "完整训练折重拟合耗时秒": refitted.elapsed_seconds,
                     "总耗时秒": time.perf_counter() - unit_started,
                     "峰值GPU显存MB": max(
                         selected.peak_gpu_memory_mb, refitted.peak_gpu_memory_mb
                     ),
                     "模型参数量": sum(p.numel() for p in final_model.parameters()),
                     "测试集推理耗时秒": inference_seconds}
                )
                print(
                    f"完成 配置={spec.label} 折={fold} 种子={seed} "
                    f"早停轮次={selected.best_epoch}", flush=True
                )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    predictions = pd.concat(prediction_parts, ignore_index=True)
    for (label, key, seed), group in predictions.groupby(
        ["消融配置", "配置键", "随机种子"], observed=True, sort=False
    ):
        raw_true = np.column_stack([
            group[f"{task}_真实值"]
            for task in main_protocol.DATA.FoldTargetPreprocessor.task_names
        ])
        raw_prediction = np.column_stack([
            group[f"{task}_预测值"]
            for task in main_protocol.DATA.FoldTargetPreprocessor.task_names
        ])
        spec = next(item for item in specs if item.key == key)
        active = np.asarray(spec.task_weights) > 0.0
        for task_index, row in enumerate(main_protocol.calculate_metrics(raw_true, raw_prediction)):
            metric_rows.append(
                {"消融配置": label, "配置键": key,
                 "外层测试折": "OOF总体", "随机种子": seed,
                 "是否活动任务": bool(active[task_index]), **row}
            )
        risk_rows.append(
            {"消融配置": label, "配置键": key,
             "外层测试折": "OOF总体", "随机种子": seed,
             **safe_risk_metrics(
                 group["低表现真实标签"].to_numpy(),
                 group["低表现风险分数"].to_numpy(),
                 group["低表现校准概率"].to_numpy(),
             )}
        )
    predictions.to_csv(
        OUTPUT_DIR / "formal_ablation_oof_predictions.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(metric_rows).to_csv(
        OUTPUT_DIR / "formal_ablation_fold_and_overall_metrics.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(risk_rows).to_csv(
        OUTPUT_DIR / "formal_ablation_risk_metrics.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(efficiency_rows).to_csv(
        OUTPUT_DIR / "formal_ablation_training_inference_efficiency.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        [{"配置键": spec.key, "消融配置": spec.label,
          **{f"结构_{key}": value for key, value in asdict(spec.flags).items()},
          "英语任务权重": spec.task_weights[0],
          "非英语任务权重": spec.task_weights[1],
          "工程任务权重": spec.task_weights[2]} for spec in specs]
    ).to_csv(OUTPUT_DIR / "formal_ablation_configuration.csv", index=False, encoding="utf-8-sig")
    manifest = {
        "协议": "固定高校隔离五折+高校隔离内部早停",
        "训练目标": "M2",
        "配置": [spec.label for spec in specs],
        "随机种子": list(seeds), "外层折": list(folds),
        "设备": str(device), "总耗时秒": time.time() - started,
        "生成时间": datetime.now(timezone.utc).astimezone().isoformat(),
        "保存检查点": False,
        "基础模型配置": asdict(model_config), "基础训练配置": asdict(base_train),
    }
    (OUTPUT_DIR / "formal_ablation_run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def run_fusion(args: argparse.Namespace) -> None:
    if args.confirm_training != CONFIRMATION_TEXT:
        raise RuntimeError(f"训练被安全锁阻止；请添加 --confirm-training {CONFIRMATION_TEXT}")
    for path in (NEURAL_OOF, CATBOOST_OOF):
        if not path.is_file():
            raise FileNotFoundError(f"缺少基模型样本外预测：{path}")
    seeds = parse_ints(args.seeds)
    folds = parse_ints(args.folds)
    if not set(folds).issubset({1, 2, 3, 4, 5}):
        raise ValueError("外层折只能为1--5")
    frame = main_protocol.load_protocol_data()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_config = ModelConfig(variant="v1")
    train_config = main_protocol.TrainConfig(max_epochs=args.max_epochs, patience=args.patience)
    loss_config = main_protocol.LossConfig(protocol="M2")
    started = time.time()
    prediction_parts: list[pd.DataFrame] = []
    metric_rows: list[dict[str, Any]] = []
    risk_rows: list[dict[str, Any]] = []
    weight_rows: list[dict[str, Any]] = []
    trace_parts: list[pd.DataFrame] = []

    for fold in folds:
        outer_train = frame.loc[frame["外层测试折"].ne(fold)].copy()
        outer_test = frame.loc[frame["外层测试折"].eq(fold)].copy()
        full = main_protocol.prepare_split(outer_train, outer_test, "raw")
        for seed in seeds:
            fit_started = time.perf_counter()
            selection_train, selection_validation = main_protocol.university_validation_split(outer_train, seed)
            selection = main_protocol.prepare_split(selection_train, selection_validation, "raw")
            main_protocol.set_seed(seed)
            neural_model = main_protocol.make_model(selection, model_config)
            selection_train_data = main_protocol.make_dataset(
                selection.train_continuous, selection.train_categorical,
                selection.train_target, selection.train_risk,
            )
            selection_validation_data = main_protocol.make_dataset(
                selection.other_continuous, selection.other_categorical,
                selection.other_target, selection.other_risk,
            )
            fitted = main_protocol.fit_model(
                neural_model, selection_train_data, selection_validation_data,
                train_config, loss_config, seed, device,
            )
            neural_std = main_protocol.predict(
                neural_model, selection_validation_data, train_config, device
            )
            neural_raw = main_protocol.inverse_targets(selection.target_processor, neural_std)

            train_x, validation_x, categories = BASELINES.design_matrices(selection, "catboost")
            tree_model = BASELINES.make_estimator("catboost", seed, args.threads)
            BASELINES.fit_estimator(
                tree_model, "catboost", train_x, selection.train_target, categories
            )
            tree_std = np.asarray(tree_model.predict(validation_x), dtype=float)
            tree_raw = main_protocol.inverse_targets(selection.target_processor, tree_std)
            alpha, trace = select_weight(selection.other_target_raw, neural_raw, tree_raw)
            trace.insert(0, "外层测试折", fold)
            trace.insert(1, "随机种子", seed)
            trace_parts.append(trace)
            validation_fused = alpha * neural_raw + (1.0 - alpha) * tree_raw
            calibration_labels = (
                selection_validation["大学英语成绩"].to_numpy(dtype=float)
                <= full.target_processor.risk_threshold
            ).astype(np.int8)
            calibrator = main_protocol.fit_risk_calibrator(-validation_fused[:, 0], calibration_labels)

            neural_outer, tree_outer = load_outer_predictions(seed, fold)
            key = [main_protocol.DATA.SAMPLE_ID, "外层测试折", "随机种子"]
            tree_columns = key + [
                f"{task}_预测值" for task in main_protocol.DATA.FoldTargetPreprocessor.task_names
            ]
            merged = neural_outer.merge(
                tree_outer[tree_columns], on=key,
                suffixes=("_神经网络", "_CatBoost"), validate="one_to_one",
            )
            raw_prediction = np.column_stack(
                [
                    alpha * merged[f"{task}_预测值_神经网络"].to_numpy(float)
                    + (1.0 - alpha) * merged[f"{task}_预测值_CatBoost"].to_numpy(float)
                    for task in main_protocol.DATA.FoldTargetPreprocessor.task_names
                ]
            )
            raw_true = np.column_stack(
                [
                    merged[f"{task}_真实值"].to_numpy(float)
                    for task in main_protocol.DATA.FoldTargetPreprocessor.task_names
                ]
            )
            result = merged[
                [main_protocol.DATA.SAMPLE_ID, "外层测试折", "随机种子",
                 main_protocol.DATA.GROUP_COLUMN, *main_protocol.DATA.AUDIT_COLUMNS]
            ].copy()
            for index, task in enumerate(main_protocol.DATA.FoldTargetPreprocessor.task_names):
                result[f"{task}_真实值"] = raw_true[:, index]
                result[f"{task}_预测值"] = raw_prediction[:, index]
            result["低表现真实标签"] = merged["低表现真实标签"].to_numpy()
            result["训练折英语风险阈值"] = full.target_processor.risk_threshold
            result["神经网络权重"] = alpha
            result["低表现风险分数"] = -raw_prediction[:, 0]
            result["低表现校准概率"] = main_protocol.apply_risk_calibrator(
                calibrator, result["低表现风险分数"].to_numpy()
            )
            prediction_parts.append(result)
            for row in main_protocol.calculate_metrics(raw_true, raw_prediction):
                metric_rows.append({"外层测试折": fold, "随机种子": seed, **row})
            risk_rows.append(
                {"外层测试折": fold, "随机种子": seed,
                 **safe_risk_metrics(
                     result["低表现真实标签"].to_numpy(),
                     result["低表现风险分数"].to_numpy(),
                     result["低表现校准概率"].to_numpy(),
                 )}
            )
            weight_rows.append(
                {"外层测试折": fold, "随机种子": seed,
                 "神经网络权重": alpha, "CatBoost权重": 1.0 - alpha,
                 "神经网络内部最佳轮次": fitted.best_epoch,
                 "权重学习耗时秒": time.perf_counter() - fit_started}
            )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    predictions = pd.concat(prediction_parts, ignore_index=True)
    predictions.to_csv(OUTPUT_DIR / "collaborative_fusion_oof_predictions.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(metric_rows).to_csv(OUTPUT_DIR / "collaborative_fusion_fold_metrics.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(risk_rows).to_csv(OUTPUT_DIR / "collaborative_fusion_risk_metrics.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(weight_rows).to_csv(OUTPUT_DIR / "collaborative_fusion_internal_weights.csv", index=False, encoding="utf-8-sig")
    pd.concat(trace_parts, ignore_index=True).to_csv(
        OUTPUT_DIR / "collaborative_fusion_weight_selection_trace.csv", index=False, encoding="utf-8-sig"
    )
    manifest = {
        "协议": "每个外层训练折内部高校隔离学习融合权重",
        "权重目标": "内部验证英语RMSE",
        "候选权重": "0.00--1.00，步长0.01",
        "随机种子": list(seeds), "外层折": list(folds), "设备": str(device),
        "总耗时秒": time.time() - started,
        "生成时间": datetime.now(timezone.utc).astimezone().isoformat(),
        "模型配置": asdict(model_config), "训练配置": asdict(train_config),
        "损失配置": asdict(loss_config),
    }
    (OUTPUT_DIR / "collaborative_fusion_run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def check() -> None:
    frame = main_protocol.load_protocol_data()
    print("消融与协同实验协议检查通过（未训练）")
    print(f"样本数={len(frame)}, 高校数={frame[main_protocol.DATA.GROUP_COLUMN].nunique()}")
    print(f"主模型外层预测={NEURAL_OOF.is_file()}")
    print(f"CatBoost外层预测={CATBOOST_OOF.is_file()}")
    print("正式融合权重将只在每个外层训练折内部学习")
    print("可用消融=" + ", ".join(f"{spec.key}:{spec.label}" for spec in ABLATION_SPECS))


def summarize_existing() -> None:
    """对已完成的多种子样本外预测集成，不重新训练。"""

    path = OUTPUT_DIR / "collaborative_fusion_oof_predictions.csv"
    if not path.is_file():
        raise FileNotFoundError(f"缺少待汇总文件：{path}")
    predictions = pd.read_csv(path)
    tasks = list(main_protocol.DATA.FoldTargetPreprocessor.task_names)
    value_columns = [f"{task}_预测值" for task in tasks] + [
        "低表现风险分数", "低表现校准概率"
    ]
    keys = [main_protocol.DATA.SAMPLE_ID, "外层测试折"]
    grouped = predictions.groupby(keys, observed=True, sort=False)
    means = grouped[value_columns].mean().add_suffix("_集成均值")
    deviations = grouped[value_columns].std(ddof=0).add_suffix("_种子标准差")
    metadata = [
        main_protocol.DATA.GROUP_COLUMN, *main_protocol.DATA.AUDIT_COLUMNS,
        *[f"{task}_真实值" for task in tasks], "低表现真实标签",
        "训练折英语风险阈值",
    ]
    ensemble = grouped[metadata].first().join(means).join(deviations).reset_index()
    ensemble.to_csv(
        OUTPUT_DIR / "collaborative_fusion_three_seed_ensemble_predictions.csv", index=False, encoding="utf-8-sig"
    )
    raw_true = np.column_stack([ensemble[f"{task}_真实值"] for task in tasks])
    raw_prediction = np.column_stack(
        [ensemble[f"{task}_预测值_集成均值"] for task in tasks]
    )
    pd.DataFrame(main_protocol.calculate_metrics(raw_true, raw_prediction)).to_csv(
        OUTPUT_DIR / "collaborative_fusion_three_seed_ensemble_metrics.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        [
            safe_risk_metrics(
                ensemble["低表现真实标签"].to_numpy(),
                ensemble["低表现风险分数_集成均值"].to_numpy(),
                ensemble["低表现校准概率_集成均值"].to_numpy(),
            )
        ]
    ).to_csv(OUTPUT_DIR / "collaborative_fusion_three_seed_risk_metrics.csv", index=False, encoding="utf-8-sig")
    print(f"已汇总{predictions['随机种子'].nunique()}个种子，样本数={len(ensemble)}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", nargs="?",
        choices=["check", "ablation-screen", "fusion", "summarize"], default="check"
    )
    parser.add_argument("--seeds", default="42")
    parser.add_argument("--folds", default="1,2,3,4,5")
    parser.add_argument("--max-epochs", type=int, default=300)
    parser.add_argument("--patience", type=int, default=45)
    parser.add_argument("--threads", type=int, default=20)
    parser.add_argument("--specs", default=",".join(spec.key for spec in ABLATION_SPECS))
    parser.add_argument("--confirm-training", default="")
    args = parser.parse_args()
    if args.max_epochs <= 0 or args.patience <= 0 or args.threads <= 0:
        parser.error("轮数、耐心和线程数必须为正")
    return args


def main() -> None:
    args = parse_args()
    if args.command == "check":
        check()
    elif args.command == "ablation-screen":
        run_ablation_screen(args)
    elif args.command == "fusion":
        run_fusion(args)
    else:
        summarize_existing()


if __name__ == "__main__":
    main()
