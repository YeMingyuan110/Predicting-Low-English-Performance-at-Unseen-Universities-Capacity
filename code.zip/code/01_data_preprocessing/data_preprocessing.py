"""数据清洗、固定高校折和无泄漏折内预处理。

本文件是数据阶段唯一的 Python 入口，不训练模型。运行后只保存两份后续实验
真正需要的数据：确定性清洗后的基础表和固定的五折高校划分。任何需要从数据
学习的变换（插补、标准化、类别词表、PC1、风险阈值和 PLE 节点）仍在训练折
内部拟合，禁止把全样本拟合后的矩阵保存成“处理后数据”。
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import OrdinalEncoder, StandardScaler


ROOT = Path(__file__).resolve().parent
DEFAULT_WORKBOOK = ROOT / "source_data.xlsx"
DEFAULT_SHEET = "高校学业表现数据"
OUTPUT_DIR = ROOT / "output"
MISSING_TOKEN = "__MISSING__"
SAMPLE_ID = "样本编号"

EXPECTED_COLUMNS = [
    "性别", "父亲受教育程度", "母亲受教育程度", "父亲职业", "母亲职业",
    "家庭社会经济阶层", "SISBEN社会福利等级", "家庭人口数", "家庭互联网",
    "电视", "电脑", "洗衣机", "微波炉", "汽车", "DVD设备", "冰箱", "固定电话",
    "手机", "家庭收入", "学生就业情况", "高中学校名称", "高中学校性质",
    "高中学校类型", "高中数学成绩", "高中批判性阅读成绩", "高中公民素养成绩",
    "高中生物成绩", "高中英语成绩", "高校名称", "工程专业", "大学定量推理成绩",
    "大学批判性阅读成绩", "大学公民素养成绩", "大学英语成绩", "大学书面表达成绩",
    "工程项目规划成绩", "大学综合总分", "百分位排名", "双十分位等级", "四分位等级",
    "学生社会经济水平", "高校社会经济水平",
]

INITIAL_ABILITY = [
    "高中数学成绩", "高中批判性阅读成绩", "高中公民素养成绩", "高中生物成绩", "高中英语成绩"
]
ENVIRONMENT = ["高中学校性质", "高中学校类型", "工程专业"]
HOUSEHOLD = [
    "父亲受教育程度", "母亲受教育程度", "父亲职业", "母亲职业", "家庭社会经济阶层",
    "SISBEN社会福利等级", "家庭收入", "家庭人口数", "学生就业情况",
]
DIGITAL = ["家庭互联网", "电脑", "手机"]
ASSETS = ["电视", "洗衣机", "微波炉", "汽车", "DVD设备", "冰箱", "固定电话"]
GROUP_COLUMN = "高校名称"
NON_ENGLISH_TARGETS = ["大学定量推理成绩", "大学批判性阅读成绩", "大学公民素养成绩"]
CONTINUOUS_INPUTS = [*INITIAL_ABILITY, "DAI"]
CATEGORICAL_INPUTS = [*ENVIRONMENT, *HOUSEHOLD, *ASSETS]
MODEL_INPUTS = [*CONTINUOUS_INPUTS, *CATEGORICAL_INPUTS]
MODEL_TARGET_COLUMNS = [*NON_ENGLISH_TARGETS, "大学英语成绩", "工程项目规划成绩"]
AUDIT_COLUMNS = ["性别", "学生社会经济水平", "高校社会经济水平"]

if len(MODEL_INPUTS) != 25 or len(set(MODEL_INPUTS)) != 25:
    raise RuntimeError("固定主协议必须恰好包含25个互不重复的模型输入")


def validate_schema(columns: Iterable[str]) -> None:
    actual = [str(column).strip() for column in columns]
    missing = [column for column in EXPECTED_COLUMNS if column not in actual]
    extra = [column for column in actual if column not in EXPECTED_COLUMNS]
    if actual != EXPECTED_COLUMNS:
        raise ValueError(
            "工作簿字段契约不匹配；拒绝按位置静默读取。"
            f" missing={missing}, extra={extra}, order_changed={not missing and not extra}"
        )


def load_dataset(path: Path | str = DEFAULT_WORKBOOK, sheet_name: str = DEFAULT_SHEET) -> pd.DataFrame:
    frame = pd.read_excel(Path(path), sheet_name=sheet_name, engine="openpyxl")
    frame.columns = [str(column).strip() for column in frame.columns]
    validate_schema(frame.columns)
    for column in frame.select_dtypes(include=["object", "string"]).columns:
        frame[column] = frame[column].astype("string").str.strip()
    return frame


def add_dai(frame: pd.DataFrame) -> pd.DataFrame:
    """构造透明的 0--3 数字可及性计数；未知类别直接报错。"""
    result = frame.copy()
    if "DAI" in result.columns and not set(DIGITAL).issubset(result.columns):
        result["DAI"] = pd.to_numeric(result["DAI"], errors="raise")
        return result
    value_map = {"是": 1.0, "否": 0.0}
    mapped = []
    invalid: dict[str, list[str]] = {}
    for column in DIGITAL:
        values = result[column].astype("string").str.strip()
        bad = sorted(set(values.dropna().unique()).difference(value_map))
        if bad:
            invalid[column] = bad
        mapped.append(values.map(value_map).to_numpy(dtype=float))
    if invalid:
        raise ValueError(f"DAI 字段存在未定义取值: {invalid}")
    matrix = np.column_stack(mapped)
    result["DAI"] = np.nansum(matrix, axis=1)
    result.loc[np.isnan(matrix).all(axis=1), "DAI"] = np.nan
    return result


def clean_categories(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    result = frame[list(columns)].copy()
    for column in result.columns:
        values = result[column].astype("string").str.strip().replace({"": pd.NA})
        if column in HOUSEHOLD:
            values = values.replace({"0": pd.NA})
        result[column] = values.fillna(MISSING_TOKEN)
    return result


def positive_pc1_fit_transform(
    train: pd.DataFrame, other: pd.DataFrame, columns: Sequence[str]
) -> tuple[np.ndarray, np.ndarray, PCA, StandardScaler, float]:
    scaler = StandardScaler().fit(train[list(columns)].to_numpy(dtype=float))
    train_scaled = scaler.transform(train[list(columns)].to_numpy(dtype=float))
    other_scaled = scaler.transform(other[list(columns)].to_numpy(dtype=float))
    pca = PCA(n_components=1, random_state=42).fit(train_scaled)
    train_raw = pca.transform(train_scaled)[:, 0]
    anchor = train_scaled.mean(axis=1)
    correlation = np.corrcoef(train_raw, anchor)[0, 1]
    sign = -1.0 if np.isfinite(correlation) and correlation < 0 else 1.0
    return train_raw * sign, pca.transform(other_scaled)[:, 0] * sign, pca, scaler, sign


def build_model_input_table(frame: pd.DataFrame) -> pd.DataFrame:
    """只执行不依赖全样本统计量的确定性清洗与 DAI 构造。"""
    derived = add_dai(frame)
    result = pd.DataFrame({SAMPLE_ID: np.arange(1, len(frame) + 1, dtype=np.int64)})
    result[GROUP_COLUMN] = frame[GROUP_COLUMN].astype("string").str.strip()

    for column in AUDIT_COLUMNS:
        result[column] = frame[column]
    for column in CONTINUOUS_INPUTS:
        result[column] = pd.to_numeric(derived[column], errors="raise")

    cleaned_categories = clean_categories(derived, CATEGORICAL_INPUTS)
    for column in CATEGORICAL_INPUTS:
        result[column] = cleaned_categories[column]

    for column in MODEL_TARGET_COLUMNS:
        result[column] = pd.to_numeric(frame[column], errors="raise")

    if result[GROUP_COLUMN].isna().any() or result[GROUP_COLUMN].eq("").any():
        raise ValueError("高校名称存在缺失，无法执行高校隔离验证")
    if result[MODEL_TARGET_COLUMNS].isna().any().any():
        raise ValueError("模型结果变量存在缺失；结果变量禁止插补")
    if result[SAMPLE_ID].duplicated().any():
        raise RuntimeError("样本编号生成失败")
    return result


def build_outer_folds(frame: pd.DataFrame, n_splits: int = 5) -> pd.DataFrame:
    """固定整所高校留出的外层折；同一高校只能出现在一个测试折。"""
    fold = np.zeros(len(frame), dtype=np.int8)
    splitter = GroupKFold(n_splits=n_splits)
    for fold_number, (_, test_index) in enumerate(
        splitter.split(frame, groups=frame[GROUP_COLUMN]), start=1
    ):
        fold[test_index] = fold_number
    if (fold == 0).any():
        raise RuntimeError("存在未分配外层折的样本")

    result = frame[[SAMPLE_ID, GROUP_COLUMN]].copy()
    result["外层测试折"] = fold
    university_fold_counts = result.groupby(GROUP_COLUMN, observed=True)["外层测试折"].nunique()
    if not university_fold_counts.eq(1).all():
        raise RuntimeError("同一高校被分配到多个外层测试折")
    return result


def save_prepared_data(frame: pd.DataFrame, output_dir: Path) -> tuple[Path, Path]:
    """保存两份核心数据；不生成审计报告或全局标准化矩阵。"""
    output_dir.mkdir(parents=True, exist_ok=True)
    model_table = build_model_input_table(frame)
    fold_table = build_outer_folds(model_table)
    data_path = output_dir / "model_input_data.csv"
    fold_path = output_dir / "university_five_fold_assignment.csv"
    model_table.to_csv(data_path, index=False, encoding="utf-8-sig")
    fold_table.to_csv(fold_path, index=False, encoding="utf-8-sig")
    return data_path, fold_path


@dataclass
class PreparedFeatures:
    continuous: np.ndarray
    categorical: np.ndarray
    continuous_names: list[str]
    categorical_names: list[str]
    categorical_cardinalities: list[int]


class FoldFeaturePreprocessor:
    def fit(self, frame: pd.DataFrame) -> "FoldFeaturePreprocessor":
        derived = add_dai(frame)
        self.numeric_imputer = SimpleImputer(strategy="median", add_indicator=True)
        numeric = self.numeric_imputer.fit_transform(derived[CONTINUOUS_INPUTS])
        self.numeric_scaler = StandardScaler().fit(numeric)
        indicators = [int(i) for i in self.numeric_imputer.indicator_.features_]
        self.continuous_names = CONTINUOUS_INPUTS + [f"{CONTINUOUS_INPUTS[i]}__missing" for i in indicators]
        categories = clean_categories(derived, CATEGORICAL_INPUTS)
        self.category_encoder = OrdinalEncoder(
            handle_unknown="use_encoded_value", unknown_value=-1, encoded_missing_value=-1, dtype=np.float64
        ).fit(categories)
        self.categorical_cardinalities = [len(values) + 1 for values in self.category_encoder.categories_]
        self.fit_row_count = len(frame)
        return self

    def transform(self, frame: pd.DataFrame) -> PreparedFeatures:
        if not hasattr(self, "numeric_scaler"):
            raise RuntimeError("必须先在训练折 fit")
        derived = add_dai(frame)
        numeric = self.numeric_imputer.transform(derived[CONTINUOUS_INPUTS])
        continuous = self.numeric_scaler.transform(numeric).astype(np.float32)
        encoded = self.category_encoder.transform(clean_categories(derived, CATEGORICAL_INPUTS))
        for index, known in enumerate(self.category_encoder.categories_):
            encoded[:, index] = np.where(encoded[:, index] < 0, len(known), encoded[:, index])
        return PreparedFeatures(
            continuous=continuous,
            categorical=np.rint(encoded).astype(np.int64),
            continuous_names=list(self.continuous_names),
            categorical_names=list(CATEGORICAL_INPUTS),
            categorical_cardinalities=list(self.categorical_cardinalities),
        )


class FoldTargetPreprocessor:
    task_names = ["english_performance", "non_english_generic_pc1", "engineering_project_formulation"]

    def fit(self, frame: pd.DataFrame) -> "FoldTargetPreprocessor":
        pc1_train, _, self.pca, self.pc_scaler, self.pc_sign = positive_pc1_fit_transform(
            frame, frame, NON_ENGLISH_TARGETS
        )
        raw = np.column_stack([
            frame["大学英语成绩"].to_numpy(dtype=float), pc1_train,
            frame["工程项目规划成绩"].to_numpy(dtype=float),
        ])
        if not np.isfinite(raw).all():
            raise ValueError("结果变量存在缺失或非有限值；禁止插补结果")
        self.target_scaler = StandardScaler().fit(raw)
        self.risk_threshold = float(frame["大学英语成绩"].quantile(0.25))
        self.fit_row_count = len(frame)
        return self

    def _raw(self, frame: pd.DataFrame) -> np.ndarray:
        scaled = self.pc_scaler.transform(frame[NON_ENGLISH_TARGETS].to_numpy(dtype=float))
        pc1 = self.pca.transform(scaled)[:, 0] * self.pc_sign
        return np.column_stack([
            frame["大学英语成绩"].to_numpy(dtype=float), pc1,
            frame["工程项目规划成绩"].to_numpy(dtype=float),
        ])

    def transform(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        raw = self._raw(frame)
        if not np.isfinite(raw).all():
            raise ValueError("结果变量存在缺失或非有限值")
        standardized = self.target_scaler.transform(raw).astype(np.float32)
        low_performance = (raw[:, 0] <= self.risk_threshold).astype(np.int8)
        return standardized, raw.astype(np.float32), low_performance


def validate_all_folds(frame: pd.DataFrame) -> None:
    """逐折验证无泄漏处理器；成功时不额外写报告文件。"""
    splitter = GroupKFold(n_splits=5)
    for fold_number, (train_index, test_index) in enumerate(
        splitter.split(frame, groups=frame[GROUP_COLUMN]), start=1
    ):
        train = frame.iloc[train_index].copy()
        test = frame.iloc[test_index].copy()
        if set(train[GROUP_COLUMN]).intersection(test[GROUP_COLUMN]):
            raise RuntimeError(f"第{fold_number}折发生高校泄漏")

        feature_preprocessor = FoldFeaturePreprocessor().fit(train)
        train_x = feature_preprocessor.transform(train)
        test_x = feature_preprocessor.transform(test)
        target_preprocessor = FoldTargetPreprocessor().fit(train)
        train_y, _, _ = target_preprocessor.transform(train)
        test_y, _, _ = target_preprocessor.transform(test)

        arrays = [train_x.continuous, test_x.continuous, train_y, test_y]
        if not all(np.isfinite(array).all() for array in arrays):
            raise RuntimeError(f"第{fold_number}折处理结果存在非有限值")
        if feature_preprocessor.fit_row_count != len(train):
            raise RuntimeError(f"第{fold_number}折特征处理器拟合范围错误")
        if target_preprocessor.fit_row_count != len(train):
            raise RuntimeError(f"第{fold_number}折结果处理器拟合范围错误")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=["prepare", "validate", "all"], default="all")
    parser.add_argument("--workbook", type=Path, default=DEFAULT_WORKBOOK)
    parser.add_argument("--sheet", default=DEFAULT_SHEET)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    raw_frame = load_dataset(args.workbook, args.sheet)
    model_table = build_model_input_table(raw_frame)
    if args.command in {"prepare", "all"}:
        data_path, fold_path = save_prepared_data(raw_frame, args.output_dir)
        print(f"已保存：{data_path}")
        print(f"已保存：{fold_path}")
    if args.command in {"validate", "all"}:
        validate_all_folds(model_table)
        print("五折高校隔离与折内预处理验证通过")


if __name__ == "__main__":
    main()
