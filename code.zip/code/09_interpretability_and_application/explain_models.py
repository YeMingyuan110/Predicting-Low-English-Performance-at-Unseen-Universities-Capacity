"""折外ESD-MTMS-Net解释：理论组Shapley、变量敏感度和解释稳定性。"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from scipy.special import expit
from scipy.stats import spearmanr
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score

MODULE = Path(__file__).resolve().parent
ROOT = MODULE.parent
MODEL_DIR = ROOT / "03_main_model"
PREDICTIONS = MODEL_DIR / "output/M2_raw_continuous_encoding_three_seed_ensemble_oof_predictions.csv"
RAW_PREDICTIONS = MODEL_DIR / "output/M2_raw_continuous_encoding_oof_predictions.csv"
CHECKPOINTS = MODEL_DIR / "output"
OUTPUT = MODULE / "output"
TASK = "english_performance"


def import_model_code():
    sys.path.insert(0, str(MODEL_DIR))
    import model  # type: ignore[import-not-found]
    import train_main  # type: ignore[import-not-found]
    return model, train_main


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def device_from_option(option: str) -> torch.device:
    if option == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if option == "cuda" and not torch.cuda.is_available():
        raise ValueError("当前环境没有可用CUDA")
    return torch.device(option)


def fixed_sample_ids(predictions: pd.DataFrame, per_fold: int, seed: int) -> dict[int, np.ndarray]:
    """只使用预测分数分层抽样个案，不看真实标签或误差。"""
    rng = np.random.default_rng(seed)
    selected = {}
    for fold, part in predictions.groupby("外层测试折", sort=True):
        part = part.sort_values("低表现校准概率_集成均值")
        chunks = np.array_split(part["样本编号"].to_numpy(), per_fold)
        selected[int(fold)] = np.asarray([rng.choice(chunk) for chunk in chunks], dtype=int)
    return selected


@dataclass
class FoldModel:
    model: torch.nn.Module
    feature_processor: object
    theory_groups: dict[str, list[int]]
    continuous_names: list[str]
    categorical_names: list[str]
    english_mean: float
    english_scale: float
    risk_coefficient: float
    risk_intercept: float
    device: torch.device


def build_fold_model(frame: pd.DataFrame, fold: int, seed: int, device: torch.device, model_code, protocol) -> FoldModel:
    path = CHECKPOINTS / f"M2_raw_continuous_encoding_fold_{fold}_seed_{seed}_model.pt"
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if checkpoint["outer_fold"] != fold or checkpoint["seed"] != seed:
        raise ValueError(f"检查点标签错误：{path.name}")
    state = checkpoint["preprocessing_state"]
    if state["连续编码"] != "raw":
        raise ValueError("当前解释代码仅用于正式原始连续编码主模型")
    train = frame[frame["外层测试折"] != fold]
    processor = protocol.DATA.FoldFeaturePreprocessor().fit(train)
    if processor.continuous_names != state["模型连续字段"] or list(processor.numeric_scaler.mean_) != state["连续标准化均值"]:
        if not np.allclose(processor.numeric_scaler.mean_, state["连续标准化均值"], rtol=0, atol=1e-8):
            raise ValueError("重建预处理器与检查点不一致")
    if processor.continuous_names != state["模型连续字段"] or processor.categorical_cardinalities != state["类别基数"]:
        raise ValueError("特征顺序或类别词表维度发生漂移")
    for actual, expected in zip(processor.category_encoder.categories_, state["类别词表"]):
        if list(actual) != expected:
            raise ValueError("类别词表与检查点不一致")
    config = model_code.ModelConfig(**checkpoint["model_config"])
    model = model_code.build_model(len(processor.continuous_names), processor.categorical_cardinalities,
                                   checkpoint["theory_groups"], config=config)
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.to(device).eval()
    target_mean = float(state["三任务标准化均值"][0])
    target_scale = float(state["三任务标准化尺度"][0])
    calibration = checkpoint["risk_calibrator"]
    return FoldModel(model, processor, checkpoint["theory_groups"], processor.continuous_names,
                     list(protocol.DATA.CATEGORICAL_INPUTS), target_mean, target_scale,
                     float(calibration["coefficient"]), float(calibration["intercept"]), device)


def predict(fold_model: FoldModel, continuous: np.ndarray, categorical: np.ndarray, batch_size: int = 512) -> np.ndarray:
    parts = []
    with torch.inference_mode():
        for start in range(0, len(continuous), batch_size):
            cont = torch.as_tensor(continuous[start:start + batch_size], dtype=torch.float32, device=fold_model.device)
            cat = torch.as_tensor(categorical[start:start + batch_size], dtype=torch.long, device=fold_model.device)
            standard = fold_model.model(cont, cat)[:, 0].detach().cpu().numpy()
            english = standard * fold_model.english_scale + fold_model.english_mean
            risk = expit(fold_model.risk_coefficient * (-english) + fold_model.risk_intercept)
            parts.append(np.column_stack([english, risk]))
    return np.concatenate(parts, axis=0)


def mixed_inputs(
    target_cont: np.ndarray, target_cat: np.ndarray,
    donor_cont: np.ndarray, donor_cat: np.ndarray,
    retained: set[int], groups: list[list[int]],
) -> tuple[np.ndarray, np.ndarray]:
    """同一训练折真实学生作为所有缺席理论组的联合背景。"""
    cont = donor_cont.copy()
    cat = donor_cat.copy()
    num_cont = cont.shape[1]
    for group_index in retained:
        for feature_index in groups[group_index]:
            if feature_index < num_cont:
                cont[:, feature_index] = target_cont[feature_index]
            else:
                cat[:, feature_index - num_cont] = target_cat[feature_index - num_cont]
    return cont, cat


def coalition_values(fold_model: FoldModel, cont: np.ndarray, cat: np.ndarray,
                     background_cont: np.ndarray, background_cat: np.ndarray,
                     groups: list[list[int]]) -> dict[int, np.ndarray]:
    values = {}
    for mask in range(1 << len(groups)):
        selected = {index for index in range(len(groups)) if mask & (1 << index)}
        mixed_cont, mixed_cat = mixed_inputs(cont, cat, background_cont, background_cat, selected, groups)
        values[mask] = predict(fold_model, mixed_cont, mixed_cat).mean(axis=0)
    return values


def exact_shapley(values: dict[int, np.ndarray], size: int) -> np.ndarray:
    weights = [math.factorial(k) * math.factorial(size - k - 1) / math.factorial(size) for k in range(size)]
    result = np.zeros((size, len(values[0])))
    for index in range(size):
        for mask in range(1 << size):
            if mask & (1 << index):
                continue
            result[index] += weights[mask.bit_count()] * (values[mask | (1 << index)] - values[mask])
    return result


def local_surrogate(values: dict[int, np.ndarray], size: int) -> tuple[float, float]:
    """LIME式五组二值局部代理；只作对照，绝不称为官方LIME实现。"""
    masks = np.arange(1 << size)
    matrix = ((masks[:, None] & (1 << np.arange(size))) > 0).astype(float)
    distance = np.sqrt((1 - matrix).sum(axis=1))
    weights = np.exp(-(distance / (0.75 * np.sqrt(size))) ** 2)
    target = np.vstack([values[int(mask)] for mask in masks])
    fidelity = []
    for task in range(target.shape[1]):
        surrogate = Ridge(alpha=1e-3).fit(matrix, target[:, task], sample_weight=weights)
        fidelity.append(float(r2_score(target[:, task], surrogate.predict(matrix), sample_weight=weights)))
    return fidelity[0], fidelity[1]


def feature_sensitivity(fold_model: FoldModel, cont: np.ndarray, cat: np.ndarray,
                        donor_cont: np.ndarray, donor_cat: np.ndarray,
                        baseline: np.ndarray, groups: dict[str, list[int]]) -> list[dict]:
    rows = []
    names = [*fold_model.continuous_names, *fold_model.categorical_names]
    num_cont = len(fold_model.continuous_names)
    for group, indices in groups.items():
        for index in indices:
            variant_cont = np.repeat(cont[None, :], len(donor_cont), axis=0)
            variant_cat = np.repeat(cat[None, :], len(donor_cat), axis=0)
            if index < num_cont:
                variant_cont[:, index] = donor_cont[:, index]
            else:
                variant_cat[:, index - num_cont] = donor_cat[:, index - num_cont]
            changed = predict(fold_model, variant_cont, variant_cat).mean(axis=0)
            rows.append({"理论组": group, "变量": names[index], "英语预测变化绝对值": abs(float(baseline[0] - changed[0])),
                         "低表现概率变化绝对值": abs(float(baseline[1] - changed[1]))})
    return rows


def stability_summary(local: pd.DataFrame) -> pd.DataFrame:
    group_order = sorted(local["理论组"].unique())
    rows = []
    for sample, group in local.groupby("样本编号"):
        vectors = []
        for _, seed_frame in group.groupby("随机种子"):
            vectors.append(seed_frame.set_index("理论组").reindex(group_order)["低表现风险Shapley"].to_numpy(float))
        if len(vectors) < 2:
            continue
        for i, j in itertools.combinations(range(len(vectors)), 2):
            first, second = vectors[i], vectors[j]
            correlation = spearmanr(np.abs(first), np.abs(second)).statistic
            top_first = set(np.argsort(np.abs(first))[-2:])
            top_second = set(np.argsort(np.abs(second))[-2:])
            rows.append({"样本编号": sample, "种子配对": f"{i+1}-{j+1}",
                         "组重要性Spearman": float(correlation) if np.isfinite(correlation) else np.nan,
                         "前二理论组Jaccard": len(top_first & top_second) / len(top_first | top_second)})
    return pd.DataFrame(rows)


def fold_stability(local: pd.DataFrame) -> pd.DataFrame:
    """比较每折的平均绝对组归因，量化跨高校测试折的一致程度。"""
    grouped = local.groupby(["外层测试折", "理论组"])["低表现风险Shapley"].apply(
        lambda values: float(np.mean(np.abs(values)))
    ).unstack("理论组")
    rows = []
    for first, second in itertools.combinations(grouped.index, 2):
        left = grouped.loc[first].to_numpy(float)
        right = grouped.loc[second].to_numpy(float)
        a = set(np.argsort(left)[-2:])
        b = set(np.argsort(right)[-2:])
        rows.append({"折A": int(first), "折B": int(second),
                     "组重要性Spearman": float(spearmanr(left, right).statistic),
                     "前二理论组Jaccard": len(a & b) / len(a | b)})
    return pd.DataFrame(rows, columns=["折A", "折B", "组重要性Spearman", "前二理论组Jaccard"])


def write_case_gate(output: Path) -> pd.DataFrame:
    """透明的解释展示门槛；属于待实证验证的工作流规则。"""
    local = pd.read_csv(output / "local_theory_group_shapley.csv")
    fidelity = pd.read_csv(output / "local_explanation_faithfulness.csv")
    background = pd.read_csv(output / "training_fold_background_sensitivity.csv")
    joined = fidelity.merge(background, on=["样本编号", "外层测试折", "随机种子"], validate="one_to_one")
    rows = []
    for sample_id, subset in joined.groupby("样本编号"):
        attributions = local[local["样本编号"].eq(sample_id)]
        top_groups = [part.loc[part["低表现风险Shapley"].abs().idxmax(), "理论组"]
                      for _, part in attributions.groupby("随机种子")]
        passed = bool(
            subset["风险局部代理加权R2"].ge(0.90).all()
            and subset["组归因与遮蔽效应Spearman"].ge(0.50).all()
            and subset["风险组重要性Spearman"].ge(0.60).all()
            and len(set(top_groups)) == 1
        )
        rows.append({"样本编号": int(sample_id), "外层测试折": int(subset["外层测试折"].iloc[0]),
                     "通过解释展示门槛": passed,
                     "三个种子是否同一首要理论组": len(set(top_groups)) == 1,
                     "首要理论组": top_groups[0] if len(set(top_groups)) == 1 else "种子间不一致",
                     "最小局部代理风险R2": float(subset["风险局部代理加权R2"].min()),
                     "最小遮蔽忠实度Spearman": float(subset["组归因与遮蔽效应Spearman"].min()),
                     "最小背景稳定性Spearman": float(subset["风险组重要性Spearman"].min()),
                     "使用建议": "可供辅导人员复核的模型依据" if passed else "仅提示风险，个案解释需人工复核"})
    result = pd.DataFrame(rows)
    result.to_csv(output / "case_explanation_use_thresholds.csv", index=False, encoding="utf-8-sig")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=str, default="42,3407,2027")
    parser.add_argument("--folds", type=str, default="1,2,3,4,5")
    parser.add_argument("--students-per-fold", type=int, default=12)
    parser.add_argument("--background-size", type=int, default=8)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--summarize-only", action="store_true", help="仅从已生成结果重建个案解释门槛")
    args = parser.parse_args()
    if args.summarize_only:
        result = write_case_gate(args.output)
        print(f"已复核{len(result)}个个案，通过解释展示门槛{int(result['通过解释展示门槛'].sum())}个")
        return
    if args.students_per_fold < 2 or args.background_size < 2:
        raise ValueError("每折个案数和背景人数至少为2")
    seeds = [int(value) for value in args.seeds.split(",")]
    folds = [int(value) for value in args.folds.split(",")]
    model_code, protocol = import_model_code()
    frame = protocol.load_protocol_data()
    predictions = pd.read_csv(PREDICTIONS)
    raw_predictions = pd.read_csv(RAW_PREDICTIONS).set_index(["样本编号", "外层测试折", "随机种子"])
    if len(predictions) != len(frame) or predictions["样本编号"].duplicated().any():
        raise ValueError("集成折外预测与输入数据不匹配")
    selected_ids = fixed_sample_ids(predictions, args.students_per_fold, 20260924)
    device = device_from_option(args.device)
    local_rows, sensitivity_rows, faithfulness_rows, prediction_deviations, background_rows = [], [], [], [], []
    checkpoint_hashes = {}
    for fold in folds:
        outer_train = frame[frame["外层测试折"] != fold]
        sampled = frame[frame["样本编号"].isin(selected_ids[fold])].sort_values("样本编号")
        if sampled["外层测试折"].nunique() != 1 or int(sampled["外层测试折"].iloc[0]) != fold:
            raise ValueError("解释样本不是当前外层未见高校测试折")
        rng = np.random.default_rng(20260924 + fold)
        donor_indices = rng.choice(len(outer_train), 2 * args.background_size, replace=False)
        background = outer_train.iloc[donor_indices[:args.background_size]]
        alternate_background = outer_train.iloc[donor_indices[args.background_size:]]
        for seed in seeds:
            path = CHECKPOINTS / f"M2_raw_continuous_encoding_fold_{fold}_seed_{seed}_model.pt"
            fold_model = build_fold_model(frame, fold, seed, device, model_code, protocol)
            checkpoint_hashes[path.name] = sha256(path)
            transformed = fold_model.feature_processor.transform(sampled)
            donors = fold_model.feature_processor.transform(background)
            alternate_donors = fold_model.feature_processor.transform(alternate_background)
            group_names = list(fold_model.theory_groups)
            group_indices = list(fold_model.theory_groups.values())
            for row_index, sample_id in enumerate(sampled["样本编号"].to_numpy()):
                cont = transformed.continuous[row_index]
                cat = transformed.categorical[row_index]
                values = coalition_values(fold_model, cont, cat, donors.continuous, donors.categorical, group_indices)
                shapley = exact_shapley(values, len(group_names))
                alternate_values = coalition_values(
                    fold_model, cont, cat, alternate_donors.continuous, alternate_donors.categorical, group_indices
                )
                alternate_shapley = exact_shapley(alternate_values, len(group_names))
                first_rank = np.abs(shapley[:, 1])
                second_rank = np.abs(alternate_shapley[:, 1])
                first_top = set(np.argsort(first_rank)[-2:])
                second_top = set(np.argsort(second_rank)[-2:])
                background_rows.append({
                    "样本编号": int(sample_id), "外层测试折": fold, "随机种子": seed,
                    "风险组重要性Spearman": float(spearmanr(first_rank, second_rank).statistic),
                    "前二理论组Jaccard": len(first_top & second_top) / len(first_top | second_top),
                    "组风险Shapley平均绝对变化": float(np.abs(shapley[:, 1] - alternate_shapley[:, 1]).mean()),
                })
                full = values[(1 << len(group_names)) - 1]
                reference = raw_predictions.loc[(int(sample_id), fold, seed)]
                reference_values = np.asarray([reference["english_performance_预测值"],
                                               reference["低表现校准概率"]], dtype=float)
                deviation = np.abs(full - reference_values)
                prediction_deviations.append({"样本编号": int(sample_id), "外层测试折": fold,
                                              "随机种子": seed, "英语预测绝对差": float(deviation[0]),
                                              "风险概率绝对差": float(deviation[1])})
                # 原检查点用PyTorch 2.8/CUDA 12.8训练；当前环境是2.13/CUDA 12.6。
                # 允许浮点内核差异，超过论文量尺上有意义的差值则拒绝解释。
                if deviation[0] > 0.25 or deviation[1] > 0.002:
                    raise RuntimeError(
                        f"检查点复原与样本外预测不一致：折{fold} 种子{seed} 样本{sample_id} "
                        f"复原={full.tolist()} 存档={[float(reference['english_performance_预测值']), float(reference['低表现校准概率'])]}"
                    )
                delta = np.abs(shapley.sum(axis=0) - (full - values[0]))
                if np.max(delta) > 1e-4:
                    raise RuntimeError("组Shapley加和性检查失败")
                fidelity_english, fidelity_risk = local_surrogate(values, len(group_names))
                leave_one_out = np.asarray([
                    full[1] - values[((1 << len(group_names)) - 1) ^ (1 << index)][1]
                    for index in range(len(group_names))
                ])
                perturbation_fidelity = spearmanr(np.abs(shapley[:, 1]), np.abs(leave_one_out)).statistic
                faithfulness_rows.append({"样本编号": int(sample_id), "外层测试折": fold, "随机种子": seed,
                                          "英语局部代理加权R2": fidelity_english, "风险局部代理加权R2": fidelity_risk,
                                          "组归因与遮蔽效应Spearman": float(perturbation_fidelity),
                                          "英语Shapley加和误差": float(delta[0]), "风险Shapley加和误差": float(delta[1])})
                for group_name, attribution in zip(group_names, shapley):
                    local_rows.append({"样本编号": int(sample_id), "外层测试折": fold, "随机种子": seed,
                                       "理论组": group_name, "英语预测Shapley": float(attribution[0]),
                                       "低表现风险Shapley": float(attribution[1]),
                                       "英语预测值": float(full[0]), "低表现预测概率": float(full[1]),
                                       "训练折背景英语预测均值": float(values[0][0]),
                                       "训练折背景风险预测均值": float(values[0][1])})
                for row in feature_sensitivity(fold_model, cont, cat, donors.continuous, donors.categorical,
                                               full, fold_model.theory_groups):
                    sensitivity_rows.append({"样本编号": int(sample_id), "外层测试折": fold, "随机种子": seed, **row})
            print(f"完成折{fold} 种子{seed}：{len(sampled)}个预先分层选取的折外个案", flush=True)
            del fold_model
            if device.type == "cuda":
                torch.cuda.empty_cache()
    local = pd.DataFrame(local_rows)
    sensitivity = pd.DataFrame(sensitivity_rows)
    args.output.mkdir(parents=True, exist_ok=True)
    local.to_csv(args.output / "local_theory_group_shapley.csv", index=False, encoding="utf-8-sig")
    sensitivity.to_csv(args.output / "feature_level_occlusion_sensitivity.csv", index=False, encoding="utf-8-sig")
    local.groupby("理论组").agg(
        英语平均绝对Shapley=("英语预测Shapley", lambda x: float(np.mean(np.abs(x)))),
        风险平均绝对Shapley=("低表现风险Shapley", lambda x: float(np.mean(np.abs(x)))),
        个案数量=("样本编号", "count"),
    ).reset_index().to_csv(args.output / "theory_group_global_importance.csv", index=False, encoding="utf-8-sig")
    sensitivity.groupby(["理论组", "变量"]).agg(
        英语平均预测变化=("英语预测变化绝对值", "mean"),
        风险平均概率变化=("低表现概率变化绝对值", "mean"),
    ).reset_index().to_csv(args.output / "feature_global_sensitivity.csv", index=False, encoding="utf-8-sig")
    stability_summary(local).to_csv(args.output / "between_seed_explanation_stability.csv", index=False, encoding="utf-8-sig")
    fold_stability(local).to_csv(args.output / "between_fold_explanation_stability.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(faithfulness_rows).to_csv(args.output / "local_explanation_faithfulness.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(prediction_deviations).to_csv(args.output / "checkpoint_prediction_verification.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(background_rows).to_csv(args.output / "training_fold_background_sensitivity.csv", index=False, encoding="utf-8-sig")
    write_case_gate(args.output)
    (args.output / "model_interpretation_run_manifest.json").write_text(json.dumps({
        "协议": "外层训练高校背景＋未见高校个案；5理论组全32个联盟精确Shapley",
        "随机种子": seeds, "外层折": folds, "每折每种子个案": args.students_per_fold,
        "每折背景学生数": args.background_size,
        "背景敏感性": "每折抽两组互不重复的训练高校真实学生，各自计算完整理论组Shapley并比较排名",
        "理论组Shapley": "训练折真实行作为共同背景；组间混合可能产生低密度组合，应视为模型归因而非因果效应",
        "局部代理": "五组二值联盟上拟合加权Ridge，属LIME式敏感性对照，并非LIME软件包的实现",
        "变量遮蔽": "训练折真实学生同一变量替换，绝对预测变化；不是变量级SHAP值",
        "个案解释展示门槛": "三种子均满足局部风险代理R2≥0.90、遮蔽忠实度Spearman≥0.50、背景稳定性Spearman≥0.60，且三个种子首要理论组相同；探索性工作流规则",
        "检查点复原最大偏差": {
            "英语成绩": max(row["英语预测绝对差"] for row in prediction_deviations),
            "风险概率": max(row["风险概率绝对差"] for row in prediction_deviations),
        },
        "输入SHA256": {PREDICTIONS.name: sha256(PREDICTIONS), RAW_PREDICTIONS.name: sha256(RAW_PREDICTIONS), **checkpoint_hashes},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"解释完成：{local['样本编号'].nunique()}个折外个案，{len(seeds)}个种子，{len(group_names)}个理论组")


if __name__ == "__main__":
    main()
