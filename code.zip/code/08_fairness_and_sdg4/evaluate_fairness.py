"""对锁定的折外英语预警预测进行群体差异与资源分配审计。"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

ROOT = Path(__file__).resolve().parent.parent
MODULE = Path(__file__).resolve().parent
INPUT = ROOT / "03_main_model/output/M2_raw_continuous_encoding_three_seed_ensemble_oof_predictions.csv"
LABEL = "低表现真实标签"
SCORE = "低表现校准概率_集成均值"
AUDITS = ["性别", "学生社会经济水平", "高校社会经济水平", "性别×学生社会经济水平"]
CAPACITIES = (0.10, 0.20)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def assign_capacity(frame: pd.DataFrame, capacity: float) -> pd.Series:
    selected = []
    for _, part in frame.groupby("外层测试折"):
        n = int(np.ceil(len(part) * capacity))
        selected.extend(part.sort_values([SCORE, "样本编号"], ascending=[False, True]).head(n).index)
    return pd.Series(frame.index.isin(selected), index=frame.index)


def metrics(part: pd.DataFrame, chosen: np.ndarray) -> dict[str, float]:
    truth = part[LABEL].to_numpy(dtype=int)
    probability = np.clip(part[SCORE].to_numpy(dtype=float), 1e-6, 1 - 1e-6)
    selected = np.asarray(chosen, dtype=bool)
    positives = truth == 1
    negatives = ~positives
    bins = pd.qcut(probability, 10, duplicates="drop")
    curve = pd.DataFrame({"标签": truth, "预测": probability, "分箱": bins}).groupby("分箱", observed=True).agg(
        人数=("标签", "size"), 实际率=("标签", "mean"), 平均预测=("预测", "mean")
    )
    return {
        "人数": int(len(part)), "低表现人数": int(positives.sum()), "低表现率": float(positives.mean()),
        "获得支持比例": float(selected.mean()),
        "低表现召回率": float(selected[positives].mean()) if positives.any() else np.nan,
        "非低表现获得支持率_FPR": float(selected[negatives].mean()) if negatives.any() else np.nan,
        "支持名额精准率_PPV": float(positives[selected].mean()) if selected.any() else np.nan,
        "ROC_AUC": float(roc_auc_score(truth, probability)) if positives.any() and negatives.any() else np.nan,
        "PR_AUC": float(average_precision_score(truth, probability)) if positives.any() and negatives.any() else np.nan,
        "Brier": float(brier_score_loss(truth, probability)),
        "ECE_等频10箱": float(np.average(np.abs(curve["实际率"] - curve["平均预测"]), weights=curve["人数"])),
    }


def evaluate(frame: pd.DataFrame, min_group: int, min_events: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows, gaps = [], []
    for capacity in CAPACITIES:
        frame = frame.copy()
        frame["获得支持"] = assign_capacity(frame, capacity)
        for column in AUDITS:
            valid_rows = []
            for value, part in frame.groupby(column, dropna=False, sort=True):
                record = {"审计维度": column, "群体": str(value), "容量比例": capacity, **metrics(part, part["获得支持"])}
                record["是否满足最低统计量"] = bool(
                    record["人数"] >= min_group
                    and record["低表现人数"] >= min_events
                    and record["人数"] - record["低表现人数"] >= min_events
                )
                rows.append(record)
                if record["是否满足最低统计量"]:
                    valid_rows.append(record)
            for metric in ("低表现召回率", "非低表现获得支持率_FPR", "支持名额精准率_PPV", "Brier", "ECE_等频10箱"):
                valid = [row[metric] for row in valid_rows if np.isfinite(row[metric])]
                gaps.append({"审计维度": column, "容量比例": capacity, "指标": metric,
                             "有效群体数": len(valid), "最大群体差": max(valid) - min(valid) if len(valid) >= 2 else np.nan})
    return pd.DataFrame(rows), pd.DataFrame(gaps)


def bootstrap_gaps(frame: pd.DataFrame, repetitions: int, seed: int, min_group: int, min_events: int) -> pd.DataFrame:
    """整所高校重采样；维持原始折内名额指示，不在重采样上重新制定政策。"""
    rng = np.random.default_rng(seed)
    cluster_frames = {name: part for name, part in frame.groupby("高校名称")}
    universities = list(cluster_frames)
    draws: dict[tuple[str, float, str], list[float]] = {}
    for _ in range(repetitions):
        sampled = pd.concat([cluster_frames[universities[i]] for i in rng.integers(0, len(universities), len(universities))], ignore_index=True)
        # 重复抽取同一高校时，原始资源分配指示被作为观察到的固定策略结果复制。
        for capacity in CAPACITIES:
            chosen = f"获得支持_{int(capacity * 100)}"
            for column in AUDITS:
                group_rows = []
                for _, part in sampled.groupby(column, dropna=False):
                    positives = int(part[LABEL].sum())
                    if len(part) < min_group or positives < min_events or len(part) - positives < min_events:
                        continue
                    group_rows.append(metrics(part, part[chosen]))
                for metric in ("低表现召回率", "非低表现获得支持率_FPR", "支持名额精准率_PPV", "Brier", "ECE_等频10箱"):
                    values = [row[metric] for row in group_rows if np.isfinite(row[metric])]
                    if len(values) >= 2:
                        draws.setdefault((column, capacity, metric), []).append(max(values) - min(values))
    return pd.DataFrame([
        {"审计维度": dimension, "容量比例": capacity, "指标": metric,
         "95%区间下限": float(np.quantile(values, 0.025)),
         "95%区间上限": float(np.quantile(values, 0.975)), "有效重采样次数": len(values)}
        for (dimension, capacity, metric), values in draws.items() if len(values) >= repetitions * 0.75
    ])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bootstrap", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20260924)
    parser.add_argument("--min-group", type=int, default=100)
    parser.add_argument("--min-events", type=int, default=20)
    parser.add_argument("--output", type=Path, default=MODULE / "output")
    args = parser.parse_args()
    if args.bootstrap < 100:
        raise ValueError("正式高校聚类bootstrap应至少100次")
    frame = pd.read_csv(INPUT)
    required = {"样本编号", "外层测试折", "高校名称", LABEL, SCORE, "性别", "学生社会经济水平", "高校社会经济水平"}
    if required - set(frame) or frame["样本编号"].duplicated().any() or frame[list(required)].isna().any().any():
        raise ValueError("主模型集成折外预测字段不完整、缺失或样本重复")
    frame["性别×学生社会经济水平"] = frame["性别"].astype(str) + "×" + frame["学生社会经济水平"].astype(str)
    for capacity in CAPACITIES:
        frame[f"获得支持_{int(capacity * 100)}"] = assign_capacity(frame, capacity)
    groups, gaps = evaluate(frame, args.min_group, args.min_events)
    intervals = bootstrap_gaps(frame, args.bootstrap, args.seed, args.min_group, args.min_events)
    gaps = gaps.merge(intervals, on=["审计维度", "容量比例", "指标"], how="left", validate="one_to_one")
    args.output.mkdir(parents=True, exist_ok=True)
    groups.to_csv(args.output / "group_fairness_and_calibration_metrics.csv", index=False, encoding="utf-8-sig")
    gaps.to_csv(args.output / "group_difference_university_cluster_intervals.csv", index=False, encoding="utf-8-sig")
    frame[["样本编号", "高校名称", "外层测试折", *AUDITS, LABEL, SCORE, "获得支持_10", "获得支持_20"]].to_csv(
        args.output / "fairness_audit_allocation_details.csv", index=False, encoding="utf-8-sig"
    )
    (args.output / "run_manifest.json").write_text(json.dumps({
        "协议": "五折高校隔离、三种子集成；折内固定容量风险排序",
        "最低群体人数": args.min_group, "最低阳性与阴性人数": args.min_events,
        "高校聚类Bootstrap次数": args.bootstrap, "输入SHA256": sha256(INPUT),
        "解释边界": "群体差异是审计结果；不代表歧视因果机制；SDG4为政策关联框架",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(gaps.to_string(index=False))


if __name__ == "__main__":
    main()
