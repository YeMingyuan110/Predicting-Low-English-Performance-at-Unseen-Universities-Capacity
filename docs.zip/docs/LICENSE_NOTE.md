# Licence note

This reviewer package does not assign a software licence. Absence of a licence means that reuse rights are not granted by default. Before public release, all code authors should agree on a licence compatible with the dependencies and institutional requirements, add the licence text at the package root, and cite any third-party code or adapted implementations.

