# Included file manifest

| Included file | Role in the study | Why included | External inputs needed |
|---|---|---|---|
| `code/01_data_preprocessing/data_preprocessing.py` | Cleans variables and constructs analysis-ready inputs | Establishes the preprocessing and leakage-control path | Source data |
| `code/02_measurement_and_suitability/measurement_and_suitability.py` | Educational-measurement and suitability diagnostics | Supports construct/data suitability claims | Processed analysis data |
| `code/03_main_model/model.py` | Defines ESD-MTMS-Net architecture | Core model implementation | None for inspection |
| `code/03_main_model/train_main.py` | University-disjoint training, inner validation, calibration, and OOF prediction | Core estimation procedure | Model input data and fold index |
| `code/04_baseline_comparison/run_baselines.py` | Executes strong tabular baselines under the shared protocol | Supports comparative performance claims | Same model input and fold index |
| `code/04_baseline_comparison/review_results.py` | Consolidates and checks baseline outputs | Supports auditable result aggregation | Baseline outputs |
| `code/05_ablation_and_task_interaction/run_ablations.py` | Structural ablation and task-sharing variants | Supports mechanism and necessity analysis | Same inputs and fold index |
| `code/06_cross_university_generalization/evaluate_reliability.py` | Cross-university generalization, drift, and clustered uncertainty | Supports robustness claims | OOF predictions and model inputs |
| `code/07_capacity_constrained_screening/evaluate_capacity.py` | Precision/recall/nDCG/lift under fixed support capacities | Supports resource-allocation analysis | OOF predictions and risk labels |
| `code/08_fairness_and_sdg4/evaluate_fairness.py` | Group performance, calibration, and clustered uncertainty | Supports descriptive fairness audit | OOF predictions and group fields |
| `code/09_interpretability_and_application/explain_models.py` | Exact grouped Shapley decomposition and case explanations | Supports interpretation claims | Inputs, fold index, OOF predictions, checkpoints |

## Excluded on purpose

- raw, processed, or student-level data;
- student-level out-of-fold predictions;
- model checkpoints and serialized weights;
- generated tables and figures;
- exploratory notebooks and notebook checkpoints;
- manuscript drafting utilities;
- duplicated plotting scripts;
- obsolete, debugging, smoke-test, and historical development files.

These exclusions keep the review package small and focused while avoiding unauthorized redistribution of sensitive or repository-governed material.

