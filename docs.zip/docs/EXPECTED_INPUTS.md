# Expected external inputs

The package does not redistribute data. To execute the workflow, place legally obtained inputs where the included scripts expect them, or update the path constants explicitly and record the change.

## Required for training and evaluation

1. **Analysis/model input table** containing the 25 predictors, raw outcome scores, student identifiers where permitted, and university identifiers.
2. **Fixed university-fold assignment** defining the five university-disjoint outer folds.
3. **Variable metadata or codebook** needed to identify numerical, categorical, outcome, and protected/group-audit fields.

## Required only for downstream analyses

- Out-of-fold predictions from all three seeds for generalization, capacity, and fairness analyses.
- Baseline out-of-fold predictions for model comparison and capacity curves.
- Fold/seed-specific fitted ESD-MTMS-Net checkpoints for grouped Shapley interpretation.
- Fold-specific preprocessing states needed to transform cases consistently with each fitted checkpoint.

## Source dataset

The manuscript identifies the source dataset as the dataset deposited by Delahoz-Dominguez and colleagues in Mendeley Data, version 1, DOI `10.17632/83tcx8psxv.1`. Users must verify the repository licence, access conditions, variable definitions, and ethical/privacy requirements directly from the dataset record.

## Privacy boundary

Do not place student-level inputs, OOF predictions, or identifiable intermediate files in a public code repository unless the repository licence and applicable institutional/privacy requirements explicitly permit this. Aggregate tables can be released separately after disclosure-risk review.

