# Execution guide

The scripts preserve the original research-directory relationships. Execute commands from the `code` directory or update path constants in a documented way.

1. `01_data_preprocessing/data_preprocessing.py`
2. `02_measurement_and_suitability/measurement_and_suitability.py`
3. `03_main_model/train_main.py` (imports `03_main_model/model.py`)
4. `04_baseline_comparison/run_baselines.py`
5. `04_baseline_comparison/review_results.py`
6. `05_ablation_and_task_interaction/run_ablations.py`
7. `06_cross_university_generalization/evaluate_reliability.py`
8. `07_capacity_constrained_screening/evaluate_capacity.py`
9. `08_fairness_and_sdg4/evaluate_fairness.py`
10. `09_interpretability_and_application/explain_models.py`

## Protocol safeguards

- Fit preprocessing, outcome scaling, PCA, and risk thresholds on the appropriate training partition only.
- Keep the outer university test fold unavailable to early stopping, calibration, feature selection, and model selection.
- Use the fixed university fold assignment and seeds `42`, `3407`, and `2027` for the reported principal analyses.
- Refit on the full outer-training set for the internally selected epoch before predicting the outer test fold.
- Preserve fold and seed identifiers in all OOF outputs.
- Treat capacity and fairness analyses as downstream audits of OOF predictions, not as additional tuning stages.

## Re-execution note

The selected scripts retain the original path constants to preserve provenance. A public release should replace machine-specific paths with command-line arguments or a single configuration file and should add automated end-to-end tests. Such refactoring was intentionally not performed in this reviewer package because it would create code that differs from the reported run.

